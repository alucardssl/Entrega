﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppFuncionario
{
    class Usuario
    {
        public string usuario { set; get; }
        public string contrasenia { set; get; }
        public byte rol { set; get; }

        public Usuario()
        {

        }

        public byte validoUsuario() //Le cambié el nombre de validoUsuario() a asignarRol() porque este se me hace más fácil de recordar, aparte no tenía sentido que asigne el rol y también lo devuelva así que también cambié eso, ahora solo le asigna el rol al usuario
        {
            String sql;
            ADODB.Recordset rs = new ADODB.Recordset();
            object filasAfectadas = new object();

            if (!iniciarConexion()) //primero que nada se testea la conexión, si esto falla devolvemos un 9 (no sé por qué, lel), osea  que rol 9 significa que no es usuario directamente
            {
                return 9;
            }
            //ahora sabemos que la conexión está abierta

            Program.cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient;

            if (Program.cn.State == 1) //Si la conexion está abierta
            {
                sql = "Select rol from usuario_rol where usuario='" + usuario + "'";
                try
                {
                    rs = Program.cn.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    return 10;
                }

                if (rs.RecordCount == 0) //no encontré el rol del usuario
                {
                    return 11;
                }
                else //encontramos el rol del usuario (encontramos hasta uno, pues buscamos por la PK)
                {
                    rol = Convert.ToByte(rs.Fields[0].Value);
                    return rol;
                }

            } //if

            else
            {
                return 12;
            }
        }


        public bool iniciarConexion() //este método inicia la conexión, devolviendo un true si lo hace con exito y un false si no
        {
            try
            {
                if (Program.cn.State == 1) //si la conexión está abierta, la cierro primero
                {
                    Program.cn.Close();
                }

                Program.cn.Open("miodbc", usuario, contrasenia); //intentamos conectarnos a la base de datos
                return true; //Nos conectamos exitosamente yaaaay!!!
            }
            catch
            {
                return false; //ERROR. No pudimos conectarnos :(
            }
        }




    }
}