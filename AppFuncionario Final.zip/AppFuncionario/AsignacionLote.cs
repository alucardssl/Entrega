﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppFuncionario
{
    class AsignacionLote
    {
        private int _idLote;
        private int _idCamion;
        private int _idDeposito;
        private ADODB.Connection _conexion;

        public AsignacionLote()
        {
            _idLote= 0;
            _idCamion= 0;
            _idDeposito = 0;
            _conexion = new ADODB.Connection();
        }
        public AsignacionLote(int IdLote,int idDeposito, int idCamion, ADODB.Connection cn)
        {
            _idLote = IdLote;
            _idCamion = idCamion;
            _idDeposito = idDeposito;
            _conexion = cn;
        }
        public int idLote { get => _idLote; set => _idLote = value; }
        public int idCamion { get => _idCamion; set => _idCamion= value; }
        public int idDeposito { get => _idDeposito; set => _idDeposito = value; }
        public ADODB.Connection conexion
        {
            get { return (_conexion); }
            set { _conexion = value; }
        }

        public byte AsignarLote()
        {
            object filasAfectadas;
            string sql;
            ADODB.Recordset rs = new ADODB.Recordset();
            byte resultado = 0;

            if (_conexion.State == 0)
            {
                resultado = 1; // La conexión está cerrada.
            }
            else
            {
                sql = "select * from camionalmacenadoen join camion on camionalmacenadoen.camion = camion.id Join deposito on camionalmacenadoen.deposito = deposito.id where camion.id = " + _idCamion + " and deposito.id =" + _idDeposito;
                try
                {
                    //_conexion.Execute(sql, out filasAfectadas);
                    rs.Open(sql, _conexion, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly, -1);
                }
                catch
                {
                    return 2; // Error al ejecutar la consulta de inserción
                }
                if (rs.RecordCount == 0)   
                {
                    return 3;//No se encontró
                }
                Program.cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient;
                rs.Close();
                rs = null;

                sql = "INSERT INTO camionlleva (camion, lote) VALUES (" + _idCamion + "," + _idLote+")";

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    return 2; // Error al ejecutar la consulta de inserción
                }
            }
            return resultado;
        }
        public byte EliminarLote()
        {
            object filasAfectadas;
            string sql;
            byte resultado = 0;

            if (_conexion.State == 0)
            {
                resultado = 1; // La conexión no está abierta
            }
            else
            {
                // Componer la consulta de eliminación para la tabla 'camion'
                sql = "DELETE FROM camionlleva WHERE lote=" + _idLote;

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 2; // Error al ejecutar la consulta de eliminación
                }

            }


            return resultado;
        }
    }
}
