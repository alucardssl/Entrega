﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppFuncionario
{
    class Lote
    {
        private int _id;
        private int _idProducto;
        private int _prioridad;
        private int _idDeposito;
        private DateTime _fechaLimite;
        private List<String> _nombreDeposito;
        private List<String> _nombreProducto;
        private float _latitudDepositoDestino;
        private float _longitudDepositoDestino;
        private String _direccionDepositoDestino;
        private String _departamentoLugar;
        private ADODB.Connection _conexion;

        public Lote()
        {
            _id = 0;
            _idProducto = 0;
            _prioridad = 0;
            _idDeposito = 0;
            _fechaLimite = new DateTime();
            _nombreDeposito = new List<String>();
            _nombreProducto = new List<String>();
            _latitudDepositoDestino = 0;
            _longitudDepositoDestino = 0;
            _direccionDepositoDestino = "";
            _departamentoLugar = "";
            _conexion = new ADODB.Connection();
        }

        public Lote(int ID, int idProducto, List<String> nombreDeposito, List<String> nombreProducto, int idDeposito, int prioridad, DateTime fechaLimite, float latitudDepositoDestino, float longitudDepositoDestino, String direccionDepositoDestino, String departamentoLugar, ADODB.Connection cn)
        {
            _id = ID;
            _idProducto = idProducto;
            _idDeposito = idDeposito;
            _prioridad = prioridad;
            _fechaLimite = fechaLimite;
            _nombreDeposito = nombreDeposito;
            _nombreProducto = nombreProducto;
            _latitudDepositoDestino = latitudDepositoDestino;
            _longitudDepositoDestino = longitudDepositoDestino;
            _direccionDepositoDestino = direccionDepositoDestino;
            _departamentoLugar = departamentoLugar;
            _conexion = cn;
        }

        public int Id { get => _id; set => _id = value; }
        public int idProducto { get => _idProducto; set => _idProducto = value; }
        public int idDeposito { get => _idDeposito; set => _idDeposito = value; }
        public int prioridad { get => _prioridad; set => _prioridad = value; }
        public DateTime FechaLimite { get => _fechaLimite; set => _fechaLimite = value; }
        public List<String> NombreDeposito { get => _nombreDeposito; set => _nombreDeposito = value; }
        public List<String> NombreProducto { get => _nombreProducto; set => _nombreProducto = value; }
        public float LatitudDepositoDestino { get => _latitudDepositoDestino; set => _latitudDepositoDestino = value; }
        public float LongitudDepositoDestino { get => _longitudDepositoDestino; set => _longitudDepositoDestino = value; }
        public string DireccionDepositoDestino { get => _direccionDepositoDestino; set => _direccionDepositoDestino = value; }
        public string DepartamentoLugar { get => _departamentoLugar; set => _departamentoLugar = value; }

        public ADODB.Connection conexion
        {
            get { return (_conexion); }
            set { _conexion = value; }
        }

        public int buscar()
        {
            int retorno = 0; //por defecto asumo que no hubieron errores.
            //object cantFilas;
            ADODB.Recordset rs = new ADODB.Recordset();
            string sql;


            if (_conexion.State == 0)
            {
                retorno = 1; //conexión cerrada.
            }
            else
            {
                Program.cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient;
                sql = "select id from lote where id=" + _id;
                try
                {
                    //rs = _conexion.Execute(sql, out cantFilas, -1);   
                    rs.Open(sql, _conexion, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly, -1);
                }
                catch
                {
                    return 2; //error al ejecutar la consulta.
                }
                if (rs.RecordCount == 0)
                {
                    return 3; //No se encontró registro alguno.
                }
                Program.cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient;
                rs.Close();
                rs = null; // destruyo el objeto.
            }//if
            return (retorno);
        }
        public int buscarDestinoYProductos()
        {
            int retorno = 0; // Por defecto, asumimos que no hubo errores.
            ADODB.Recordset rs = new ADODB.Recordset();
            string sql;

            if (_conexion.State == 0)
            {
                retorno = 1; // Conexión cerrada.
            }
            else
            {
                // Consulta para la tabla 'lugar'
                sql = "SELECT nombre FROM deposito";
                try
                {
                    rs.Open(sql, _conexion, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly, -1);
                    _nombreDeposito.Clear();
                    while (!rs.EOF)
                    {
                        _nombreDeposito.Add(rs.Fields[0].Value);
                        rs.MoveNext();
                    }
                    rs.Close();
                }
                catch
                {
                    return 2; // Error al ejecutar la consulta de nombre de lugar
                }

                // Consulta para la tabla 'departamento'
                sql = "SELECT nombre FROM producto";
                try
                {
                    rs.Open(sql, _conexion, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly, -1);
                    _nombreProducto.Clear();
                    while (!rs.EOF)
                    {
                        _nombreProducto.Add(rs.Fields[0].Value);
                        rs.MoveNext();
                    }
                    rs.Close();
                }
                catch
                {
                    return 3; // Error al ejecutar la consulta de nombre de departamento
                }

                Program.cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient;
                rs = null; // Destruyo el objeto.
            }

            return retorno;
        }
        public byte CrearLote()
        {
            object filasAfectadas;
            string sql;
            byte resultado = 0;

            if (_conexion.State == 0)
            {
                resultado = 1; // La conexión está cerrada.
            }
            else
            {
                // Componer la consulta de inserción para la tabla 'producto'
                sql = "INSERT INTO lote (fechalimite, prioridad,destino) VALUES ('" + _fechaLimite.ToString("yyyy-MM-dd") + "','" + _prioridad + "'," + _idDeposito + ")";

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    return 2; // Error al ejecutar la consulta de inserción
                }
            }
            return resultado;
        }
        public byte ModificarLote()
        {
            object filasAfectadas;
            string sql;
            byte resultado = 0;

            if (_conexion.State == 0)
            {
                resultado = 1; // La conexión está cerrada.
            }
            else
            {
                // Componer la consulta de actualización para la tabla 'lote'
                sql = "UPDATE lote SET fechalimite = '" + _fechaLimite.ToString("yyyy-MM-dd") + "', prioridad = '" + _prioridad + "', destino = " + _idDeposito + " WHERE id = " + _id;

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    return 2; // Error al ejecutar la consulta de actualización
                }
            }
            return resultado;
        }

        public byte EliminarLote()
        {
            object filasAfectadas;
            string sql;
            byte resultado = 0;

            if (_conexion.State == 0)
            {
                resultado = 1; // La conexión no está abierta
            }
            else
            {
                // Componer la consulta de eliminación para la tabla 'camion'
                sql = "DELETE FROM lote WHERE id=" + _id;

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 2; // Error al ejecutar la consulta de eliminación
                }

            }


            return resultado;
        }
        public byte AgregarProducto()
        {
            object filasAfectadas;
            string sql;
            byte resultado = 0;

            if (_conexion.State == 0)
            {
                resultado = 1; // La conexión está cerrada.
            }
            else
            {
                // Componer la consulta de inserción para la tabla 'producto'
                sql = "INSERT INTO productodentrodelote(productoDentro, lote) Value(" + _idProducto + "," + _id + ")";

                /*try
                {*/
                _conexion.Execute(sql, out filasAfectadas);
                /*}
                catch
                {
                    return 2; // Error al ejecutar la consulta de inserción
                }*/
            }
            return resultado;
        }
        public byte EliminarProducto()
        {
            object filasAfectadas;
            string sql;
            byte resultado = 0;

            if (_conexion.State == 0)
            {
                resultado = 1; // La conexión no está abierta
            }
            else
            {
                // Componer la consulta de eliminación para la tabla 'camion'
                sql = "DELETE FROM productodentrodelote WHERE productoDentro=" + _idProducto;

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 2; // Error al ejecutar la consulta de eliminación
                }

            }
            return resultado;
        }
    }
}

