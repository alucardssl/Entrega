﻿namespace AppFuncionario
{
    partial class IngresarDeposito
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblIngresar = new System.Windows.Forms.Label();
            this.btnContinuar = new System.Windows.Forms.Button();
            this.cboDeposito = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lblIngresar
            // 
            this.lblIngresar.BackColor = System.Drawing.Color.Transparent;
            this.lblIngresar.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblIngresar.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold);
            this.lblIngresar.ForeColor = System.Drawing.Color.BlueViolet;
            this.lblIngresar.Location = new System.Drawing.Point(0, 0);
            this.lblIngresar.Name = "lblIngresar";
            this.lblIngresar.Size = new System.Drawing.Size(1284, 129);
            this.lblIngresar.TabIndex = 13;
            this.lblIngresar.Text = "Seleccione ID de Depósito para Continuar";
            this.lblIngresar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // btnContinuar
            // 
            this.btnContinuar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnContinuar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnContinuar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnContinuar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContinuar.ForeColor = System.Drawing.Color.BlueViolet;
            this.btnContinuar.Location = new System.Drawing.Point(778, 165);
            this.btnContinuar.Name = "btnContinuar";
            this.btnContinuar.Size = new System.Drawing.Size(138, 44);
            this.btnContinuar.TabIndex = 140;
            this.btnContinuar.Text = "Continuar";
            this.btnContinuar.UseVisualStyleBackColor = true;
            this.btnContinuar.Click += new System.EventHandler(this.btnContinuar_Click);
            // 
            // cboDeposito
            // 
            this.cboDeposito.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.cboDeposito.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.cboDeposito.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboDeposito.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboDeposito.ForeColor = System.Drawing.Color.White;
            this.cboDeposito.FormattingEnabled = true;
            this.cboDeposito.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.cboDeposito.Location = new System.Drawing.Point(503, 173);
            this.cboDeposito.Name = "cboDeposito";
            this.cboDeposito.Size = new System.Drawing.Size(254, 32);
            this.cboDeposito.TabIndex = 180;
            // 
            // IngresarDeposito
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(12)))), ((int)(((byte)(27)))));
            this.ClientSize = new System.Drawing.Size(1284, 573);
            this.Controls.Add(this.cboDeposito);
            this.Controls.Add(this.btnContinuar);
            this.Controls.Add(this.lblIngresar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "IngresarDeposito";
            this.Text = "+++++++++++++++++";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblIngresar;
        public System.Windows.Forms.Button btnContinuar;
        public System.Windows.Forms.ComboBox cboDeposito;
    }
}