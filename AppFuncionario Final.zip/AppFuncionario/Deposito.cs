﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppFuncionario
{
    class Deposito
    {
        private ADODB.Connection _conexion;
        private int _idDeposito;
        public Deposito()
        { 
            _conexion = new ADODB.Connection();
        }

        public Deposito(int idDeposito, ADODB.Connection cn)
        {
            _idDeposito = 0;
            _conexion = cn;
        }
        public int IdDeposito { get => _idDeposito; set => _idDeposito = value; }

        public ADODB.Connection conexion
        {
            get { return (_conexion); }
            set { _conexion = value; }
        }

        public int buscar()
        {
            int retorno = 0; //por defecto asumo que no hubieron errores.
            //object cantFilas;
            ADODB.Recordset rs = new ADODB.Recordset();
            string sql;


            if (_conexion.State == 0)
            {
                retorno = 1; //conexión cerrada.
            }
            else
            {
                Program.cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient;
                sql = "select * from funcionariosupervisa where deposito =" + _idDeposito;
                try
                {
                    //rs = _conexion.Execute(sql, out cantFilas, -1);   
                    rs.Open(sql, _conexion, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly, -1);
                }
                catch
                {
                    return 2; //error al ejecutar la consulta.
                }
                if (rs.RecordCount == 0)
                {
                    return 3; //No se encontró registro alguno.
                }
                Program.cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient;
                rs.Close();
                rs = null; // destruyo el objeto.
            }//if
            return (retorno);
        }
    }
}
