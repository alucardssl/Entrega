﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace AppFuncionario
{
    public partial class IngresarDeposito : Form
    {
        public IngresarDeposito()
        {
            InitializeComponent();
            actualizarTexto();
            List<String> ubicaciones = new List<String>();
            String sql;
            ADODB.Recordset rs = new ADODB.Recordset();
            object filasAfectadas = new object();
            sql = "select deposito from funcionariosupervisa where funcionario = '" + Program.CI+"'";
            try
            {
                rs = Program.cn.Execute(sql, out filasAfectadas);
            }
            catch
            {
                return;
            }
            while (!rs.EOF) //mientras no llegue al fin 
            {
                cboDeposito.Items.Add(Convert.ToString(rs.Fields[0].Value));
                rs.MoveNext();
            }

        }
        private void btnContinuar_Click(object sender, EventArgs e) //-S Primero chequearia que existe el deposito seleccionado en la bd
        {
            Deposito d = new Deposito();
            d.IdDeposito = int.Parse(cboDeposito.Text);
            d.conexion = Program.cn;

            switch (d.buscar())
            {
                case 0:  //Encontré 
                    Program.frmPrincipal.actualizarPantalla(0);
                    Program.idDepositoActual = int.Parse(cboDeposito.Text); //Uso el tag como espacio de memoria donde almacenar el ID de Deposito
                    Program.frmPrincipal.actualizarTexto();
                    break;
                case 1: //La conexión está cerrada.
                    MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                    break;
                case 2:
                    MessageBox.Show("Hubo errores");
                    break;
                case 4:
                    MessageBox.Show("Hubo errores al efectuar operación");
                    break;
                case 3: //No encontré
                    CustomMessageBox.Show("El deposito ingresado no te corresponde ", "Error");
                    break;
            };           
        }

        public void actualizarTexto()
        {
            switch (Program.frmLogin.idioma)
            {
                case 0:
                    lblIngresar.Text = "Seleccione ID de Depósito para Continuar";
                    btnContinuar.Text = "Continuar";
                    break;
                case 1:
                    lblIngresar.Text = "Enter a Warehouse to Navigate in";
                    btnContinuar.Text = "Continue";
                    break;
                default:
                    lblIngresar.Text = "Seleccione ID de Depósito para Continuar";
                    btnContinuar.Text = "Continuar";
                    break;
            }
        }
    }
}


