﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppFuncionario
{
    public partial class Lotes : Form
    {
        public Lotes()
        {
            InitializeComponent();
        }

        private void btnCrear_Click(object sender, EventArgs e)
        {
            Lote l = new Lote();
            l.Id = int.Parse(txtID.Text);
            l.idUbicacion = int.Parse(txtUbicacion.Text);
            l.idDestino = int.Parse(txtDestino.Text);
            l.FechaLimite = dtpFechaLimite.Value;
            l.prioridad = cboPrioridad.SelectedIndex;
            l.conexion = Program.cn;

            switch (l.CrearLote())
            {
                case 0:  //Se pudo efectuar el alta o modificación sin problemas.

                    MessageBox.Show ("Lote creado exitosamente");
                    this.Close();
                    break;
                case 1: //La conexión está cerrada.
                    MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                    break;
                case 2:
                    MessageBox.Show("2");
                    break;
                case 3:
                    MessageBox.Show("3");
                    break;
            }
            l = null;
            this.Close();
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            Lote l = new Lote();
            l.Id = int.Parse(txtID.Text);
            l.idUbicacion = int.Parse(txtUbicacion.Text);
            l.idDestino = int.Parse(txtDestino.Text);
            l.FechaLimite = dtpFechaLimite.Value;
            l.prioridad = cboPrioridad.SelectedIndex;
            l.conexion = Program.cn;

            switch (l.ModificarLote())
            {
                case 0:  //Se pudo efectuar el alta o modificación sin problemas.
                    MessageBox.Show("Lote modificado exitosamente");
                    this.Close();
                    break;
                case 1: //La conexión está cerrada.
                    MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                    break;
                case 2:
                    MessageBox.Show("2");
                    break;
                case 3:
                    MessageBox.Show("3");
                    break;
            }
            l = null;
            this.Close();
        }

        private void btnAgregarProducto_Click(object sender, EventArgs e)
        {
            Lote l = new Lote();
            l.Id = int.Parse(txtID.Text);
            l.idProducto = int.Parse(txtProductos.Text);
            l.FechaLimite = dtpFechaLimite.Value;
            l.prioridad = cboPrioridad.SelectedIndex;
            l.conexion = Program.cn;

            switch (l.AgregarProducto())
            {
                case 0:  //Se pudo efectuar el alta o modificación sin problemas.
                    MessageBox.Show("Producto agregado exitosamente");
                    break;
                case 1: //La conexión está cerrada.
                    MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                    break;
                case 2:
                    MessageBox.Show("2");
                    break;
                case 3:
                    MessageBox.Show("3");
                    break;
            }

            l = null;
            this.Close();
        }

        private void btnEliminarProducto_Click(object sender, EventArgs e)
        {
            Program.frmLotes = new Lotes();
            Lote l = new Lote();
            l.idProducto = int.Parse(txtProductos.Text);
            l.Id = int.Parse(txtID.Text);
            l.conexion = Program.cn;

            switch (l.buscar())
            {
                case 0:  //Encontré 
                    l.EliminarProducto();
                    CustomMessageBox.Show("Producto eliminado exitosamente.", "Mensaje");
                    l = null;
                    break;
                case 1: //La conexión está cerrada.
                    MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                    break;
                case 2:
                case 4:
                    MessageBox.Show("Hubo errores al efectuar operación");
                    break;
                case 3: //No encontré
                    CustomMessageBox.Show("El Producto no existe en el sistema", "Error");
                    return;
            };
            l = null;
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            Program.frmPrincipal.actualizarPantalla(2);
            this.Close();
        }

        public void actualizarTexto()
        {
            switch (Program.frmLogin.idioma)
            {
                case 0:
                    lblFechaLim.Text = "Fecha Máxima de Entrega";
                    lblPrioridad.Text = "Prioridad";
                    lblDestino.Text = "ID de Destino";
                    btnCrear.Text = "Guardar";
                    btnVolver.Text = "Cancelar";
                    btnModificar.Text = "Modificar";
                    lblTitulo.Text = "Creación de Lote";
                    lblIDProductos.Text = "ID de Productos";
                    lblUbicacion.Text = "Ubicación";
                    break;
                case 1:
                    lblFechaLim.Text = "Due date";
                    lblPrioridad.Text = "Priority";
                    lblDestino.Text = "Destination";
                    btnCrear.Text = "Save";
                    btnVolver.Text = "Cancel";
                    btnModificar.Text = "Modify";
                    lblTitulo.Text = "Package Registration";
                    lblIDProductos.Text = "Products ID";
                    lblUbicacion.Text = "Location";
                    break;
            }
        }

        
    }   
}
