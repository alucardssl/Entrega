﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppFuncionario
{
    static class Program
    {
        public static Principal frmPrincipal;
        public static ADODB.Connection cn = new ADODB.Connection();
        public static Login frmLogin;
        public static Productos frmProductos;
        public static Lotes frmLotes;
        public static PagWeb frmPagWeb;
        public static Preferencias frmPreferencias;
        public static IngresarDeposito frmIngresarDeposito;
        public static Boolean existeCI;
        public static AsignarLote frmAsignarLote;
        public static int idDepositoActual = 0;
        public static int CI;

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            frmLogin = new Login();
            Application.Run(new Login());
        }
    }
}
