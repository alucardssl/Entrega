﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Backoffice.capa_de_negocios;
using Backoffice.capa_de_presentacion;
using System.Data.OleDb;

namespace Backoffice
{
    public partial class Backoffice : Form
    {
        public byte categoriaMenuActual = 1;
        /*Indicador de en que categoria está navegando el usuario en el menú
        0 -Inicio
        1 - Funcionarios
        2 - Camioneros
        3 - Camiones
        4 - Productos
        5 - Lotes
        6 - Depósitos
        */

        private bool _txtCiIntacto;
        private bool _txtNombreIntacto;
        Funcionario f = new Funcionario();

        public Backoffice()
        {

            InitializeComponent();
            actualizarTexto();
            actualizarPantalla(0);
        }

        public void actualizarPantalla(byte nuevaCategoriaMenu)
        {
            //MessageBox.Show(Convert.ToString(pnlEncabez.Size.Width - btnFuncionarios.Size.Width));
            //MessageBox.Show(Convert.ToString(pnlLateralL.Size.Height));

            /*
            if (categoriaMenuActual == nuevaCategoriaMenu) //no me saquen esto de vuelta por favor
            {
                return;
            }*/
            //-S lo saco porque interfiere con botones que quieren actualizar la pantalla sin cambiar de categoria el menu

            btnFuncionarios.BackColor = Color.FromArgb(5, 5, 15);
            btnCamioneros.BackColor = Color.FromArgb(5, 5, 15);
            btnProductos.BackColor = Color.FromArgb(5, 5, 15);
            btnCamiones.BackColor = Color.FromArgb(5, 5, 15);
            btnLotes.BackColor = Color.FromArgb(5, 5, 15);
            btnDepositos.BackColor = Color.FromArgb(5, 5, 15);
            txtCI.ForeColor = Color.FromArgb(80, 80, 95);
            pnlLateralL.Show();
            pnlLateralR.Show();
            pnlFormHijo.Hide();
            pnl_lupita.Hide();
            pnlLogoFondo.Hide();
            txtCI.Show();
            btnAgregar.Hide();
            btnEliminar.Hide();
            lblError.Hide();
            dgvResultados.Hide();
            dgvResultados.Columns.Clear();
            IsMdiContainer = false;
            _txtCiIntacto = true;
            _txtNombreIntacto = true;

            categoriaMenuActual = nuevaCategoriaMenu;

            switch (nuevaCategoriaMenu)
            {
                case 0: //Ninguna categoría seleccionada / Pantalla inicial
                    pnlLogoFondo.Show();
                    txtCI.Hide();
                    break;
                case 1: //Categoría Funcionarios seleccionada
                    btnFuncionarios.BackColor = Color.FromArgb(12, 12, 27);
                    actualizarTextoCategoria(nuevaCategoriaMenu);
                    btnAgregar.Show();
                    btnEliminar.Show();
                    pnl_lupita.Show();
                    actualizarDataGrid();
                    dgvResultados.Show();
                    break;

                case 2: //Categoría Camioneros seleccionada
                    btnCamioneros.BackColor = Color.FromArgb(12, 12, 27);
                    actualizarTextoCategoria(nuevaCategoriaMenu);
                    btnAgregar.Show();
                    btnEliminar.Show();
                    pnl_lupita.Show();
                    dgvResultados.Columns.Add("id", "ID");
                    dgvResultados.Columns.Add("nombre", "Nombre");
                    dgvResultados.Columns.Add("apellidos", "Apellidos");
                    dgvResultados.Columns.Add("fechaNac", "Fecha de nacimiento");
                    dgvResultados.Columns.Add("tel", "Telefono");
                    dgvResultados.Columns.Add("mail", "Mail");
                    actualizarDataGrid();
                    dgvResultados.Show();
                    break;
                case 3: //Categoría Camiones seleccionada
                    btnCamiones.BackColor = Color.FromArgb(12, 12, 27);
                    actualizarTextoCategoria(nuevaCategoriaMenu);
                    btnAgregar.Show();
                    btnEliminar.Show();
                    pnl_lupita.Show();
                    actualizarDataGrid();
                    dgvResultados.Show();
                    break;
                case 4: //Categoría Productos seleccionada
                    btnProductos.BackColor = Color.FromArgb(12, 12, 27);
                    actualizarTextoCategoria(nuevaCategoriaMenu);
                    btnAgregar.Show();
                    btnEliminar.Show();
                    pnl_lupita.Show();
                    actualizarDataGrid();
                    dgvResultados.Show();
                    break;
                case 5: //Categoría Lotes seleccionada
                    btnLotes.BackColor = Color.FromArgb(12, 12, 27);
                    actualizarTextoCategoria(nuevaCategoriaMenu);
                    btnAgregar.Show();
                    btnEliminar.Show();
                    pnl_lupita.Show();
                    actualizarDataGrid();
                    dgvResultados.Show();
                    break;
                case 6: //Categoría Depósitos seleccionada
                    btnDepositos.BackColor = Color.FromArgb(12, 12, 27);
                    actualizarTextoCategoria(nuevaCategoriaMenu);
                    btnAgregar.Show();
                    btnEliminar.Show();
                    pnl_lupita.Show();
                    ActualizarDataGridDepositos();
                    dgvResultados.Show();
                    break;
            } //switch
        }


        private Int32 numero(String valor)
        {
            Int32 retorno;
            if (!Int32.TryParse(valor, out retorno))
            {
                retorno = 0;
            }
            return (retorno);
        }

        public Boolean validaCI(int CI)
        {
            Boolean retorno = true;
            Int16 i;
            int calculoDigitoControl = 0;
            int digitoControl = CI % 10;
            int CIaux = CI / 10; //división entera
            if (CI < 100000)
            {
                retorno = false;
            }
            else
            {
                for (i = 1; i <= 7; i++)
                {
                    switch (i)
                    {
                        case 1:
                            calculoDigitoControl = calculoDigitoControl + (CIaux % 10) * 6;
                            break;
                        case 2:
                            calculoDigitoControl = calculoDigitoControl + (CIaux % 10) * 7;
                            break;
                        case 3:
                            calculoDigitoControl = calculoDigitoControl + (CIaux % 10) * 4;
                            break;
                        case 4:
                            calculoDigitoControl = calculoDigitoControl + (CIaux % 10) * 3;
                            break;
                        case 5:
                            calculoDigitoControl = calculoDigitoControl + (CIaux % 10) * 2;
                            break;
                        case 6:
                            calculoDigitoControl = calculoDigitoControl + (CIaux % 10) * 1;
                            break;
                        case 7:
                            calculoDigitoControl = calculoDigitoControl + (CIaux % 10) * 8;
                            break;
                    };
                    CIaux = CIaux / 10;
                }//for
                retorno = (calculoDigitoControl % 10 == digitoControl);
            }
            return (retorno);
        }

        private void txtCI_TextChanged(object sender, EventArgs e) //esto hace que aparezca el cartelito que avisa que la cédula es inválida antes de darle al botón
        {
            switch (categoriaMenuActual)
            {
                case 1:
                case 2:

                    if (txtCI.Text.Length == 8)
                    {
                        if (validaCI(numero(txtCI.Text)))
                        {
                            lblError.Text = "Cédula valida.";
                            lblError.ForeColor = Color.MediumSeaGreen;
                            lblError.Show();
                        }
                        else
                        {
                            lblError.Text = "Cédula invalida.";
                            lblError.ForeColor = Color.Crimson;
                            lblError.Show();
                        }
                    }
                    else
                    {
                        lblError.Hide();
                    }
                    break;
            }

        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            switch (categoriaMenuActual)
            {
                case 1: //funcionarios

                    if (!validaCI(numero(txtCI.Text)))
                    {
                        CustomMessageBox.Show("Cédula inválida", "Error");
                        return;
                    }

                    
                    List<String> telefonosF = new List<String>();
                    f.ci = numero(txtCI.Text);
                    f.conexion = Program.cn;
                    txtCI.Text = Convert.ToString(f.ci);


                    switch (f.buscar())
                    {
                        case 0:  //Encontré 
                            Program.existeCI = true;
                            Program.frmFuncionarios = new Funcionarios();
                            abrirFormHijo(Program.frmFuncionarios);
                            Program.frmFuncionarios.lblCI.Text = "CI: " + txtCI.Text;
                            Program.frmFuncionarios.lblTitulo.Text = "Creacíon de Perfil de Funcionario";
                            Program.frmFuncionarios.txtCI.Text = txtCI.Text;
                            Program.frmFuncionarios.txtNombre.Text = f.nombre;
                            Program.frmFuncionarios.cboTelefonos.Items.Clear();
                            foreach (string tel in f.telefonos)
                            {
                                Program.frmFuncionarios.cboTelefonos.Items.Add(tel);
                            }
                            break;
                        case 1: //La conexión está cerrada.
                            MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                            break;
                        case 2:
                        case 4:
                            MessageBox.Show("Hubo errores al efectuar operación");
                            break;
                        case 3: //No encontré
                            Program.existeCI = false;

                            if (CustomMessageBox.Show("Registro no encontrado ¿Desea efectuar el alta?", "¿Alta?", 0) == 0)
                            {
                                Program.frmBackoffice.abrirFormHijo(Program.frmFuncionarios);
                                Program.frmFuncionarios.lblCI.Text = "CI: " + txtCI.Text;
                                Program.frmFuncionarios.txtCI.Text = txtCI.Text;
                            }

                            break;
                    };

                    break;

                case 2: //choferes

                    if (!validaCI(numero(txtCI.Text)))
                    {
                        CustomMessageBox.Show("Cédula inválida", "Error");
                        return;
                    }

                    Program.frmCamioneros = new Camioneros();
                    List<String> telefonos = new List<String>();
                    Camionero c = new Camionero();
                    c.ci = numero(txtCI.Text);
                    c.conexion = Program.cn;
                    txtCI.Text = Convert.ToString(c.ci);
                    Program.frmCamioneros.cboTelefonos.SelectedIndex = -1;

                    switch (c.buscar())
                    {
                        case 0:  //Encontré 
                            Program.existeCI = true;
                            Program.frmCamioneros = new Camioneros();
                            abrirFormHijo(Program.frmCamioneros);
                            MessageBox.Show(Convert.ToString(txtCI.Text));
                            Program.frmCamioneros.lblCI.Text = "CI: " + txtCI.Text;
                            Program.frmCamioneros.lblTitulo.Text = "Modificacion de Choferes";
                            Program.frmCamioneros.txtCI.Text = txtCI.Text;
                            Program.frmCamioneros.txtNombre.Text = c.nombre;
                            Program.frmCamioneros.cboTelefonos.Items.Clear();
                            foreach (string tel in c.telefonos)
                            {
                                Program.frmCamioneros.cboTelefonos.Items.Add(tel);
                            }

                            break;
                        case 1: //La conexión está cerrada.
                            MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                            break;
                        case 2:
                        case 4:
                            MessageBox.Show("Hubo errores al efectuar operación");
                            break;
                        case 3: //No encontré
                            Program.existeCI = false;

                            int respuesta = CustomMessageBox.Show("Registro no encontrado ¿Desea efectuar el alta?", "¿Alta?", 0);
                            if (respuesta == 0)
                            {
                                Program.frmBackoffice.abrirFormHijo(Program.frmCamioneros);

                                Program.frmCamioneros.lblCI.Text = "CI: " + txtCI.Text;
                                Program.frmCamioneros.txtCI.Text = txtCI.Text;

                            }
                            break;
                    };
                    c = null;
                    break;

                case 3: //Camiones

                    Program.frmCamiones = new Camiones();
                    List<String> t = new List<String>();
                    Camion ca = new Camion();
                    if (txtCI.Text != null)
                    {
                        try
                        {
                            ca.Id = int.Parse(txtCI.Text);
                        }
                        catch
                        {
                            CustomMessageBox.Show("Valor no admitido.", "Error");
                            return;
                        }
                    }
                    else
                    {
                        CustomMessageBox.Show("Valor no admitido.", "Error");
                        return;
                    }
                    ca.conexion = Program.cn;

                    switch (ca.buscar())
                    {
                        case 0:  //Encontré 
                            abrirFormHijo(Program.frmCamiones);
                            Program.frmCamiones.lblCI.Text = "ID: " + txtCI.Text;
                            Program.frmCamiones.lblTitulo.Text = "Creacíon de Camion";
                            Program.frmCamiones.txtCI.Text = txtCI.Text;
                            List<String> opciones = new List<String>() { "No", "Si" };
                            foreach (string Opcion in opciones)
                            {
                                Program.frmCamiones.cboSticker.Items.Add(Opcion);
                            }
                            List<String> modelos = new List<String>();
                            ADODB.Recordset rs = new ADODB.Recordset();
                            object filasAfectadas = new object();
                            string sql = "select nombre from modeloCamion";
                            try
                            {
                                rs = Program.cn.Execute(sql, out filasAfectadas);
                            }
                            catch
                            {
                                return;
                            }
                            while (!rs.EOF) //mientras no llegue al fin 
                            {
                                Program.frmCamiones.cboModelo.Items.Add(Convert.ToString(rs.Fields[0].Value));
                                rs.MoveNext();
                            }
                            foreach (string modelo in modelos)
                            {
                                Program.frmCamiones.cboModelo.Items.Add(modelo);
                            }
                            List<String> estadosmantenimiento = new List<String>() { " ", "Necesita mantenimiento", "Disfuncional", "En mantenimiento" };
                            foreach (string estados in estadosmantenimiento)
                            {
                                Program.frmCamiones.cboEstadoMantenimiento.Items.Add(estados);
                            }
                            break;

                        case 1: //La conexión está cerrada.
                            MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                            break;
                        case 2:
                        case 4:
                            MessageBox.Show("Hubo errores al efectuar operación");
                            break;
                        case 3: //No encontré
                            Program.existeCI = false;

                            switch (Program.idioma)
                            {
                                case 0:
                                    int respuesta = CustomMessageBox.Show("Registro no encontrado ¿Desea efectuar el alta?", "Registro no encontrado", 0);
                                    if (respuesta == 0)
                                    {
                                        Program.frmBackoffice.abrirFormHijo(Program.frmCamiones);
                                        Program.frmCamiones.lblCI.Text = "ID: " + txtCI.Text;
                                        Program.frmCamiones.txtCI.Text = txtCI.Text;
                                        List<String> opcionesM = new List<String>() { "No", "Yes" };
                                        foreach (string Opcion in opcionesM)
                                        {
                                            Program.frmCamiones.cboSticker.Items.Add(Opcion);
                                        }
                                        List<String> modelosM = new List<String>() { " ", "Cascadia", "114SD", "Cascadia Clásica", "Daimler Truck GenH2", "MAN TGX", "Volvo FH" };
                                        foreach (string modelo in modelosM)
                                        {
                                            Program.frmCamiones.cboModelo.Items.Add(modelo);
                                        }
                                        List<String> estadosmantenimientoM = new List<String>() { " ", "Funcional", "Necesita mantenimiento", "Disfuncional", "En mantenimiento" };
                                        foreach (string estados in estadosmantenimientoM)
                                        {
                                            Program.frmCamiones.cboEstadoMantenimiento.Items.Add(estados);
                                        }
                                    }
                                    return;
                                case 1:
                                    respuesta = CustomMessageBox.Show("Register not found. Would you like to add it right now?", "Register not found", 0);
                                    if (respuesta == 0)
                                    {
                                        Program.frmBackoffice.abrirFormHijo(Program.frmCamiones);
                                        Program.frmCamiones.lblCI.Text = "ID: " + txtCI.Text;
                                        Program.frmCamiones.txtCI.Text = txtCI.Text;
                                        List<String> opcionesM = new List<String>() { "No", "Yes" };
                                        foreach (string Opcion in opcionesM)
                                        {
                                            Program.frmCamiones.cboSticker.Items.Add(Opcion);
                                        }
                                        List<String> modelosM = new List<String>() { " ", "Cascadia", "114SD", "Cascadia Clásica", "Daimler Truck GenH2", "MAN TGX", "Volvo FH" };
                                        foreach (string modelo in modelosM)
                                        {
                                            Program.frmCamiones.cboModelo.Items.Add(modelo);
                                        }
                                        List<String> estadosmantenimientoM = new List<String>() { " ", "Funcional", "Necesita mantenimiento", "Disfuncional", "En mantenimiento" };
                                        foreach (string estados in estadosmantenimientoM)
                                        {
                                            Program.frmCamiones.cboEstadoMantenimiento.Items.Add(estados);
                                        }
                                    }
                                    return;
                            }
                            break;
                    };
                    ca = null;
                    //Esto no va a andar hasta que se arregle (o más bien termine) la clase camión
                    break;

                case 4: //Producto

                    Producto p = new Producto();
                    List<String> nombreLugares = new List<String>();
                    if (txtCI.Text != null)
                    {
                        try
                        {
                            p.Id = int.Parse(txtCI.Text);
                        }
                        catch
                        {
                            CustomMessageBox.Show("Valor no admitido.", "Error");
                            return;
                        }
                    }
                    else
                    {
                        CustomMessageBox.Show("Valor no admitido.", "Error");
                        return;
                    }
                    p.conexion = Program.cn;

                    switch (p.buscar())
                    {
                        case 0:  //Encontré 
                            Program.frmProductos = new Productos();
                            p.buscarLugar();
                            abrirFormHijo(Program.frmProductos);
                            Program.frmProductos.lblID.Text = "CI: " + txtCI.Text;
                            Program.frmProductos.lblTitulo.Text = "Creacíon de Producto";
                            Program.frmProductos.txtCI.Text = txtCI.Text;
                            List<String> opcionesF = new List<String>() { "No", "Si" };
                            foreach (string Opcion in opcionesF)
                            {
                                Program.frmProductos.cboFragilidad.Items.Add(Opcion);
                            }
                            List<String> opcionesP = new List<String>() { "No", "Si" };
                            foreach (string Opcion in opcionesP)
                            {
                                Program.frmProductos.cboPrioridad.Items.Add(Opcion);
                            }
                            ActualizarDataGridLugarP(Program.frmProductos);
                            ActualizarDataGridDeposito(Program.frmProductos);
                            break;
                        case 1: //La conexión está cerrada.
                            MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                            break;
                        case 2:
                        case 4:
                            MessageBox.Show("Hubo errores al efectuar operación");
                            break;
                        case 3: //No encontré
                            if (CustomMessageBox.Show("Registro no encontrado ¿Desea efectuar el alta?", "¿Alta?", 0) == 0)
                            {
                                Program.frmBackoffice.abrirFormHijo(Program.frmProductos);
                                Program.frmProductos.lblID.Text = "ID: " + txtCI.Text;
                                p.buscarLugar();
                                Program.frmProductos.txtCI.Text = txtCI.Text;
                                List<String> opcionesF2 = new List<String>() { "No", "Si" };
                                foreach (string Opcion in opcionesF2)
                                {
                                    Program.frmProductos.cboFragilidad.Items.Add(Opcion);
                                }
                                List<String> opcionesP2 = new List<String>() { "No", "Si" };
                                foreach (string Opcion in opcionesP2)
                                {
                                    Program.frmProductos.cboPrioridad.Items.Add(Opcion);
                                }
                                ActualizarDataGridLugarP(Program.frmProductos);
                                ActualizarDataGridDeposito(Program.frmProductos);
                            }
                            break;
                    };
                    break;
                case 5: //Lotes

                    Lote l = new Lote();
                    List<String> nombreDestinos = new List<String>();
                    if (txtCI.Text != null)
                    {
                        try
                        {
                            l.Id = int.Parse(txtCI.Text);
                        }
                        catch
                        {
                            CustomMessageBox.Show("Valor no admitido.", "Error");
                            return;
                        }
                    }
                    else
                    {
                        CustomMessageBox.Show("Valor no admitido.", "Error");
                        return;
                    }
                    l.conexion = Program.cn;

                    switch (l.buscar())
                    {
                        case 0:  //Encontré 
                            Program.frmLotes = new Lotes();
                            abrirFormHijo(Program.frmLotes);
                            Program.frmLotes.lblID.Text = "ID: " + txtCI.Text;
                            Program.frmLotes.txtID.Text = txtCI.Text;
                            Program.frmLotes.lblTitulo.Text = "Creacíon de Lote";
                            List<String> opcionesF = new List<String>() { "No", "Si" };
                            foreach (string Opcion in opcionesF)
                            {
                                Program.frmLotes.cboPrioridad.Items.Add(Opcion);
                            }
                            ActualizarDataGridDepositoL(Program.frmLotes);
                            ActualizarDataGridLugarL(Program.frmLotes);
                            ActualizarDataGridProducto(Program.frmLotes);
                            break;
                        case 1: //La conexión está cerrada.
                            MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                            break;
                        case 2:
                        case 4:
                            MessageBox.Show("Hubo errores al efectuar operación");
                            break;
                        case 3: //No encontré
                            if (CustomMessageBox.Show("Registro no encontrado ¿Desea efectuar el alta?", "¿Alta?", 0) == 0)
                            {
                                Program.frmBackoffice.abrirFormHijo(Program.frmLotes);
                                Program.frmLotes.lblID.Text = "ID: " + txtCI.Text;
                                Program.frmLotes.dgvProductos.Visible = false;
                                List<String> opcionesF2 = new List<String>() { "No", "Si" };
                                foreach (string Opcion in opcionesF2)
                                {
                                    Program.frmLotes.cboPrioridad.Items.Add(Opcion);
                                }
                            }else
                            {
                                return;
                            }
                            ActualizarDataGridDepositoL(Program.frmLotes);
                            ActualizarDataGridLugarL(Program.frmLotes);
                            break;
                    };
                    break;
                case 6: //Depositos

                    Deposito d = new Deposito();

                    List<String> nombreLugar = new List<String>();
                    List<String> departamentoLugar = new List<String>();
                    if (txtCI.Text != null)
                    {
                        try
                        {
                            d.IdDeposito = int.Parse(txtCI.Text);
                        }
                        catch
                        {
                            CustomMessageBox.Show("Valor no admitido.", "Error");
                            return;
                        }
                    }
                    else
                    {
                        CustomMessageBox.Show("Valor no admitido.", "Error");
                        return;
                    }
                    d.conexion = Program.cn;

                    switch (d.buscar())
                    {
                        case 0:  //Encontré 
                            Program.frmDepositos = new Depositos();
                            d.buscarLugaryDepartamento();
                            abrirFormHijo(Program.frmDepositos);
                            Program.frmDepositos.lblID.Text = "ID: " + txtCI.Text;
                            Program.frmDepositos.lblTitulo.Text = "Registro de Depósito";
                            Program.frmDepositos.txtCI.Text = txtCI.Text;
                            ActualizarDataGridLugar(Program.frmDepositos);
                            break;
                        case 1: //La conexión está cerrada.
                            MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                            break;
                        case 2:
                        case 4:
                            MessageBox.Show("Hubo errores al efectuar operación");
                            break;
                        case 3: //No encontré
                            if (CustomMessageBox.Show("Registro no encontrado ¿Desea efectuar el alta?", "¿Alta?", 0) == 0)
                            {
                                Program.frmBackoffice.abrirFormHijo(Program.frmDepositos);
                                Program.frmDepositos.lblID.Text = "ID: " + txtCI.Text;
                                d.buscarLugaryDepartamento();
                                Program.frmDepositos.txtCI.Text = txtCI.Text;
                                
                                ActualizarDataGridLugar(Program.frmDepositos);
                            }
                            break;
                    };

                    break;
            }
        }

        private void btnCerrarSesion_Click(object sender, EventArgs e) //Cerrar sesion
        {
            if (Program.cn.State == 1) //si la conexion esta abierta
            {
                int respuesta;
                switch (Program.idioma)
                {
                    case 0:
                        respuesta = CustomMessageBox.Show("¿Desea cerrar sesión?", "Cerrar sesión", 1);
                        if (respuesta == 0)
                        {
                            Program.cn.Close();
                            Program.frmLogin = new Login();
                            Hide();
                            Program.frmLogin.ShowDialog();
                            Dispose();
                            //Close();
                        }
                        return;
                    case 1:
                        respuesta = CustomMessageBox.Show("Do you want to log out?", "Log out", 1);
                        if (respuesta == 0)
                        {
                            Program.cn.Close();
                            Program.frmLogin = new Login();
                            Hide();
                            Program.frmLogin.ShowDialog();
                            Dispose();
                            //Close();
                        }
                        return;
                }
                //int respuesta = CustomMessageBox.Show("¿Desea cerrar sesión?", "Cerrar sesión", 1);
            }
        }

        public void maximizarPantalla()
        {
            if (WindowState != FormWindowState.Maximized) //Si la ventana no está maximizada...
            {
                WindowState = FormWindowState.Maximized;
            }
            else
            {
                WindowState = FormWindowState.Normal;
            }
        }

        private void btnMax_Click(object sender, EventArgs e) //Maximizar pantalla
        {
            maximizarPantalla();
        }

        private void pnlBarraTitulo_DoubleClick(object sender, EventArgs e) //Otra forma de maximizar la pantalla más práctica
        {
            maximizarPantalla();
        }

        private void btnMin_Click(object sender, EventArgs e) //Minimizar pantalla
        {
            WindowState = FormWindowState.Minimized;
        }


        private void btnCerrar_Click(object sender, EventArgs e) //Cerrar aplicación
        {
            int respuesta;
            switch (Program.idioma)
            {
                case 0:
                    respuesta = CustomMessageBox.Show("¿Está seguro que desea salir de la aplicación?", "Saliendo de WingMaster", 1);
                    if (respuesta == 0)
                    {
                        Program.cn.Close();
                        this.Close();
                    }
                    return;
                case 1:
                    respuesta = CustomMessageBox.Show("Are you sure you want to exit the application?", "Exiting WingMaster", 1);
                    if (respuesta == 0)
                    {
                        Program.cn.Close();
                        this.Close();
                    }
                    return;
            }
        }

        private void tmrFadeIn_Tick(object sender, EventArgs e) //Animación de entrada del formulario
        {
            if (Opacity == 1)
            {
                tmrFadeIn.Stop();
            }
            Opacity += .17; //Marca la velocidad en la que el formulario entra
        }

        private void txtCI_Enter(object sender, EventArgs e) //para borrar el texto placeholder al hacer click y resaltar el texto en blanco más claro 
        {
            txtCI.ForeColor = Color.White;
            if (_txtCiIntacto)
            {
                txtCI.Text = "";
                _txtCiIntacto = false;
            }
        }

        private void txtNombre_Enter(object sender, EventArgs e) //para borrar el texto placeholder al hacer click y resaltar el texto en blanco más claro 
        {
            txtCI.ForeColor = Color.FromArgb(80, 80, 95);

            if (_txtNombreIntacto)
            {
                _txtNombreIntacto = false;
            }
        }

        private void btnFuncionarios_Click(object sender, EventArgs e)
        {
            actualizarPantalla(1);

        }

        private void btnCamioneros_Click(object sender, EventArgs e)
        {
            actualizarPantalla(2);
        }

        private void btnCamiones_Click(object sender, EventArgs e)
        {
            actualizarPantalla(3);
        }

        private void btnProductos_Click(object sender, EventArgs e)
        {
            actualizarPantalla(4);
        }

        private void btnLotes_Click(object sender, EventArgs e)
        {
            actualizarPantalla(5);
        }

        private void btnDepositos_Click(object sender, EventArgs e)
        {
            actualizarPantalla(6);
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {

            switch (categoriaMenuActual)
            {

                case 1: //funcionarios

                    if (!validaCI(numero(txtCI.Text)))
                    {
                        CustomMessageBox.Show("Cédula inválida", "Error");
                        return;
                    }

                    Funcionario f = new Funcionario();
                    List<String> telefonosF = new List<String>();
                    f.ci = numero(txtCI.Text);
                    f.conexion = Program.cn;
                    txtCI.Text = Convert.ToString(f.ci);
                    switch (f.buscar())
                    {
                        case 0:  //Encontré 
                            f.Eliminar();
                            switch (Program.idioma)
                            {
                                case 0:
                                    CustomMessageBox.Show("Funcionario eliminado exitosamente.", "Mensaje");
                                    break;
                                case 1:
                                    CustomMessageBox.Show("Clerk successfully deleted.", "Message");
                                    break;
                            }
                            Program.frmBackoffice.actualizarPantalla(1);
                            break;
                        case 1: //La conexión está cerrada.
                            MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                            break;
                        case 2:
                        case 4:
                            switch (Program.idioma)
                            {
                                case 0:
                                    CustomMessageBox.Show("Hubo errores al efectuar operación", "Error");
                                    break;
                                case 1:
                                    CustomMessageBox.Show("There seems to be a problem.", "Error");
                                    break;
                            }
                            break;
                        case 3: //No encontré
                            Program.existeCI = false;

                            switch (Program.idioma)
                            {
                                case 0:
                                    CustomMessageBox.Show("El funcionario no existe en el sistema", "Error");
                                    break;
                                case 1:
                                    CustomMessageBox.Show("Clerk does not exist.", "Error");
                                    break;
                            }
                            return;
                    };
                    f = null;
                    break;
      
                case 2: //Camioneros

                    if (!validaCI(numero(txtCI.Text)))
                    {
                        CustomMessageBox.Show("Cédula inválida", "Error");
                        return;
                    }

                    Program.frmCamioneros = new Camioneros();
                    List<String> telefonos = new List<String>();
                    Camionero c = new Camionero();
                    c.ci = numero(txtCI.Text);
                    c.conexion = Program.cn;
                    txtCI.Text = Convert.ToString(c.ci);

                    switch (c.buscar())
                    {
                        case 0:  //Encontré 
                            c.Eliminar();
                            Program.frmBackoffice.actualizarPantalla(2);
                            MessageBox.Show("Camionero eliminado exitosamente.");
                            c = null;
                            break;
                        case 1: //La conexión está cerrada.
                            MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                            break;
                        case 2:
                        case 4:
                            MessageBox.Show("Hubo errores al efectuar operación");
                            break;
                        case 3: //No encontré
                            Program.existeCI = false;

                            CustomMessageBox.Show("La cédula no existe en el sistema", "Error");
                            return;
                    };
                    c = null;
                    break;
                case 3: //Camiones

                    Program.frmCamiones = new Camiones();
                    Camion ca = new Camion();
                    ca.Id = numero(txtCI.Text);
                    ca.conexion = Program.cn;
                    txtCI.Text = Convert.ToString(ca.Id);

                    switch (ca.buscar())
                    {
                        case 0:  //Encontré 
                            switch(ca.Eliminar())
                            {

                                case 0:
                                    CustomMessageBox.Show("Camion eliminado exitosamente.", "Mensaje");
                                    Program.frmBackoffice.actualizarPantalla(2);
                                    break;
                                case 1:
                                    CustomMessageBox.Show("Conexion cerrada", "Error");
                                    break;
                                case 2:
                                     CustomMessageBox.Show("Error al ejecutar consulta", "Error");
                                    break;
                            }
                            Program.frmBackoffice.actualizarPantalla(2);
                            break;
                        case 1: //La conexión está cerrada.
                            MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                            break;
                        case 2:
                        case 4:
                            MessageBox.Show("Hubo errores al efectuar operación");
                            break;
                        case 3: //No encontré
                            Program.existeCI = false;

                            CustomMessageBox.Show("El camión no existe en el sistema", "Error");
                            return;
                    };
                    c = null;
                    break;
                case 4: //Camioneros

                    Program.frmProductos = new Productos();
                    Producto p = new Producto();
                    p.Id = int.Parse(txtCI.Text);
                    p.conexion = Program.cn;

                    switch (p.buscar())
                    {
                        case 0:  //Encontré 
                            p.EliminarProducto();
                            Program.frmBackoffice.actualizarPantalla(4);
                            switch (Program.idioma)
                            {
                                case 0:
                                    CustomMessageBox.Show("Producto eliminado exitosamente.", "Error");
                                    break;
                                case 1:
                                    CustomMessageBox.Show("Package successfully deleted.", "Error");
                                    break;
                            }
                            c = null;
                            break;
                        case 1: //La conexión está cerrada.
                            MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                            break;
                        case 2:
                        case 4:
                            MessageBox.Show("Hubo errores al efectuar operación");
                            break;
                        case 3: //No encontré
                            Program.existeCI = false;

                            CustomMessageBox.Show("El Producto no existe en el sistema", "Error");
                            return;
                    };
                    c = null;
                    break;
                case 5: //Lotes

                    Program.frmLotes = new Lotes();
                    Lote l = new Lote();
                    l.Id = int.Parse(txtCI.Text);
                    l.conexion = Program.cn;

                    switch (l.buscar())
                    {
                        case 0:  //Encontré 
                            l.EliminarLote();
                            Program.frmBackoffice.actualizarPantalla(4);
                            CustomMessageBox.Show("Lote eliminado exitosamente.", "Mensaje");
                            l = null;
                            break;
                        case 1: //La conexión está cerrada.
                            MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                            break;
                        case 2:
                        case 4:
                            MessageBox.Show("Hubo errores al efectuar operación");
                            break;
                        case 3: //No encontré
                            Program.existeCI = false;

                            CustomMessageBox.Show("El Producto no existe en el sistema", "Error");
                            return;
                    };
                    l = null;
                    break;
                case 6: //Deposito

                    Program.frmDepositos = new Depositos();
                    Deposito d = new Deposito();
                    d.IdDeposito = numero(txtCI.Text);
                    d.conexion = Program.cn;
                    txtCI.Text = Convert.ToString(d.IdDeposito);

                    switch (d.buscar())
                    {
                        case 0:  //Encontré 
                            switch (d.EliminarDeposito())
                            {

                                case 0:
                                    CustomMessageBox.Show("Deposito eliminado exitosamente.", "Mensaje");
                                    Program.frmBackoffice.actualizarPantalla(2);
                                    break;
                                case 1:
                                    CustomMessageBox.Show("Conexion cerrada", "Error");
                                    break;
                                case 2:
                                    CustomMessageBox.Show("Error al ejecutar consulta", "Error");
                                    break;
                            }
                            Program.frmBackoffice.actualizarPantalla(2);
                            break;
                        case 1: //La conexión está cerrada.
                            MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                            break;
                        case 2:
                        case 4:
                            MessageBox.Show("Hubo errores al efectuar operación");
                            break;
                        case 3: //No encontré
                            CustomMessageBox.Show("El Deposito no existe en el sistema", "Error");
                            return;
                    };
                    c = null;
                    break;
            }
        }

        private Form frmActivo = null;

        public void abrirFormHijo(Form frmHijo)
        {
            IsMdiContainer = true;
            /*if (frmActivo != null)
                frmActivo.Close();
            frmHijo = frmActivo; */
            pnlFormHijo.Show();
            pnlFormHijo.Dock = DockStyle.Fill;
            switch (categoriaMenuActual)
            {
                case 1:
                    Program.frmFuncionarios = new Funcionarios();
                    frmHijo = Program.frmFuncionarios;
                    Program.frmFuncionarios.actualizarTexto();
                    break;
                case 2:
                    Program.frmCamioneros = new Camioneros();
                    frmHijo = Program.frmCamioneros;
                    Program.frmCamioneros.actualizarTexto();
                    break;
                case 3:
                    Program.frmCamiones = new Camiones();
                    frmHijo = Program.frmCamiones;
                    Program.frmCamiones.actualizarTexto();

                    break;
                case 4:
                    Program.frmProductos = new Productos();
                    frmHijo = Program.frmProductos;
                    Program.frmProductos.actualizarTexto();
                    break;
                case 5:
                    Program.frmLotes = new Lotes();
                    frmHijo = Program.frmLotes;
                    Program.frmLotes.actualizarTexto();
                    break;
                case 6:
                    Program.frmDepositos = new Depositos();
                    frmHijo = Program.frmDepositos;
                    Program.frmDepositos.actualizarTexto();
                    break;
            }
            //MessageBox.Show(Convert.ToString(categoriaMenuActual));
            btnAgregar.Hide();
            btnEliminar.Hide();
            dgvResultados.Hide();
            pnl_lupita.Hide();
            pnlLateralL.Hide();
            pnlLateralR.Hide();
            txtCI.Hide();
            lblError.Hide();

            frmHijo.MdiParent = this;
            frmHijo.TopLevel = false;
            frmHijo.Dock = DockStyle.Fill;
            pnlFormHijo.Show();
            pnlFormHijo.Controls.Add(frmHijo);
            pnlFormHijo.Tag = frmHijo;
            frmHijo.BringToFront();
            frmHijo.Show();
        }
        private void pnlLogoPhoenix_Click(object sender, EventArgs e)
        {
            actualizarPantalla(0);
        }

        public void actualizarDataGrid()
        {
            String sql;
            DataTable dt = new DataTable();
            switch (categoriaMenuActual)
            {
                case 1: //Funcionario
                    sql = "SELECT e.ci as CI, e.nombre as Nombre, e.apellidos as Apellidos, e.fechaContratado as FechaContratado, e.certificadoMedico as CertificadoMedico, e.certificadoBuenaConducta as CertBuenaConducta, e.ubicadoEn as Deposito, et.telefonos as Telefono FROM empleado e JOIN empleado_telefonos et ON e.ci = et.empleado where e.ci like '" + txtCI.Text + "%' AND e.ci NOT IN (SELECT ci FROM chofer)";
                    break;
                case 2: //Camionero
                    sql = "SELECT e.ci as CI, e.nombre as Nombre, e.apellidos as Apellidos, e.fechaContratado as FechaContratado, e.certificadoMedico as CertificadoMedico, e.certificadoBuenaConducta as CertBuenaConducta, e.ubicadoEn as Deposito, et.telefonos as Telefono, ch.expiracionLicencia as ExpiracionLicencia, ch.cantEnvios as CantEnvios, ch.enviosTarde as CantEnviosTarde FROM empleado e JOIN empleado_telefonos et ON e.ci = et.empleado JOIN chofer ch ON e.ci = ch.ci where e.ci like '" + txtCI.Text + "%'";
                    break;
                case 3: //Camion
                    sql = "SELECT c.id AS ID, c.matricula AS Matricula, mc.nombre AS Modelo, mc.volMax AS VolMax, mc.tara AS Tara, mc.mma AS MMA, mc.cargaUtil AS CargaUtil, mc.velMax AS VelMax, c.StickerTelepeaje AS StickerTelepeaje, c.seguro AS Seguro, c.patente AS Patente, em.nombre AS EstadoMantenimiento FROM camion c JOIN modeloCamion mc ON c.modelo = mc.id JOIN estadoMantenimiento em ON c.estadoMantenimiento = em.id where c.matricula like '" + txtCI.Text + "%'";
                    break;
                case 4: //Producto
                    sql = "SELECT p.id AS ID, p.nombre AS Nombre, p.descripcion AS Descripcion, p.peso AS Peso, p.volumen AS Volumen, p.fechaLimite AS FechaMax, p.fragilidad AS Fragilidad, p.ubicadoEn AS Ubicacion, l.id AS Lote, p.destino AS Destino, p.prioridad AS Prioridad FROM producto p JOIN productoDentroDeLote pdl ON p.id = pdl.productoDentro JOIN lote l ON pdl.lote = l.id where p.id like '" + txtCI.Text + "%'";
                    break;
                case 5: //Lote
                    sql = "SELECT l.id AS ID, l.fechaLimite AS FechaMaxima, d.nombre AS Deposito, cl.camion AS Camion, lu.nombre AS Destino, l.prioridad AS Prioridad FROM lote l LEFT JOIN loteAlmacenadoEn lae ON l.id = lae.lote LEFT JOIN camionLleva cl ON l.id = cl.lote LEFT JOIN lugar lu ON l.destino = lu.id LEFT JOIN deposito d ON lae.deposito = d.id where l.id like '" + txtCI.Text + "%'";
                    break;
                case 6: //Deposito
                    sql = "SELECT e.ci as CI, e.nombre as Nombre, e.apellidos as Apellidos, e.fechaContratado as FechaContratado, e.certificadoMedico as CertificadoMedico, e.certificadoBuenaConducta as CertBuenaConducta, e.ubicadoEn as Deposito, et.telefonos as Telefono, ch.expiracionLicencia as ExpiracionLicencia, ch.cantEnvios as CantEnvios, ch.enviosTarde as CantEnviosTarde FROM empleado e JOIN empleado_telefonos et ON e.ci = et.empleado JOIN chofer ch ON e.ci = ch.ci where l.id like '" + txtCI.Text + "%'";
                    break;
                default: sql = null;
                    break;
                    }
                    if (Program.cn.State == 1) // Si la conexión está abierta
                    {
                        ADODB.Recordset rs = new ADODB.Recordset();
                        object filasAfectadas = new object();
                        rs = Program.cn.Execute(sql, out filasAfectadas);
                        OleDbDataAdapter da = new OleDbDataAdapter(); dgvResultados.DataSource = null;
                        dgvResultados.Rows.Clear();
                        dgvResultados.Columns.Clear();
                        da.Fill(dt, rs);
                        dgvResultados.DataSource = dt;
                        rs = null;
                        filasAfectadas = null;
                        return;
                    }

                    // Asigna los datos al DataGridView solo si aún no tiene un origen de datos
                    if (dgvResultados.DataSource == null)
                    {
                        dgvResultados.DataSource = dt;
                    }

                    dgvResultados.DataSource = null;
        
        
        }
        
        public void ActualizarDataGridDepositos()
        {
            String sql = "select * from deposito";
            DataTable dt = new DataTable();

            try
            {
                if (Program.cn.State == 1) // Si la conexión está abierta
                {
                    ADODB.Recordset rs = Program.cn.Execute(sql, out object filasAfectadas);
                    OleDbDataAdapter da = new OleDbDataAdapter();
                    da.Fill(dt, rs);
                    rs = null;
                }

                // Asigna los datos al DataGridView solo si aún no tiene un origen de datos
                if (dgvResultados.DataSource == null)
                {
                    dgvResultados.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                // Maneja la excepción según tus necesidades
                MessageBox.Show("Error al cargar datos: " + ex.Message);
            }
        }
        public void ActualizarDataGridLugar(Depositos frmDepositos)
        {
            String sql = "select id, nombre from lugar";
            DataTable dt = new DataTable();

            try
            {
                if (Program.cn.State == 1) // Si la conexión está abierta
                {
                    ADODB.Recordset rs = Program.cn.Execute(sql, out object filasAfectadas);
                    OleDbDataAdapter da = new OleDbDataAdapter();
                    da.Fill(dt, rs);
                    rs = null;
                }

                // Asigna los datos al DataGridView solo si aún no tiene un origen de datos
                if (frmDepositos.dgvLugar.DataSource == null)
                {
                    frmDepositos.dgvLugar.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                // Maneja la excepción según tus necesidades
                MessageBox.Show("Error al cargar datos: " + ex.Message);
            }
        }
        public void ActualizarDataGridLugarP(Productos frmProductos)
        {
            String sql = "select id, nombre from lugar";
            DataTable dt = new DataTable();

            try
            {
                if (Program.cn.State == 1) // Si la conexión está abierta
                {
                    ADODB.Recordset rs = Program.cn.Execute(sql, out object filasAfectadas);
                    OleDbDataAdapter da = new OleDbDataAdapter();
                    da.Fill(dt, rs);
                    rs = null;
                }

                // Asigna los datos al DataGridView solo si aún no tiene un origen de datos
                if (frmProductos.dgvDestino.DataSource == null)
                {
                    frmProductos.dgvDestino.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                // Maneja la excepción según tus necesidades
                MessageBox.Show("Error al cargar datos: " + ex.Message);
            }
        }
        public void ActualizarDataGridLugarL(Lotes frmLotes)
        {
            String sql = "select id, nombre from lugar";
            DataTable dt = new DataTable();

            try
            {
                if (Program.cn.State == 1) // Si la conexión está abierta
                {
                    ADODB.Recordset rs = Program.cn.Execute(sql, out object filasAfectadas);
                    OleDbDataAdapter da = new OleDbDataAdapter();
                    da.Fill(dt, rs);
                    rs = null;
                }

                // Asigna los datos al DataGridView solo si aún no tiene un origen de datos
                if (frmLotes.dgvDestino.DataSource == null)
                {
                    frmLotes.dgvDestino.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                // Maneja la excepción según tus necesidades
                MessageBox.Show("Error al cargar datos: " + ex.Message);
            }
        }
        public void ActualizarDataGridProducto(Lotes frmLotes)
        {
            String sql = "select id, nombre, destino from producto";
            DataTable dt = new DataTable();

            try
            {
                if (Program.cn.State == 1) // Si la conexión está abierta
                {
                    ADODB.Recordset rs = Program.cn.Execute(sql, out object filasAfectadas);
                    OleDbDataAdapter da = new OleDbDataAdapter();
                    da.Fill(dt, rs);
                    rs = null;
                }

                // Asigna los datos al DataGridView solo si aún no tiene un origen de datos
                if (frmLotes.dgvProductos.DataSource == null)
                {
                    frmLotes.dgvProductos.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                // Maneja la excepción según tus necesidades
                MessageBox.Show("Error al cargar datos: " + ex.Message);
            }
        }
        public void ActualizarDataGridDeposito(Productos frmProductos)
        {
            String sql = "select id, nombre, localizacion from deposito";
            DataTable dt = new DataTable();

            try
            {
                if (Program.cn.State == 1) // Si la conexión está abierta
                {
                    ADODB.Recordset rs = Program.cn.Execute(sql, out object filasAfectadas);
                    OleDbDataAdapter da = new OleDbDataAdapter();
                    da.Fill(dt, rs);
                    rs = null;
                }

                // Asigna los datos al DataGridView solo si aún no tiene un origen de datos
                if (frmProductos.dgvDepositos.DataSource == null)
                {
                    frmProductos.dgvDepositos.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                // Maneja la excepción según tus necesidades
                MessageBox.Show("Error al cargar datos: " + ex.Message);
            }
        }
        public void ActualizarDataGridDepositoL(Lotes frmLotes)
        {
            String sql = "select id, nombre, localizacion from deposito";
            DataTable dt = new DataTable();

            try
            {
                if (Program.cn.State == 1) // Si la conexión está abierta
                {
                    ADODB.Recordset rs = Program.cn.Execute(sql, out object filasAfectadas);
                    OleDbDataAdapter da = new OleDbDataAdapter();
                    da.Fill(dt, rs);
                    rs = null;
                }

                // Asigna los datos al DataGridView solo si aún no tiene un origen de datos
                if (frmLotes.dgvDepositos.DataSource == null)
                {
                    frmLotes.dgvDepositos.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                // Maneja la excepción según tus necesidades
                MessageBox.Show("Error al cargar datos: " + ex.Message);
            }
        }
       
        private void txtCI_KeyUp(object sender, KeyEventArgs e)
        {
            //if (txtCI.Text.Length = 0) //Comienza a tomar efecto despues del tercer digito para no sobrecargar la busqueda cuando todavia hay muchos registros
            //{
                actualizarDataGrid();
            //}
        }


        //para mover el forms por el label

        private bool _dragging = false;
        private Point _offset;
        private Point _start_point = new Point(0, 0);

        private void pnlBarraTitulo_MouseDown(object sender, MouseEventArgs e)
        {
            _dragging = true;
            _start_point = new Point(e.X, e.Y);
        }

        private void pnlBarraTitulo_MouseMove(object sender, MouseEventArgs e)
        {
            if (_dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this._start_point.X, p.Y - this._start_point.Y);
            }
        }

        private void pnlBarraTitulo_MouseUp(object sender, MouseEventArgs e)
        {
            _dragging = false;
        }

        private void btnPreferencias_Click(object sender, EventArgs e)
        {
            Preferencias frmPreferencias = new Preferencias();
            frmPreferencias.Show();
        }

        public void actualizarTexto()
        {
            switch (Program.idioma)
            {
                case 0:
                    lblBienvenido.Text = "Bienvenido/a, ";
                    btnFuncionarios.Text = "Funcionarios";
                    btnCamioneros.Text = "Camioneros";
                    btnCamiones.Text = "Camiones";
                    btnProductos.Text = "Productos";
                    btnLotes.Text = "Lotes";
                    btnDepositos.Text = "Depósitos";
                    btnCerrarSesion.Text = "Cerrar sesión";
                    pnlCreditos.Text = "desarrollado por";
                    break;
                case 1:
                    lblBienvenido.Text = "Welcome";
                    btnFuncionarios.Text = "Clerks";
                    btnCamioneros.Text = "Drivers";
                    btnCamiones.Text = "Trucks";
                    btnProductos.Text = "Packages";
                    btnLotes.Text = "Batches";
                    btnDepositos.Text = "Warehouses";
                    btnCerrarSesion.Text = "Log out";
                    pnlCreditos.Text = "developed by";
                    break;
                default:
                    lblBienvenido.Text = "Bienvenido/a, ";
                    btnFuncionarios.Text = "Funcionarios";
                    btnCamioneros.Text = "Camioneros";
                    btnCamiones.Text = "Camiones";
                    btnProductos.Text = "Productos";
                    btnLotes.Text = "Lotes";
                    btnDepositos.Text = "Depósitos";
                    btnCerrarSesion.Text = "Cerrar sesión";
                    pnlCreditos.Text = "desarrollado por";
                    break;
            }
        }
        public void actualizarTextoCategoria(int categoria)
        {
            switch (categoriaMenuActual)
            {
                case 0: //Ninguna categoría seleccionada / Pantalla inicial
                    return;
                case 1: //Categoría Funcionarios seleccionada
                    switch (Program.idioma)
                    {
                        case 0:
                            btnAgregar.Text = "Cambiar/Agregar Funcionario";
                            txtCI.Text = "Buscar CI de Funcionario...";
                            btnEliminar.Text = "Eliminar Funcionario";
                            break;
                        case 1:
                            btnAgregar.Text = "Modify/Add Clerk";
                            txtCI.Text = "Search in Clerk by ID...";
                            btnEliminar.Text = "Delete Clerk";
                            break;
                        default:
                            btnAgregar.Text = "Cambiar/Agregar Funcionario";
                            txtCI.Text = "Buscar CI de Funcionario...";
                            btnEliminar.Text = "Eliminar Funcionario";
                            break;
                    }
                    break;
                case 2: //Categoría Camioneros seleccionada
                    switch (Program.idioma)
                    {
                        case 0:
                            btnAgregar.Text = "Cambiar/Agregar Camionero";
                            txtCI.Text = "Buscar CI de Camionero...";
                            btnEliminar.Text = "Eliminar Camionero";
                            break;
                        case 1:
                            btnAgregar.Text = "Modify/Add Driver";
                            txtCI.Text = "Search in Drivers by ID...";
                            btnEliminar.Text = "Delete Driver";
                            break;
                        default:
                            btnAgregar.Text = "Cambiar/Agregar Camionero";
                            txtCI.Text = "Buscar CI de Camionero...";
                            btnEliminar.Text = "Eliminar Camionero";
                            break;
                    }
                    break;
                case 3: //Categoría Camiones seleccionada
                    switch (Program.idioma)
                    {
                        case 0:
                            btnAgregar.Text = "Cambiar/Agregar Camión";
                            txtCI.Text = "Buscar ID de Camión...";
                            btnEliminar.Text = "Eliminar Camión";
                            break;
                        case 1:
                            btnAgregar.Text = "Modify/Add Truck";
                            txtCI.Text = "Search in Trucks by ID...";
                            btnEliminar.Text = "Delete Truck";
                            break;
                        default:
                            btnAgregar.Text = "Cambiar/Agregar Camión";
                            txtCI.Text = "Buscar ID de Camión...";
                            btnEliminar.Text = "Eliminar Camión";
                            break;
                    }
                    break;
                case 4: //Categoría Productos seleccionada
                    switch (Program.idioma)
                    {
                        case 0:
                            btnAgregar.Text = "Cambiar/Agregar Producto";
                            txtCI.Text = "Buscar ID de Producto...";
                            btnEliminar.Text = "Eliminar Producto";
                            break;
                        case 1:
                            btnAgregar.Text = "Modify/Add Package";
                            txtCI.Text = "Search in Packages by ID...";
                            btnEliminar.Text = "Delete Package";
                            break;
                        default:
                            btnAgregar.Text = "Cambiar/Agregar Producto";
                            txtCI.Text = "Buscar ID de Producto...";
                            btnEliminar.Text = "Eliminar Producto";
                            break;
                    }
                    break;
                case 5: //Categoría Lotes seleccionada
                    switch (Program.idioma)
                    {
                        case 0:
                            btnAgregar.Text = "Cambiar/Agregar Lote";
                            txtCI.Text = "Buscar ID de Lote...";
                            btnEliminar.Text = "Eliminar Lote";
                            break;
                        case 1:
                            btnAgregar.Text = "Modify/Add Package";
                            txtCI.Text = "Search in Packages by ID...";
                            btnEliminar.Text = "Delete Package";
                            break;
                        default:
                            btnAgregar.Text = "Cambiar/Agregar Lote";
                            txtCI.Text = "Buscar ID de Lote...";
                            btnEliminar.Text = "Eliminar Lote";
                            break;
                    }
                    break;
                case 6: //Categoría Depósitos seleccionada
                    switch (Program.idioma)
                    {
                        case 0:
                            btnAgregar.Text = "Cambiar/Agregar Depósito";
                            txtCI.Text = "Buscar ID de Depósito...";
                            btnEliminar.Text = "Eliminar Depósito";
                            break;
                        case 1:
                            btnAgregar.Text = "Modify/Add Warehouses";
                            txtCI.Text = "Search in Warehouses by ID...";
                            btnEliminar.Text = "Delete Warehouses";
                            break;
                        default:
                            btnAgregar.Text = "Cambiar/Agregar Depósito";
                            txtCI.Text = "Buscar ID de Depósito...";
                            btnEliminar.Text = "Eliminar Depósito";
                            break;
                    }
                    break;
            } 
        }

        private void dgvResultados_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvResultados.CurrentCell != null && dgvResultados.CurrentCell.Value != null)
            {
                // Convert the value of the current cell to a string
                txtCI.Text = dgvResultados.CurrentRow.Cells[0].Value.ToString();

            }
            //dgvResultados.CurrentCell = dgvResultados.Rows[1].Cells[1];
            //txtCI.Text = dgvResultados.CurrentCell;
        }
    }
}





