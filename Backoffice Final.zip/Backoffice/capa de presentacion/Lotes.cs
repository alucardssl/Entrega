﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Backoffice.capa_de_negocios;

namespace Backoffice.capa_de_presentacion
{
    public partial class Lotes : Form
    {
        public Lotes()
        {
            InitializeComponent();
        }

        private void btnCrear_Click(object sender, EventArgs e)
        {
            Lote l = new Lote();
            l.ubicacion = cboUbicacion.Text;
            l.destino = cboDestinos.Text;
            l.FechaLimite = dtpFechaLimite.Value;
            l.prioridad = cboPrioridad.SelectedIndex;
            l.conexion = Program.cn;

            switch (l.CrearLote())
            {
                case 0:  //Se pudo efectuar el alta o modificación sin problemas.
                    PopUp frmPopup = new PopUp();
                    Program.frmBackoffice.actualizarPantalla(5);
                    frmPopup.lblPopUp.Text = "Lote creado exitosamente";
                    frmPopup.pnlMensaje.BackColor = Color.MediumSeaGreen;
                    frmPopup.Show();
                    this.Close();
                    break;
                case 1: //La conexión está cerrada.
                    MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                    break;
                case 2:
                    MessageBox.Show("2");
                    break;
                case 3:
                    MessageBox.Show("3");
                    break;
            }
            Program.frmBackoffice.actualizarPantalla(0);
            l = null;
            this.Close();
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            Lote l = new Lote();
            l.Id = int.Parse(txtID.Text);
            l.ubicacion = cboUbicacion.Text;
            l.destino= cboDestinos.Text;
            l.FechaLimite = dtpFechaLimite.Value;
            l.prioridad = cboPrioridad.SelectedIndex;
            l.conexion = Program.cn;

            switch (l.ModificarLote())
            {
                case 0:  //Se pudo efectuar el alta o modificación sin problemas.
                    PopUp frmPopup = new PopUp();
                    Program.frmBackoffice.actualizarPantalla(5);
                    frmPopup.lblPopUp.Text = "Lote modificado exitosamente";
                    frmPopup.pnlMensaje.BackColor = Color.MediumSeaGreen;
                    frmPopup.Show();
                    this.Close();
                    break;
                case 1: //La conexión está cerrada.
                    MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                    break;
                case 2:
                    MessageBox.Show("2");
                    break;
                case 3:
                    MessageBox.Show("3");
                    break;
            }
            Program.frmBackoffice.actualizarPantalla(0);
            l = null;
            this.Close();
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            Program.frmBackoffice.actualizarPantalla(5);
            this.Close();
        }

        private void btnAgregarProducto_Click(object sender, EventArgs e)
        {
            Lote l = new Lote();
            l.Id = int.Parse(txtID.Text);
            l.idProducto = int.Parse(txtProductos.Text);
            l.FechaLimite = dtpFechaLimite.Value;
            l.prioridad = cboPrioridad.SelectedIndex;
            l.conexion = Program.cn;

            switch (l.AgregarProducto())
            {
                case 0:  //Se pudo efectuar el alta o modificación sin problemas.
                    PopUp frmPopup = new PopUp();
                    Program.frmBackoffice.actualizarPantalla(5);
                    frmPopup.lblPopUp.Text = "Producto agregado a lote exitosamente";
                    frmPopup.pnlMensaje.BackColor = Color.MediumSeaGreen;
                    frmPopup.Show();
                    this.Close();
                    Program.frmBackoffice.actualizarPantalla(5);
                    break;
                case 1: //La conexión está cerrada.
                    MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                    break;
                case 2:
                    MessageBox.Show("2");
                    break;
                case 3:
                    MessageBox.Show("3");
                    break;
            }

            l = null;
            this.Close();
        }

        private void btnEliminarProducto_Click(object sender, EventArgs e)
        {
            Program.frmLotes = new Lotes();
            Lote l = new Lote();
            l.idProducto = int.Parse(txtProductos.Text);
            l.Id = int.Parse(txtID.Text);
            l.conexion = Program.cn;

            switch (l.buscar())
            {
                case 0:  //Encontré 
                    l.EliminarProducto();
                    Program.frmBackoffice.actualizarPantalla(5);
                    CustomMessageBox.Show("Producto eliminado exitosamente.", "Mensaje");
                    l = null;
                    break;
                case 1: //La conexión está cerrada.
                    MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                    break;
                case 2:
                case 4:
                    MessageBox.Show("Hubo errores al efectuar operación");
                    break;
                case 3: //No encontré
                    Program.existeCI = false;
                    CustomMessageBox.Show("El Producto no existe en el sistema", "Error");
                    return;
            };
            l = null;
        }
        public void actualizarTexto()
        {
            switch (Program.idioma)
            {
                case 0:
                    lblFechaLim.Text = "Fecha Máxima de Entrega";
                    lblPrioridad.Text = "Prioridad";
                    lblDestino.Text = "Destino";
                    btnCrear.Text = "Guardar";
                    btnVolver.Text = "Cancelar";
                    btnModificar.Text = "Modificar";
                    lblTitulo.Text = "Creación de Lote";
                    lblIDProductos.Text = "ID de Productos";
                    lblUbicacion.Text = "Ubicación";
                    break;
                case 1:
                    lblFechaLim.Text = "Due date";
                    lblPrioridad.Text = "Priority";
                    lblDestino.Text = "Destination";
                    btnCrear.Text = "Save";
                    btnVolver.Text = "Cancel";
                    btnModificar.Text = "Modify";
                    lblTitulo.Text = "Batch Registration";
                    lblIDProductos.Text = "Package ID";
                    lblUbicacion.Text = "Location";
                    break;
            }
        }

        private void Lotes_Load(object sender, EventArgs e)
        {
            List<String> destinos = new List<String>();
            List<String> ubicaciones = new List<String>();
            String sql;
            ADODB.Recordset rs = new ADODB.Recordset();
            object filasAfectadas = new object();
            sql = "select nombre from lugar";
            /*foreach (string d in cboDestinos.Items)
            {
                destinos.Add(d);
            }*/
            try
            {
                rs = Program.cn.Execute(sql, out filasAfectadas);
            }
            catch
            {
                return;
            }
            while (!rs.EOF) //mientras no llegue al fin 
            {
                cboDestinos.Items.Add(Convert.ToString(rs.Fields[0].Value));
                rs.MoveNext();
            }
            try
            {
                rs = Program.cn.Execute(sql, out filasAfectadas);
            }
            catch
            {
                return;
            }
            while (!rs.EOF) //mientras no llegue al fin 
            {
                cboUbicacion.Items.Add(Convert.ToString(rs.Fields[0].Value));
                rs.MoveNext();
            }
        }
    } 
} 
