﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Backoffice.capa_de_negocios;
using System.Data.OleDb;
using Backoffice.capa_de_presentacion;

namespace Backoffice
{
    public partial class Depositos : Form
    {
        public Depositos()
        {
            InitializeComponent();

        }

        private void Almacenes_Load(object sender, EventArgs e)
        {

        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            Program.frmBackoffice = new Backoffice();
            this.Hide();
            Program.frmBackoffice.ShowDialog();
            this.Close();
        }

        private void btnCrear_Click(object sender, EventArgs e)
        {

            Deposito d = new Deposito();
            d.IdLugar = int.Parse(txtUbicacion.Text);
            d.IdDeposito = int.Parse(txtCI.Text);
            d.nombre = txtNombreDeposito.Text;
            d.conexion = Program.cn;

            switch (d.CrearDeposito())
            {
                case 0:  //Se pudo efectuar el alta o modificación sin problemas.
                    PopUp frmPopup = new PopUp();
                    Program.frmBackoffice.actualizarPantalla(6);
                    frmPopup.lblPopUp.Text = "Deposito creado exitosamente";
                    frmPopup.pnlMensaje.BackColor = Color.MediumSeaGreen;
                    frmPopup.Show();
                    this.Close();
                    break;
                case 1: //La conexión está cerrada.
                    MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                    break;
                case 2:
                    MessageBox.Show("2");
                    break;
                case 3:
                    MessageBox.Show("3");
                    break;
            }
            Program.frmBackoffice.actualizarPantalla(0);
            d = null;
            this.Close();
        }
  
        private void btnModificarDeposito_Click(object sender, EventArgs e)
        {
            Program.frmBackoffice = new Backoffice();
            Deposito d = new Deposito();
            d.nombre = txtNombreDeposito.Text;
            d.IdLugar = int.Parse(txtUbicacion.Text);
            d.IdDeposito = int.Parse(txtCI.Text);
            d.conexion = Program.cn;
            if (int.TryParse(txtCI.Text, out int id))
            {
                d.IdDeposito = id;
            }
            else
            {
                Console.WriteLine("Error: El valor de ID no es un número válido.");
            }
            switch (d.ActualizarDeposito())
            {
                case 0:  //Se pudo efectuar el alta o modificación sin problemas.
                    PopUp frmPopup = new PopUp();
                    Program.frmBackoffice.actualizarPantalla(6);
                    frmPopup.lblPopUp.Text = "Deposito modificado exitosamente";
                    frmPopup.pnlMensaje.BackColor = Color.MediumSeaGreen;
                    frmPopup.Show();
                    this.Close();
                    break;
                case 1: //La conexión está cerrada.
                    MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                    break;
                case 2:
                    MessageBox.Show("2");
                    break;
                case 3:
                    MessageBox.Show("3");
                    break;
            }
            Program.frmBackoffice.actualizarPantalla(0);
            d = null;
            this.Close();
        }

       
        private void btnVolver_Click_1(object sender, EventArgs e)
        {
            Program.frmBackoffice.actualizarPantalla(6);
            this.Close();
        }

       
       

        public void actualizarTexto()
        {
            switch (Program.idioma)
            {
                case 0:
                    lblNombre.Text = "Nombre";
                    lblUbicacion.Text = "Ubicación";
                    btnCrear.Text = "Guardar";
                    btnVolver.Text = "Cancelar";
                    btnModificarDeposito.Text = "Modificar Depósito";
                    lblTitulo.Text = "Registro de Depósito";
                    break;
                case 1:
                    lblNombre.Text = "Name";
                    lblUbicacion.Text = "Location";
                    btnCrear.Text = "Save";
                    btnVolver.Text = "Cancel";
                    btnModificarDeposito.Text = "Modify Warehouse";
                    lblTitulo.Text = "Warehouse Registration";
                    break;
            }
        }
    }
}
