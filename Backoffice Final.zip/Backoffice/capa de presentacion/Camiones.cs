﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Backoffice.capa_de_negocios;
using System.Data.OleDb;
namespace Backoffice
{
    public partial class Camiones : Form
    {
        public Camiones()
        {
            InitializeComponent();
            ActualizarDataGridDepositoC();

        }
        public void ActualizarDataGridDepositoC()
        {
            String sql = "select id, nombre, localizacion from deposito";
            DataTable dt = new DataTable();

            try
            {
                if (Program.cn.State == 1) // Si la conexión está abierta
                {
                    ADODB.Recordset rs = Program.cn.Execute(sql, out object filasAfectadas);
                    OleDbDataAdapter da = new OleDbDataAdapter();
                    da.Fill(dt, rs);
                    rs = null;
                }

                // Asigna los datos al DataGridView solo si aún no tiene un origen de datos
                if (dgvDepositos.DataSource == null)
                {
                   dgvDepositos.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                // Maneja la excepción según tus necesidades
                MessageBox.Show("Error al cargar datos: " + ex.Message);
            }
        }
        private void btnCrear_Click(object sender, EventArgs e)
        {
            Camion c = new Camion();
            c.Id = int.Parse(txtCI.Text);
            c.Matricula = txtMatricula.Text;
            c.NombreModelo = cboModelo.SelectedIndex;
            c.StickerTelepeaje = cboSticker.SelectedIndex;
            c.EstadoMantenimiento = cboEstadoMantenimiento.SelectedIndex;
            c.Patente = dtpExpPatente.Text;
            c.Seguro = txtSeguro.Text;
            c.conexion = Program.cn;

            switch (c.Crear())
            {
                case 0:  //Se pudo efectuar el alta o modificación sin problemas.
                    PopUp frmPopup = new PopUp();
                    Program.frmBackoffice.actualizarPantalla(3);
                    frmPopup.lblPopUp.Text = "Camion creado exitosamente";
                    frmPopup.pnlMensaje.BackColor = Color.MediumSeaGreen;
                    frmPopup.Show();
                    this.Close();
                    break;
                case 1: //La conexión está cerrada.
                    MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                    break;
                case 2:
                    MessageBox.Show("2");
                    break;
                case 3:
                    MessageBox.Show("3");
                    break;
            }
            c = null;
            this.Close();
        }

        private void lblSticker_Click(object sender, EventArgs e)
        {

        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            Program.frmBackoffice = new Backoffice();
            Camion c = new Camion();
            c.Matricula = txtMatricula.Text;
            c.NombreModelo = cboModelo.SelectedIndex;
            c.StickerTelepeaje = cboSticker.SelectedIndex;
            c.EstadoMantenimiento = cboEstadoMantenimiento.SelectedIndex;
            c.Patente = dtpExpPatente.Text;
            c.Seguro = txtSeguro.Text;
            c.conexion = Program.cn;
            if (int.TryParse(txtCI.Text, out int id))
            {
                c.Id = id;
            }
            else
            {
                Console.WriteLine("Error: El valor de ID no es un número válido.");
            }
            switch (c.Modificar())
            {
                case 0:  //Se pudo efectuar el alta o modificación sin problemas.
                    PopUp frmPopup = new PopUp();
                    Program.frmBackoffice.actualizarPantalla(2);
                    frmPopup.lblPopUp.Text = "Camionero modificado exitosamente";
                    frmPopup.pnlMensaje.BackColor = Color.MediumSeaGreen;
                    frmPopup.Show();
                    this.Close();
                    break;
                case 1: //La conexión está cerrada.
                    MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                    break;
                case 2:
                    MessageBox.Show("2");
                    break;
                case 3:
                    MessageBox.Show("3");
                    break;
            }
            Program.frmBackoffice.actualizarPantalla(0);
            c = null;
            this.Close();
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            Program.frmBackoffice.actualizarPantalla(3);
            this.Close();
        }

        public void actualizarTexto()
        {
            switch (Program.idioma)
            {
                case 0:
                    lblMatricula.Text = "Matrícula";
                    lblExpPatente.Text = "Fecha de Expiración de Patente";
                    lblSeguro.Text = "Seguro";
                    lblModeloCamion.Text = "Modelo de Camión";
                    lblSticker.Text = "Sticker de Telepeaje";
                    lblEstadoMant.Text = "Estado de Mantenimiento";
                    btnCrear.Text = "Guardar";
                    btnVolver.Text = "Cancelar";
                    btnModificar.Text = "Modificar";
                    lblTitulo.Text = "Registro de Camión";
                    break;
                case 1:
                    lblMatricula.Text = "License Plate";
                    lblExpPatente.Text = "Patente Expiration Date";
                    lblSeguro.Text = "Insurance";
                    lblModeloCamion.Text = "Truck model";
                    lblSticker.Text = "Electronic Tag";
                    lblEstadoMant.Text = "Maintenance State";
                    btnCrear.Text = "Save";
                    btnVolver.Text = "Cancel";
                    btnModificar.Text = "Modify";
                    lblTitulo.Text = "Truck Registration";
                    break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Camion c = new Camion();
            c.IdDeposito = int.Parse(txtIdDeposito.Text);
            c.Id = int.Parse(txtCI.Text);          
            c.conexion = Program.cn;

            switch (c.AsignarDeposito())
            {
                case 0:  //Se pudo efectuar el alta o modificación sin problemas.
                    PopUp frmPopup = new PopUp();
                    Program.frmBackoffice.actualizarPantalla(3);
                    frmPopup.lblPopUp.Text = "Camion agregado a deposito exitosamente";
                    frmPopup.pnlMensaje.BackColor = Color.MediumSeaGreen;
                    frmPopup.Show();
                    this.Close();
                    break;
                case 1: //La conexión está cerrada.
                    MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                    break;
                case 2:
                    MessageBox.Show("2");
                    break;
                case 3:
                    MessageBox.Show("3");
                    break;
            }
            c = null;
            this.Close();
        }
    }
}


