﻿using Backoffice.capa_de_negocios;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace Backoffice
{
    public partial class Funcionarios : Form
    {
        public Funcionarios()
        {
            InitializeComponent();
            ActualizarDataGridDeposito();
        }
          private Int32 numero(String valor)
        {
            Int32 retorno;
            if (!Int32.TryParse(valor, out retorno))
            {
                retorno = 0;
            }
            return (retorno);
        }
        public void ActualizarDataGridDeposito()
        {
            String sql = "select id, nombre, localizacion from deposito";
            DataTable dt = new DataTable();

            try
            {
                if (Program.cn.State == 1) // Si la conexión está abierta
                {
                    ADODB.Recordset rs = Program.cn.Execute(sql, out object filasAfectadas);
                    OleDbDataAdapter da = new OleDbDataAdapter();
                    da.Fill(dt, rs);
                    rs = null;
                }

                // Asigna los datos al DataGridView solo si aún no tiene un origen de datos
                if (dgvDepositos.DataSource == null)
                {
                    dgvDepositos.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                // Maneja la excepción según tus necesidades
                MessageBox.Show("Error al cargar datos: " + ex.Message);
            }
        }
        private void Funcionarios_Load(object sender, EventArgs e)
        {

        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            Program.frmBackoffice = new Backoffice();
            this.Hide();
            Program.frmBackoffice.ShowDialog();
            this.Close();
        }

        private void btnCrear_Click(object sender, EventArgs e)
        {
            List<String> telefonos = new List<String>();
            Funcionario f = new Funcionario();
            f.ci = numero(txtCI.Text);
            f.nombre = txtNombre.Text;
            f.apellidos = txtApellidos.Text;
            f.fechaDeNacimiento = dtpFechaDeNac.Value;
            f.mail = txtMail.Text;
            f.certificadoBuenaConducta = txtCertBuenaConducta.Text;
            f.certificadoMedico = txtCertMed.Text;
            f.direccion = txtDireccion.Text;
            f.fechaContratado = dtpFechaContratado.Value;
            f.conexion = Program.cn;

            foreach (string t in cboTelefonos.Items)
            {
                telefonos.Add(t);
            }
            f.telefonos = telefonos;
            switch (f.Crear())
            {
                case 0:  //Se pudo efectuar el alta o modificación sin problemas.
                    PopUp frmPopup = new PopUp();
                    Program.frmBackoffice.actualizarPantalla(1);
                    frmPopup.lblPopUp.Text = "Funcionario creado exitosamente";
                    frmPopup.pnlMensaje.BackColor = Color.MediumSeaGreen;
                    frmPopup.Show();
                    this.Close();
                    break;
                case 1: //La conexión está cerrada.
                    MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                    break;
                case 2:
                    MessageBox.Show("2");
                    break;
                case 3:
                    MessageBox.Show("3");
                    break;
            }
            Program.frmBackoffice.actualizarPantalla(1);
            f = null;
            this.Close();
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            Program.frmBackoffice = new Backoffice();
            List<String> telefonos = new List<String>();
            Funcionario f = new Funcionario();
            f.ci = numero(txtCI.Text);
            f.nombre = txtNombre.Text;
            f.apellidos = txtApellidos.Text;
            f.fechaDeNacimiento = dtpFechaDeNac.Value;
            f.mail = txtMail.Text;
            f.certificadoBuenaConducta = txtCertBuenaConducta.Text;
            f.certificadoMedico = txtCertMed.Text;
            f.direccion = txtDireccion.Text;
            f.fechaContratado = dtpFechaContratado.Value;       
            f.conexion = Program.cn;

            foreach (string t in cboTelefonos.Items)
            {
                telefonos.Add(t);
            }
            f.telefonos = telefonos;
            switch (f.Modificar())
            {
                case 0:  //Se pudo efectuar el alta o modificación sin problemas.
                    PopUp frmPopup = new PopUp();
                    Program.frmBackoffice.actualizarPantalla(2);
                    frmPopup.lblPopUp.Text = "Funcionario modificado exitosamente";
                    frmPopup.pnlMensaje.BackColor = Color.MediumSeaGreen;
                    frmPopup.Show();
                    this.Close();
                    break;
                case 1: //La conexión está cerrada.
                    MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                    break;
                case 2:
                    MessageBox.Show("2");
                    break;
                case 3:
                    MessageBox.Show("3");
                    break;
            }
            Program.frmBackoffice.actualizarPantalla(0);
            f = null;
            this.Close();
        }

        private void btnAgregarTelefono_Click(object sender, EventArgs e)
        {
            if (cboTelefonos.Items.IndexOf(cboTelefonos.Text) < 0)
            {
                cboTelefonos.Items.Add(cboTelefonos.Text);
                PopUp frmPopup = new PopUp();
                frmPopup.lblPopUp.Text = "Telefono agregado";
                frmPopup.pnlMensaje.BackColor = Color.MediumSeaGreen;
                frmPopup.Show();
            }
            else
            {
                PopUp frmPopup = new PopUp();
                frmPopup.lblPopUp.Text = "El telefono ya existe";
                frmPopup.pnlMensaje.BackColor = Color.Crimson;
                frmPopup.Show();
            }
        }

        private void btnEliminarTelefono_Click(object sender, EventArgs e)
        {
            if (cboTelefonos.Items.IndexOf(cboTelefonos.Text) < 0)
            {
                PopUp frmPopup = new PopUp();
                frmPopup.lblPopUp.Text = "El telefono no existe";
                frmPopup.pnlMensaje.BackColor = Color.Crimson;
                frmPopup.Show();
            }
            else
            {
                cboTelefonos.Items.Remove(cboTelefonos.Text);
                PopUp frmPopup = new PopUp();
                frmPopup.lblPopUp.Text = "Telefono removido";
                frmPopup.pnlMensaje.BackColor = Color.Crimson;
                frmPopup.Show();
            }
        }

        private void btnVolver_Click_1(object sender, EventArgs e)
        {
            Program.frmBackoffice.actualizarPantalla(1);
            this.Close();
        }

        public void actualizarTexto()
        {
            switch (Program.idioma)
            {
                case 0:
                    lblNombre.Text = "Nombre";
                    lblApellidos.Text = "Apellidos";
                    lblFechaNacimiento.Text = "Fecha de Nacimiento";
                    lblTelefono.Text = "Teléfonos";
                    lblDireccion.Text = "Dirección";
                    lblCertMed.Text = "Certificado Médico";
                    lblCertBuenaConducta.Text = "Certificado de Buena Conducta";
                    lblFechaContratado.Text = "Fecha Contratado";
                    btnCrear.Text = "Guardar";
                    btnVolver.Text = "Cancelar";
                    btnModificar.Text = "Modificar";
                    lblTitulo.Text = "Registro de Perfil de Funcionario";
                    break;
                case 1:
                    lblNombre.Text = "Name";
                    lblApellidos.Text = "Surname/Last name";
                    lblFechaNacimiento.Text = "Date of Birth";
                    lblTelefono.Text = "Contact info";
                    lblDireccion.Text = "Address";
                    lblCertMed.Text = "Medical Certificate";
                    lblCertBuenaConducta.Text = "Certificate of Good Conduct";
                    lblFechaContratado.Text = "Date of Hire";
                    btnCrear.Text = "Save";
                    btnVolver.Text = "Cancel";
                    btnModificar.Text = "Modify";
                    lblTitulo.Text = "Warehouse Clerk Registration";
                    break;
            }
        }

        private void btnAsignar_Click(object sender, EventArgs e)
        {
            List<String> telefonos = new List<String>();
            Funcionario f = new Funcionario();
            f.ci = numero(txtCI.Text);
            f.deposito = cboDeposito.Text;
            f.conexion = Program.cn;
            switch (f.AsignarDeposito())
            {
                case 0:  //Se pudo efectuar el alta o modificación sin problemas.
                    PopUp frmPopup = new PopUp();
                    Program.frmBackoffice.actualizarPantalla(1);
                    frmPopup.lblPopUp.Text = "Funcionario asignado a deposito exitosamente";
                    frmPopup.pnlMensaje.BackColor = Color.MediumSeaGreen;
                    frmPopup.Show();
                    this.Close();
                    break;
                case 1: //La conexión está cerrada.
                    MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                    break;
                case 2:
                    MessageBox.Show("2");
                    break;
                case 3:
                    MessageBox.Show("3");
                    break;
            }
            Program.frmBackoffice.actualizarPantalla(1);
            f = null;
            this.Close();
        }
    }
}

