﻿namespace Backoffice
{
    partial class Camiones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Camiones));
            this.cboSticker = new System.Windows.Forms.ComboBox();
            this.lblSticker = new System.Windows.Forms.Label();
            this.dtpExpPatente = new System.Windows.Forms.DateTimePicker();
            this.lblExpPatente = new System.Windows.Forms.Label();
            this.txtSeguro = new System.Windows.Forms.TextBox();
            this.lblSeguro = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnVolver = new System.Windows.Forms.Button();
            this.btnCrear = new System.Windows.Forms.Button();
            this.txtCI = new System.Windows.Forms.TextBox();
            this.lblCI = new System.Windows.Forms.Label();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.cboModelo = new System.Windows.Forms.ComboBox();
            this.lblModeloCamion = new System.Windows.Forms.Label();
            this.cboEstadoMantenimiento = new System.Windows.Forms.ComboBox();
            this.lblEstadoMant = new System.Windows.Forms.Label();
            this.btnModificar = new System.Windows.Forms.Button();
            this.txtIdDeposito = new System.Windows.Forms.TextBox();
            this.lblIdDeposito = new System.Windows.Forms.Label();
            this.dgvDepositos = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDepositos)).BeginInit();
            this.SuspendLayout();
            // 
            // cboSticker
            // 
            this.cboSticker.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.cboSticker.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.cboSticker.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboSticker.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboSticker.ForeColor = System.Drawing.Color.White;
            this.cboSticker.FormattingEnabled = true;
            this.cboSticker.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.cboSticker.Location = new System.Drawing.Point(545, 193);
            this.cboSticker.Name = "cboSticker";
            this.cboSticker.Size = new System.Drawing.Size(254, 32);
            this.cboSticker.TabIndex = 142;
            // 
            // lblSticker
            // 
            this.lblSticker.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.lblSticker.AutoSize = true;
            this.lblSticker.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.lblSticker.Location = new System.Drawing.Point(540, 171);
            this.lblSticker.Name = "lblSticker";
            this.lblSticker.Size = new System.Drawing.Size(211, 25);
            this.lblSticker.TabIndex = 141;
            this.lblSticker.Text = "Sticker de Telepeaje";
            this.lblSticker.Click += new System.EventHandler(this.lblSticker_Click);
            // 
            // dtpExpPatente
            // 
            this.dtpExpPatente.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.dtpExpPatente.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpExpPatente.Location = new System.Drawing.Point(125, 199);
            this.dtpExpPatente.Name = "dtpExpPatente";
            this.dtpExpPatente.Size = new System.Drawing.Size(251, 29);
            this.dtpExpPatente.TabIndex = 134;
            // 
            // lblExpPatente
            // 
            this.lblExpPatente.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.lblExpPatente.AutoSize = true;
            this.lblExpPatente.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.lblExpPatente.Location = new System.Drawing.Point(120, 171);
            this.lblExpPatente.Name = "lblExpPatente";
            this.lblExpPatente.Size = new System.Drawing.Size(342, 25);
            this.lblExpPatente.TabIndex = 133;
            this.lblExpPatente.Text = "Fecha de Expiración de la Patente";
            // 
            // txtSeguro
            // 
            this.txtSeguro.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.txtSeguro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.txtSeguro.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSeguro.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSeguro.ForeColor = System.Drawing.Color.White;
            this.txtSeguro.Location = new System.Drawing.Point(125, 275);
            this.txtSeguro.Name = "txtSeguro";
            this.txtSeguro.Size = new System.Drawing.Size(251, 22);
            this.txtSeguro.TabIndex = 132;
            // 
            // lblSeguro
            // 
            this.lblSeguro.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.lblSeguro.AutoSize = true;
            this.lblSeguro.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.lblSeguro.Location = new System.Drawing.Point(120, 244);
            this.lblSeguro.Name = "lblSeguro";
            this.lblSeguro.Size = new System.Drawing.Size(82, 25);
            this.lblSeguro.TabIndex = 131;
            this.lblSeguro.Text = "Seguro";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(55)))));
            this.panel1.Location = new System.Drawing.Point(492, 63);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1, 485);
            this.panel1.TabIndex = 130;
            // 
            // btnVolver
            // 
            this.btnVolver.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnVolver.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVolver.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(25)))));
            this.btnVolver.FlatAppearance.BorderSize = 0;
            this.btnVolver.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVolver.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVolver.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(75)))));
            this.btnVolver.Location = new System.Drawing.Point(815, 457);
            this.btnVolver.Name = "btnVolver";
            this.btnVolver.Size = new System.Drawing.Size(146, 44);
            this.btnVolver.TabIndex = 129;
            this.btnVolver.Text = "Cancelar";
            this.btnVolver.UseVisualStyleBackColor = true;
            this.btnVolver.Click += new System.EventHandler(this.btnVolver_Click);
            // 
            // btnCrear
            // 
            this.btnCrear.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnCrear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCrear.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(25)))));
            this.btnCrear.FlatAppearance.BorderSize = 0;
            this.btnCrear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCrear.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCrear.ForeColor = System.Drawing.Color.BlueViolet;
            this.btnCrear.Location = new System.Drawing.Point(517, 457);
            this.btnCrear.Name = "btnCrear";
            this.btnCrear.Size = new System.Drawing.Size(138, 44);
            this.btnCrear.TabIndex = 128;
            this.btnCrear.Text = "Guardar";
            this.btnCrear.UseVisualStyleBackColor = true;
            this.btnCrear.Click += new System.EventHandler(this.btnCrear_Click);
            // 
            // txtCI
            // 
            this.txtCI.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.txtCI.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCI.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCI.ForeColor = System.Drawing.Color.White;
            this.txtCI.Location = new System.Drawing.Point(40, 75);
            this.txtCI.Name = "txtCI";
            this.txtCI.Size = new System.Drawing.Size(198, 22);
            this.txtCI.TabIndex = 124;
            this.txtCI.Visible = false;
            // 
            // lblCI
            // 
            this.lblCI.AutoSize = true;
            this.lblCI.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.lblCI.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(65)))));
            this.lblCI.Location = new System.Drawing.Point(35, 53);
            this.lblCI.Name = "lblCI";
            this.lblCI.Size = new System.Drawing.Size(33, 25);
            this.lblCI.TabIndex = 123;
            this.lblCI.Text = "ID";
            // 
            // txtMatricula
            // 
            this.txtMatricula.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.txtMatricula.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMatricula.ForeColor = System.Drawing.Color.White;
            this.txtMatricula.Location = new System.Drawing.Point(124, 127);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(252, 22);
            this.txtMatricula.TabIndex = 125;
            // 
            // lblTitulo
            // 
            this.lblTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(0, 0);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(973, 53);
            this.lblTitulo.TabIndex = 121;
            this.lblTitulo.Text = "Creacíon de Perfil de Camión";
            this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.lblMatricula.Location = new System.Drawing.Point(120, 105);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(100, 25);
            this.lblMatricula.TabIndex = 120;
            this.lblMatricula.Text = "Matricula";
            // 
            // cboModelo
            // 
            this.cboModelo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.cboModelo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.cboModelo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboModelo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboModelo.ForeColor = System.Drawing.Color.White;
            this.cboModelo.FormattingEnabled = true;
            this.cboModelo.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.cboModelo.Location = new System.Drawing.Point(545, 127);
            this.cboModelo.Name = "cboModelo";
            this.cboModelo.Size = new System.Drawing.Size(254, 32);
            this.cboModelo.TabIndex = 144;
            // 
            // lblModeloCamion
            // 
            this.lblModeloCamion.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.lblModeloCamion.AutoSize = true;
            this.lblModeloCamion.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.lblModeloCamion.Location = new System.Drawing.Point(540, 105);
            this.lblModeloCamion.Name = "lblModeloCamion";
            this.lblModeloCamion.Size = new System.Drawing.Size(198, 25);
            this.lblModeloCamion.TabIndex = 143;
            this.lblModeloCamion.Text = "Modelo del Camión";
            // 
            // cboEstadoMantenimiento
            // 
            this.cboEstadoMantenimiento.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.cboEstadoMantenimiento.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.RecentlyUsedList;
            this.cboEstadoMantenimiento.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.cboEstadoMantenimiento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboEstadoMantenimiento.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboEstadoMantenimiento.ForeColor = System.Drawing.Color.White;
            this.cboEstadoMantenimiento.FormattingEnabled = true;
            this.cboEstadoMantenimiento.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.cboEstadoMantenimiento.Location = new System.Drawing.Point(545, 265);
            this.cboEstadoMantenimiento.Name = "cboEstadoMantenimiento";
            this.cboEstadoMantenimiento.Size = new System.Drawing.Size(254, 32);
            this.cboEstadoMantenimiento.TabIndex = 146;
            // 
            // lblEstadoMant
            // 
            this.lblEstadoMant.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.lblEstadoMant.AutoSize = true;
            this.lblEstadoMant.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.lblEstadoMant.Location = new System.Drawing.Point(540, 237);
            this.lblEstadoMant.Name = "lblEstadoMant";
            this.lblEstadoMant.Size = new System.Drawing.Size(256, 25);
            this.lblEstadoMant.TabIndex = 145;
            this.lblEstadoMant.Text = "Estado de Mantenimiento";
            // 
            // btnModificar
            // 
            this.btnModificar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnModificar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnModificar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(25)))));
            this.btnModificar.FlatAppearance.BorderSize = 0;
            this.btnModificar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModificar.ForeColor = System.Drawing.Color.BlueViolet;
            this.btnModificar.Location = new System.Drawing.Point(661, 457);
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(138, 44);
            this.btnModificar.TabIndex = 147;
            this.btnModificar.Text = "Modificar";
            this.btnModificar.UseVisualStyleBackColor = true;
            this.btnModificar.Click += new System.EventHandler(this.btnModificar_Click);
            // 
            // txtIdDeposito
            // 
            this.txtIdDeposito.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.txtIdDeposito.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.txtIdDeposito.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtIdDeposito.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIdDeposito.ForeColor = System.Drawing.Color.White;
            this.txtIdDeposito.Location = new System.Drawing.Point(545, 341);
            this.txtIdDeposito.Name = "txtIdDeposito";
            this.txtIdDeposito.Size = new System.Drawing.Size(251, 22);
            this.txtIdDeposito.TabIndex = 149;
            // 
            // lblIdDeposito
            // 
            this.lblIdDeposito.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.lblIdDeposito.AutoSize = true;
            this.lblIdDeposito.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.lblIdDeposito.Location = new System.Drawing.Point(540, 310);
            this.lblIdDeposito.Name = "lblIdDeposito";
            this.lblIdDeposito.Size = new System.Drawing.Size(177, 25);
            this.lblIdDeposito.TabIndex = 148;
            this.lblIdDeposito.Text = "Asignar Deposito";
            // 
            // dgvDepositos
            // 
            this.dgvDepositos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDepositos.Location = new System.Drawing.Point(124, 321);
            this.dgvDepositos.Name = "dgvDepositos";
            this.dgvDepositos.Size = new System.Drawing.Size(222, 128);
            this.dgvDepositos.TabIndex = 155;
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(25)))));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.BlueViolet;
            this.button1.Location = new System.Drawing.Point(545, 378);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(193, 37);
            this.button1.TabIndex = 156;
            this.button1.Text = "Asignar Deposito";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Camiones
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(12)))), ((int)(((byte)(27)))));
            this.ClientSize = new System.Drawing.Size(973, 573);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dgvDepositos);
            this.Controls.Add(this.txtIdDeposito);
            this.Controls.Add(this.lblIdDeposito);
            this.Controls.Add(this.btnModificar);
            this.Controls.Add(this.cboEstadoMantenimiento);
            this.Controls.Add(this.lblEstadoMant);
            this.Controls.Add(this.cboModelo);
            this.Controls.Add(this.lblModeloCamion);
            this.Controls.Add(this.cboSticker);
            this.Controls.Add(this.lblSticker);
            this.Controls.Add(this.dtpExpPatente);
            this.Controls.Add(this.lblExpPatente);
            this.Controls.Add(this.txtSeguro);
            this.Controls.Add(this.lblSeguro);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnVolver);
            this.Controls.Add(this.btnCrear);
            this.Controls.Add(this.txtCI);
            this.Controls.Add(this.lblCI);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.lblMatricula);
            this.ForeColor = System.Drawing.Color.BlueViolet;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Camiones";
            this.Text = "Camiones";
            ((System.ComponentModel.ISupportInitialize)(this.dgvDepositos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.ComboBox cboSticker;
        private System.Windows.Forms.Label lblSticker;
        private System.Windows.Forms.DateTimePicker dtpExpPatente;
        private System.Windows.Forms.Label lblExpPatente;
        private System.Windows.Forms.TextBox txtSeguro;
        private System.Windows.Forms.Label lblSeguro;
        private System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.Button btnVolver;
        public System.Windows.Forms.Button btnCrear;
        public System.Windows.Forms.TextBox txtCI;
        public System.Windows.Forms.Label lblCI;
        public System.Windows.Forms.TextBox txtMatricula;
        public System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblMatricula;
        public System.Windows.Forms.ComboBox cboModelo;
        private System.Windows.Forms.Label lblModeloCamion;
        public System.Windows.Forms.ComboBox cboEstadoMantenimiento;
        private System.Windows.Forms.Label lblEstadoMant;
        public System.Windows.Forms.Button btnModificar;
        private System.Windows.Forms.TextBox txtIdDeposito;
        private System.Windows.Forms.Label lblIdDeposito;
        public System.Windows.Forms.DataGridView dgvDepositos;
        public System.Windows.Forms.Button button1;
    }
}