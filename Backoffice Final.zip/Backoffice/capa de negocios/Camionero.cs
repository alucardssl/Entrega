﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Backoffice.capa_de_negocios
{
    class Camionero
    {
        protected int _ci;
        private int _idCamion;
        protected String _nombre;
        protected String _apellidos;
        protected DateTime _fechaNac;
        protected String _mail;
        protected DateTime _fechaContratado;
        protected String _certificadoMedico;
        protected String _certificadoBuenaConducta;
        protected String _direccion;
        protected List<String> _telefonos;
        protected DateTime _expiracionLicencia;
        protected int _cantEnvios;
        protected int _enviosTarde;
        protected ADODB.Connection _conexion;

        public Camionero()
        {
            _ci = 0;
            _idCamion = 0;
            _nombre = "";
            _apellidos = "";
            _fechaNac = DateTime.Now;
            _fechaContratado = DateTime.Now;
            _certificadoMedico = "";
            _certificadoBuenaConducta = "";
            _direccion = "";
            _mail = "";
            _expiracionLicencia = DateTime.Now;
            _cantEnvios = 0;
            _enviosTarde = 0;
            _telefonos = new List<String>();
            _conexion = new ADODB.Connection();
        }

        public Camionero(int idCamion,int CI, string nombre, string apellidos, DateTime fechaDeNacimiento, DateTime fechaContratado, string certificadoMedico, string certificadoBuenaConducta, string direccion, string mail, DateTime expiracionLicencia, int cantEnvios, int enviosTarde, List<String> telefonos, ADODB.Connection cn)
        {
            _ci = CI;
            _idCamion = idCamion;
            _nombre = nombre;
            _apellidos = apellidos;
            _fechaNac = fechaDeNacimiento;
            _mail = mail;
            _telefonos = telefonos;
            _conexion = cn;
            _fechaContratado = fechaContratado;
            _certificadoBuenaConducta = certificadoBuenaConducta;
            _certificadoMedico = certificadoMedico;
            _direccion = direccion;
            _expiracionLicencia = expiracionLicencia;
            _cantEnvios = cantEnvios;
            _enviosTarde = enviosTarde;
        }

        public int ci
        {
            get { return (_ci); }
            set { _ci = value; }
        }
        public int idCamion
        {
            get { return (_idCamion); }
            set { _idCamion = value; }
        }
        public string nombre
        {
            get { return (_nombre); }
            set { _nombre = value; }
        }

        public string apellidos
        {
            get { return (_apellidos); }
            set { _apellidos = value; }
        }

        public DateTime fechaDeNacimiento
        {
            get { return (_fechaNac); }
            set { _fechaNac = value; }
        }

        public DateTime fechaContratado
        {
            get { return (_fechaContratado); }
            set { _fechaContratado = value; }
        }

        public DateTime expiracionLicencia
        {
            get { return (_expiracionLicencia); }
            set { _expiracionLicencia = value; }
        }

        public int cantEnvios
        {
            get { return (_cantEnvios); }
            set { _cantEnvios = value; }
        }

        public int enviosTarde
        {
            get { return (_enviosTarde); }
            set { _enviosTarde = value; }
        }

        public string mail
        {
            get { return (_mail); }
            set { _mail = value; }
        }
        public string certificadoMedico
        {
            get { return (_certificadoMedico); }
            set { _certificadoMedico = value; }
        }
        public string certificadoBuenaConducta
        {
            get { return (_certificadoBuenaConducta); }
            set { _certificadoBuenaConducta = value; }
        }
        public string direccion
        {
            get { return (_direccion); }
            set { _direccion = value; }
        }

        public List<String> telefonos
        {
            get { return (_telefonos); }
            set { _telefonos = value; }
        }

        public ADODB.Connection conexion
        {
            get { return (_conexion); }
            set { _conexion = value; }
        }

        public int buscar()
        {
            int retorno = 0; //por defecto asumo que no hubieron errores.
            //object cantFilas;
            ADODB.Recordset rs = new ADODB.Recordset();
            string sql;


            if (_conexion.State == 0)
            {
                retorno = 1; //conexión cerrada.
            }
            else
            {
                Program.cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient;
                sql = "select nombre from empleado where ci=" + _ci;
                try
                {
                    //rs = _conexion.Execute(sql, out cantFilas, -1);   
                    rs.Open(sql, _conexion, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly, -1);
                }
                catch
                {
                    return 2; //error al ejecutar la consulta.
                }
                if (rs.RecordCount == 0)
                {
                    return 3; //No se encontró registro alguno.
                }
                else
                {
                    sql = "select telefonos from empleado_telefonos where empleado=" + _ci;
                    try
                    {
                        //rs = _conexion.Execute(sql, out cantFilas, -1);
                        rs.Close();
                        rs.Open(sql, _conexion, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly, -1);
                    }
                    catch
                    {
                        return 4; //error al ejecutar la consulta de teléfonos.
                    }
                    _telefonos.Clear();
                    while (!rs.EOF) //mientras no llegue al fin 
                    {
                        _telefonos.Add(Convert.ToString(rs.Fields[0].Value));
                        rs.MoveNext(); //nos movemos al siguiente registro
                    }
                }
                Program.cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient;
                rs.Close();
                rs = null; // destruyo el objeto.
            }//if
            return (retorno);
        }

        public byte Crear()
        {
            object filasAfectadas;
            string sql;
            byte resultado = 0;

            if (_conexion.State == 0)
            {
                resultado = 1;
            }
            else
            {
                // Componer la consulta de inserción para la tabla 'empleado'
                sql = "INSERT INTO empleado (ci, mail, fechaNacimiento, nombre, apellidos, fechaContratado, certificadoMedico, certificadoBuenaConducta, ubicadoEn) VALUES (" + _ci + ",'" + _mail + "','" + _fechaNac.ToString("yyyy-MM-dd") + "','" + _nombre + "','" + _apellidos + "','" + _fechaContratado.ToString("yyyy-MM-dd") + "','" + _certificadoMedico + "','" + _certificadoBuenaConducta + "','" + _direccion + "')";

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    return 2; // Error al ejecutar la consulta de inserción
                }

                // Componer la consulta de inserción para la tabla 'Camionero'
                sql = "INSERT INTO chofer (ci, expiracionLicencia, cantEnvios, enviosTarde) VALUES (" + _ci + ",'" + _expiracionLicencia.ToString("yyyy-MM-dd") + "','" + _cantEnvios + "','" + _enviosTarde + "')";

                /*try
                {*/
                    _conexion.Execute(sql, out filasAfectadas);
                /*}
                catch
                {
                    return 3; // Error al ejecutar la consulta de inserción en la tabla 'Camionero'
                }*/

                // Insertar registros en la tabla 'empleado_telefonos'
                foreach (string t in _telefonos)
                {
                    sql = "INSERT INTO empleado_telefonos (empleado, telefonos) VALUES (" + _ci + ",'" + t + "')";
                    try
                    {
                        _conexion.Execute(sql, out filasAfectadas);
                    }
                    catch
                    {
                        return 4; // Error al ejecutar la consulta de inserción en la tabla 'empleado_telefonos'
                    }
                }
            }

            return resultado;
        }

        public byte Modificar()
        {
            object filasAfectadas;
            string sql;
            byte resultado = 0;

            if (_conexion.State == 0)
            {
                resultado = 1;
            }
            else
            {
                // Componer la consulta de actualización para la tabla 'empleado'
                sql = $"UPDATE empleado SET mail='{_mail}', fechaNacimiento='{_fechaNac.ToString("yyyy-MM-dd")}', nombre='{_nombre}', apellidos='{_apellidos}', fechaContratado='{_fechaContratado.ToString("yyyy-MM-dd")}', certificadoMedico='{_certificadoMedico}', certificadoBuenaConducta='{_certificadoBuenaConducta}', ubicadoEn='{_direccion}' WHERE ci={_ci}";

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    return 2; // Error al ejecutar la consulta de actualización en la tabla 'empleado'
                }
            

           // Componer la consulta de actualización para la tabla 'Camionero'
           sql = $"UPDATE Camionero SET expiracionLicencia='{_expiracionLicencia.ToString("yyyy-MM-dd")}', cantEnvios='{_cantEnvios}', enviosTarde='{_enviosTarde}' WHERE ci={_ci}";

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    return 3; // Error al ejecutar la consulta de actualización en la tabla 'Camionero'
                }

                // Eliminar registros antiguos de la tabla 'empleado_telefonos' asociados al empleado
                sql = $"DELETE FROM empleado_telefonos WHERE empleado={_ci}";
                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    return 4; // Error al eliminar registros de la tabla 'empleado_telefonos'
                }

                // Insertar registros actualizados en la tabla 'empleado_telefonos'
                foreach (string t in _telefonos)
                {
                    sql = $"INSERT INTO empleado_telefonos (empleado, telefonos) VALUES ({_ci}, '{t}')";
                    try
                    {
                        _conexion.Execute(sql, out filasAfectadas);
                    }
                    catch
                    {
                        return 5; // Error al ejecutar la consulta de inserción en la tabla 'empleado_telefonos'
                    }
                }
            }

            return resultado;
        }
        public byte AsignarCamion()
        {
            object filasAfectadas;
            string sql;
            byte resultado = 0;

            if (_conexion.State == 0)
            {
                resultado = 1;
            }
            else
            {
                // Componer la consulta de inserción para la tabla 'empleado'
                sql = "INSERT INTO choferConduce (camion, chofer) VALUES ("+_idCamion+ ","+ _ci +")";

                /*try
                {*/
                    _conexion.Execute(sql, out filasAfectadas);
                /*}
                catch
                {
                    return 2; // Error al ejecutar la consulta de inserción
                } */               
            }
            return resultado;
        }
        public byte Eliminar()
        {
            object filasAfectadas;
            string sql;
            byte resultado = 0;

            if (_conexion.State == 0)
            {
                resultado = 1; // La conexión no está abierta
            }
            else
            {
                // Componer la consulta de eliminación para la tabla 'camion'
                
                sql = "DELETE FROM choferconduce WHERE chofer = " + _ci;

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 2; // Error al ejecutar la consulta de eliminación
                }

                sql = "DELETE FROM chofer WHERE ci = " + _ci;

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 2; // Error al ejecutar la consulta de eliminación
                }
                sql = "DELETE FROM funcionario WHERE ci = " + _ci;

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 2; // Error al ejecutar la consulta de eliminación
                }
                sql = "delete from empleado_telefonos where empleado = " + _ci;
                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 2; // Error al ejecutar la consulta de eliminación
                }
                sql = "delete from empleado where ci = " + _ci;
                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 2; // Error al ejecutar la consulta de eliminación
                }
            }

            return resultado;
        }
    }
}

