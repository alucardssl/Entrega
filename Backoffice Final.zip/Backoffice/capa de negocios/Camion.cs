﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Backoffice.capa_de_negocios
{
    class Camion
    {

        private int _id;
        private int _idDeposito;
        private String _matricula;
        private int _stickerTelepeaje;
        private String _patente;
        private String _seguro;
        private int _nombreModelo;
        private float _volMax;
        private float _tara;
        private float _mma;
        private float _cargaUtil;
        private float _velMax;
        private int _estadoMantenimiento;
        protected ADODB.Connection _conexion;

        public Camion()
        {
            _id = 0;
            _idDeposito = 0;
            _matricula = "";
            _stickerTelepeaje = 0;
            _patente = "";
            _seguro = "";
            _nombreModelo = 0;
            _volMax = 0;
            _tara = 0;
            _mma = 0;
            _cargaUtil = 0;
            _velMax = 0;
            _estadoMantenimiento = 0;
            _conexion = new ADODB.Connection();

        }

        public Camion(int IdDeposito, int ID, string matricula, int stickerTelepeaje, string patente, string seguro, int nombreModelo, float volMax, float tara, float mma, float cargaUtil, float velMax, int estadoMantenimiento, ADODB.Connection cn)
        {
            _id = ID;
            _idDeposito = IdDeposito;
            _matricula = matricula;
            _stickerTelepeaje = stickerTelepeaje;
            _patente = patente;
            _seguro = seguro;
            _nombreModelo = nombreModelo;
            _volMax = volMax;
            _tara = tara;
            _mma = mma;
            _cargaUtil = cargaUtil;
            _velMax = velMax;
            _estadoMantenimiento = estadoMantenimiento;
            _conexion = cn;
        }

        //getters y setters:

        public int Id { get => _id; set => _id = value; }
        public int IdDeposito { get => _idDeposito; set => _idDeposito = value; }
        public string Matricula { get => _matricula; set => _matricula = value; }
        public int StickerTelepeaje { get => _stickerTelepeaje; set => _stickerTelepeaje = value; }
        public string Patente { get => _patente; set => _patente = value; }
        public string Seguro { get => _seguro; set => _seguro = value; }
        public int NombreModelo { get => _nombreModelo; set => _nombreModelo = value; }
        public float VolMax { get => _volMax; set => _volMax = value; }
        public float Tara { get => _tara; set => _tara = value; }
        public float Mma { get => _mma; set => _mma = value; }
        public float CargaUtil { get => _cargaUtil; set => _cargaUtil = value; }
        public float VelMax { get => _velMax; set => _velMax = value; }
        public int EstadoMantenimiento { get => _estadoMantenimiento; set => _estadoMantenimiento = value; }


        public ADODB.Connection conexion
        {
            get { return (_conexion); }
            set { _conexion = value; }
        }


        public int buscar()
        {
            int retorno = 0; //por defecto asumo que no hubieron errores.
            //object cantFilas;
            ADODB.Recordset rs = new ADODB.Recordset();
            string sql;


            if (_conexion.State == 0)
            {
                retorno = 1; //conexión cerrada.
            }
            else
            {
                Program.cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient;
                sql = "select id from camion where id=" + _id;
                try
                {
                    //rs = _conexion.Execute(sql, out cantFilas, -1);   
                    rs.Open(sql, _conexion, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly, -1);
                }
                catch
                {
                    return 2; //error al ejecutar la consulta.
                }
                if (rs.RecordCount == 0)
                {
                    return 3; //No se encontró registro alguno.
                }
                Program.cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient;
                rs.Close();
                rs = null; // destruyo el objeto.
            }//if
            return (retorno);
        }

        public byte Crear()
        {
            object filasAfectadas;
            string sql;
            byte resultado = 0;
            if (_conexion.State == 0)
            {
                resultado = 1;
            }
            else
            {
                // Componer la consulta de inserción para la tabla 'empleado'
                sql = "INSERT INTO camion (id, matricula, StickerTelepeaje, patente, seguro, modelo, estadoMantenimiento) VALUES ("+_id +",'"+ _matricula + "','" + _stickerTelepeaje + "','" + _patente + "','" + _seguro + "','" + _nombreModelo + "','" + _estadoMantenimiento + "')";

                try
                {
                _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    return 2; // Error al ejecutar la consulta de inserción
                }
            }
            return resultado;
        }

        public byte Modificar()
        {
            object filasAfectadas;
            string sql;
            byte resultado = 0;

            if (_conexion.State == 0)
            {
                resultado = 1;
            }
            else
            {
                // Componer la consulta de actualización para la tabla 'empleado'
                sql = "UPDATE camion SET matricula='" + _matricula + "', StickerTelepeaje='" + _stickerTelepeaje + "', patente='" + _patente + "', seguro='" + _seguro + "', modelo='" + _nombreModelo + "', estadoMantenimiento='" + _estadoMantenimiento + "' WHERE id=" + _id;
                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    return 2; // Error al ejecutar la consulta de actualización en la tabla 'empleado'

                }

            }
            return resultado;

        }
        public byte AsignarDeposito()
        {
            object filasAfectadas;
            string sql;
            byte resultado = 0;
            if (_conexion.State == 0)
            {
                resultado = 1;
            }
            else
            {
                // Componer la consulta de inserción para la tabla 'empleado'
                sql = "INSERT INTO camionalmacenadoen (camion, deposito) VALUES (" + _id + "," + _idDeposito + ")";

                try
                {
                _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    return 3; // Error al ejecutar la consulta de inserción
                }
            }
            return resultado;
        }
        public byte Eliminar()
        {
            object filasAfectadas;
            string sql;
            byte resultado = 0;

            if (_conexion.State == 0)
            {
                resultado = 1; // La conexión no está abierta
            }
            else
            {
                sql = "DELETE FROM choferconduce WHERE camion=" + _id;

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 2; // Error al ejecutar la consulta de eliminación
                }
                // Componer la consulta de eliminación para la tabla 'camion'
                sql = "DELETE FROM camionalmacenadoen WHERE camion=" + _id;

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 2; // Error al ejecutar la consulta de eliminación
                }
                sql = "DELETE FROM camion WHERE id=" + _id;

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 2; // Error al ejecutar la consulta de eliminación
                }
            }

            return resultado;
        }
    }
}
