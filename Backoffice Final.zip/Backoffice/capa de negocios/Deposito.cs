﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Backoffice.capa_de_negocios
{
    class Deposito
    {
        private int _idDepartamento;
        private int _idLugar;
        private int _idDeposito;
        private String _nombre;
        private String _nombreL;
        private List<String> _nombreLugar;
        private float _latitudLugar;
        private float _longitudLugar;
        private String _direccionLugar;
        private List<String> _departamentoLugar;
        private ADODB.Connection _conexion;

        public Deposito()
        {
            _idDepartamento = 0;
            _idLugar = 0;
            _idDeposito = 0;
            _nombre = "Error";
            _nombreL = "";
            _nombreLugar = new List<String>();
            _latitudLugar = 0;
            _longitudLugar = 0;
            _direccionLugar = "Error";
            _departamentoLugar = new List<String>();
            _conexion = new ADODB.Connection();
        }

        public Deposito(int IdDepartamento, int IdLugar, int IdDeposito, String nombre, String nombreL, List<String> nombreLugar, float latitudLugar, float longitudLugar, String direccionLugar, List<String> departamento, ADODB.Connection cn)
        {
            _idDepartamento = IdDepartamento;
            _idLugar = IdLugar;
            _idDeposito = IdDeposito;
            _nombre = nombre;
            _nombreL = nombreL;
            _nombreLugar = nombreLugar;
            _latitudLugar = latitudLugar;
            _longitudLugar = longitudLugar;
            _direccionLugar = direccionLugar;
            _departamentoLugar = departamento;
            _conexion = cn;
        }
        public int IdDepartamento { get => _idDepartamento; set => _idDepartamento = value; }
        public int IdLugar { get => _idLugar; set => _idLugar = value; }
        public int IdDeposito { get => _idDeposito; set => _idDeposito = value; }
        public string nombre { get => _nombre; set => _nombre = value; }
        public string nombreL { get => _nombreL; set => _nombreL = value; }
        public List<String> NombreLugar { get => _nombreLugar; set => _nombreLugar = value; }
        public float LatitudLugar { get => _latitudLugar; set => _latitudLugar = value; }
        public float LongitudLugar { get => _longitudLugar; set => _longitudLugar = value; }
        public string DireccionLugar { get => _direccionLugar; set => _direccionLugar = value; }
        public List<String> Departamento { get => _departamentoLugar; set => _departamentoLugar = value; }

        public ADODB.Connection conexion
        {
            get { return (_conexion); }
            set { _conexion = value; }
        }


        public int buscar()
        {
            int retorno = 0; //por defecto asumo que no hubieron errores.
            //object cantFilas;
            ADODB.Recordset rs = new ADODB.Recordset();
            string sql;


            if (_conexion.State == 0)
            {
                retorno = 1; //conexión cerrada.
            }
            else
            {
                Program.cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient;
                sql = "select id from deposito where id=" + _idDeposito;
                try
                {
                    //rs = _conexion.Execute(sql, out cantFilas, -1);   
                    rs.Open(sql, _conexion, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly, -1);
                }
                catch
                {
                    return 2; //error al ejecutar la consulta.
                }
                if (rs.RecordCount == 0)
                {
                    return 3; //No se encontró registro alguno.
                }
                Program.cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient;
                rs.Close();
                rs = null; // destruyo el objeto.
            }//if
            return (retorno);
        }

        public int buscarLugaryDepartamento()
        {
            int retorno = 0; // Por defecto, asumimos que no hubo errores.
            ADODB.Recordset rs = new ADODB.Recordset();
            string sql;

            if (_conexion.State == 0)
            {
                retorno = 1; // Conexión cerrada.
            }
            else
            {
                // Consulta para la tabla 'lugar'
                sql = "SELECT nombre FROM lugar";
                try
                {
                    rs.Open(sql, _conexion, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly, -1);
                    _nombreLugar.Clear();
                    while (!rs.EOF)
                    {
                        _nombreLugar.Add(rs.Fields[0].Value);
                        rs.MoveNext();
                    }
                    rs.Close();
                }
                catch
                {
                    return 2; // Error al ejecutar la consulta de nombre de lugar
                }

                // Consulta para la tabla 'departamento'
                sql = "SELECT nombre FROM departamento";
                try
                {
                    rs.Open(sql, _conexion, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly, -1);
                    _departamentoLugar.Clear();
                    while (!rs.EOF)
                    {
                        _departamentoLugar.Add(rs.Fields[0].Value);
                        rs.MoveNext();
                    }
                    rs.Close();
                }
                catch
                {
                    return 3; // Error al ejecutar la consulta de nombre de departamento
                }

                Program.cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient;
                rs = null; // Destruyo el objeto.
            }

            return retorno;
        }

        public byte AgregarLugar()
        {
            object filasAfectadas;
            string sql;
            ADODB.Recordset rs = new ADODB.Recordset();
            byte resultado = 0;
            if (_conexion.State == 0)
            {
                resultado = 1;
            }
            else
            {
                // Componer la consulta de inserción para la tabla 'empleado'
                sql = "INSERT INTO lugar (nombre, latitud, longitud, direccion, departamento) VALUES('" + _nombreL + "','" + _latitudLugar.ToString("0.##########") + "','" + _longitudLugar.ToString("0.##########") + "','" + _direccionLugar + "','" + _idDepartamento + "')";

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    return 2; // Error al ejecutar la consulta de inserción
                }

                sql = "select nombre from lugar ";
                try
                {
                    //rs = _conexion.Execute(sql, out cantFilas, -1);
                    rs.Open(sql, _conexion, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly, -1);
                }
                catch
                {
                    return 3; //error al ejecutar la consulta de nombre
                }
                _nombreLugar.Clear();
                while (!rs.EOF) //mientras no llegue al fin 
                {
                    _nombreLugar.Add(rs.Fields[0].Value);
                    rs.MoveNext(); //nos movemos al siguiente registro
                }
            }
            return resultado;
        }

        public byte CrearDeposito()
        {
            object filasAfectadas;
            string sql;
            byte resultado = 0;
            if (_conexion.State == 0)
            {
                resultado = 1;
            }
            else
            {
                // Componer la consulta de inserción para la tabla 'empleado'
                sql = "INSERT INTO deposito (id,nombre, localizacion) VALUES ("+_idDeposito+ ",'"+ _nombre + "','" + _idLugar + "')";

                /*try
                {*/
                    _conexion.Execute(sql, out filasAfectadas);
                /*}
                catch
                {
                    return 2; // Error al ejecutar la consulta de inserción
                }*/
            }
            return resultado;
        }

        public byte ActualizarDeposito()
        {
            object filasAfectadas;
            string sql;
            byte resultado = 0;

            if (_conexion.State == 0)
            {
                resultado = 1; // La conexión está cerrada
            }
            else
            {
                // Componer la consulta de actualización para la tabla 'deposito'
                sql = "UPDATE deposito SET nombre = '" + _nombre + "', localizacion = '" + _idLugar + "' WHERE id = " + _idDeposito;

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 2; // Error al ejecutar la consulta de actualización
                }
            }

            return resultado;
        }


        public byte ModificarLugar()
        {
            object filasAfectadas;
            string sql;
            byte resultado = 0;
            ADODB.Recordset rs = new ADODB.Recordset();

            if (_conexion.State == 0)
            {
                resultado = 1;
            }
            else
            {
                // Componer la consulta de modificación para la tabla 'lugar' usando la clave primaria '_idLugar'
                sql = "UPDATE lugar SET nombre = '" + _nombreL + "', latitud = '" + _latitudLugar.ToString("0.##########") + "', longitud = '" + _longitudLugar.ToString("0.##########") + "', direccion = '" + _direccionLugar + "', departamento = '" + _idDepartamento + "' WHERE id = " + _idLugar;

                /*try
                {*/
                _conexion.Execute(sql, out filasAfectadas);
                /*}
                catch
                {
                    return 2; // Error al ejecutar la consulta de modificación
                }*/

                // Actualizar la lista _nombreLugar después de la modificación
                sql = "SELECT nombre FROM lugar";
                try
                {
                    rs.Open(sql, _conexion, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly, -1);
                }
                catch
                {
                    return 3; // Error al ejecutar la consulta de nombre
                }

                _nombreLugar.Clear();
                while (!rs.EOF)
                {
                    _nombreLugar.Add(rs.Fields[0].Value);
                    rs.MoveNext();
                }
            }
            return resultado;
        }
        public byte EliminarDeposito()
        {
            object filasAfectadas;
            string sql;
            byte resultado = 0;

            if (_conexion.State == 0)
            {
                resultado = 1; // La conexión no está abierta
            }
            else
            {
                // Componer la consulta de eliminación para la tabla 'camion'
                sql = "DELETE FROM lotealmacenadoen WHERE deposito = " + _idDeposito;

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 2; // Error al ejecutar la consulta de eliminación
                }

                sql = "DELETE FROM funcionariosupervisa WHERE deposito = " + _idDeposito;

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 2; // Error al ejecutar la consulta de eliminación
                }
                sql = "DELETE FROM camionsale WHERE deposito=" + _idDeposito;

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 2; // Error al ejecutar la consulta de eliminación
                }

                sql = "DELETE FROM camionalmacenadoen WHERE deposito=" + _idDeposito;

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 2; // Error al ejecutar la consulta de eliminación
                }
                sql = "DELETE FROM producto WHERE ubicadoEn=" + _idDeposito;

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 2; // Error al ejecutar la consulta de eliminación
                }

                // Componer la consulta de eliminación para la tabla 'camion'
                sql = "DELETE FROM lote WHERE ubicadoEn=" + _idDeposito;

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                        resultado = 3; // Error al ejecutar la consulta de eliminación
                }
                sql = "DELETE FROM deposito WHERE id=" + _idDeposito;

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 4; // Error al ejecutar la consulta de eliminación
                }
            }
            return resultado;
        }
            public byte EliminarLugar()
        {
            object filasAfectadas;
            string sql;
            byte resultado = 0;

            if (_conexion.State == 0)
            {
                resultado = 1; // La conexión no está abierta
            }
            else
            {
                sql = "DELETE FuncionarioSupervisa FROM FuncionarioSupervisa JOIN Deposito ON FuncionarioSupervisa.Deposito = " + _idDeposito + " WHERE Localizacion = " + _idLugar;
                // Componer la consulta de eliminación para la tabla 'camion'
                try
                {

                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 2; // Error al ejecutar la consulta de eliminación
                }
                sql = "DELETE camionAlmacenadoEn FROM camionAlmacenadoEn JOIN Deposito ON camionAlmacenadoEn.Deposito = " + _idDeposito + " WHERE Localizacion = " + _idLugar;
                // Componer la consulta de eliminación para la tabla 'camion'
                try
                {


                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 3; // Error al ejecutar la consulta de eliminación
                }
                sql = "DELETE loteAlmacenadoEn FROM loteAlmacenadoEn JOIN Deposito ON loteAlmacenadoEn.Deposito = " + _idDeposito + " WHERE Localizacion = " + _idLugar;
                // Componer la consulta de eliminación para la tabla 'camion'
                /*try
                {*/


                _conexion.Execute(sql, out filasAfectadas);
                /*}
                catch
                {
                    resultado = 4; // Error al ejecutar la consulta de eliminación
                }*/

                sql = "DELETE FROM lote WHERE destino=" + _idDeposito;
                // Componer la consulta de eliminación para la tabla 'camion'
                try
                {


                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 5; // Error al ejecutar la consulta de eliminación
                }


                sql = "DELETE FROM deposito WHERE localizacion=" + _idLugar;

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 6; // Error al ejecutar la consulta de eliminación
                }

                sql = "DELETE FROM producto WHERE destino=" + _idLugar;

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 7; // Error al ejecutar la consulta de eliminación
                }

                sql = "DELETE FROM trayecto WHERE lugar=" + _idLugar;

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 8; // Error al ejecutar la consulta de eliminación
                }

                sql = "DELETE FROM lugar WHERE id=" + _idLugar;

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 9; // Error al ejecutar la consulta de eliminación
                }
            }

            return resultado;
        }
        public byte EliminarSoloLugar()
        {
            object filasAfectadas;
            string sql;
            byte resultado = 0;

            if (_conexion.State == 0)
            {
                resultado = 1; // La conexión no está abierta
            }
            else
            {

                sql = "DELETE FROM lugar WHERE id=" + _idLugar;

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 3; // Error al ejecutar la consulta de eliminación
                }
            }

            return resultado;
        }
    }
}

