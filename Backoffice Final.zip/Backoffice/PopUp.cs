﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Backoffice
{
    public partial class PopUp : Form
    {
        public PopUp()
        {
            InitializeComponent();
        }

        private void tmrFadeIn_Tick(object sender, EventArgs e) //Animación de aparición del formulario
        {
            if (Opacity == 1)
            {
                
                Task.Delay(2000).Wait();
                this.Close();
                tmrFadeOut.Start();
                tmrFadeIn.Stop();
            }
            Opacity += .17; //Velocidad en la que aparece el formulario
        }

        private void tmrFadeOut_Tick(object sender, EventArgs e) //Animación de aparición del formulario
        {
            if (Opacity == 0)
            {
                tmrFadeOut.Stop();
            }
            Opacity -= .17; 
        }

        private void PopUp_Load(object sender, EventArgs e)
        {
            this.Location = Program.frmBackoffice.Location;
            tmrFadeIn.Start();
        }

        private void pnlMensaje_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
