﻿namespace Backoffice
{
    partial class Administradores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtBoxID = new System.Windows.Forms.TextBox();
            this.lblIDAd = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblMail = new System.Windows.Forms.Label();
            this.btnActualizar = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.txtBoxTelefono = new System.Windows.Forms.TextBox();
            this.txtBoxFechaNacimiento = new System.Windows.Forms.TextBox();
            this.txtBoxNombreChofer = new System.Windows.Forms.TextBox();
            this.txtBoxApellidos = new System.Windows.Forms.TextBox();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblNombreAd = new System.Windows.Forms.Label();
            this.lblFechaNacimiento = new System.Windows.Forms.Label();
            this.lblApellidosAd = new System.Windows.Forms.Label();
            this.lblTelefono = new System.Windows.Forms.Label();
            this.btnCrear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtBoxID
            // 
            this.txtBoxID.Location = new System.Drawing.Point(132, 90);
            this.txtBoxID.Name = "txtBoxID";
            this.txtBoxID.Size = new System.Drawing.Size(189, 20);
            this.txtBoxID.TabIndex = 63;
            // 
            // lblIDAd
            // 
            this.lblIDAd.AutoSize = true;
            this.lblIDAd.Location = new System.Drawing.Point(20, 93);
            this.lblIDAd.Name = "lblIDAd";
            this.lblIDAd.Size = new System.Drawing.Size(18, 13);
            this.lblIDAd.TabIndex = 62;
            this.lblIDAd.Text = "ID";
            // 
            // textBox1
            // 
            this.textBox1.AccessibleRole = System.Windows.Forms.AccessibleRole.Cursor;
            this.textBox1.Location = new System.Drawing.Point(132, 225);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(189, 20);
            this.textBox1.TabIndex = 61;
            // 
            // lblMail
            // 
            this.lblMail.AccessibleRole = System.Windows.Forms.AccessibleRole.Cursor;
            this.lblMail.AutoSize = true;
            this.lblMail.Location = new System.Drawing.Point(20, 228);
            this.lblMail.Name = "lblMail";
            this.lblMail.Size = new System.Drawing.Size(26, 13);
            this.lblMail.TabIndex = 60;
            this.lblMail.Text = "Mail";
            // 
            // btnActualizar
            // 
            this.btnActualizar.Location = new System.Drawing.Point(255, 262);
            this.btnActualizar.Name = "btnActualizar";
            this.btnActualizar.Size = new System.Drawing.Size(75, 23);
            this.btnActualizar.TabIndex = 59;
            this.btnActualizar.Text = "Actualizar";
            this.btnActualizar.UseVisualStyleBackColor = true;
            // 
            // btnEliminar
            // 
            this.btnEliminar.Location = new System.Drawing.Point(142, 262);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(75, 23);
            this.btnEliminar.TabIndex = 58;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            // 
            // txtBoxTelefono
            // 
            this.txtBoxTelefono.Location = new System.Drawing.Point(132, 196);
            this.txtBoxTelefono.Name = "txtBoxTelefono";
            this.txtBoxTelefono.Size = new System.Drawing.Size(189, 20);
            this.txtBoxTelefono.TabIndex = 57;
            // 
            // txtBoxFechaNacimiento
            // 
            this.txtBoxFechaNacimiento.Location = new System.Drawing.Point(132, 168);
            this.txtBoxFechaNacimiento.Name = "txtBoxFechaNacimiento";
            this.txtBoxFechaNacimiento.Size = new System.Drawing.Size(189, 20);
            this.txtBoxFechaNacimiento.TabIndex = 56;
            // 
            // txtBoxNombreChofer
            // 
            this.txtBoxNombreChofer.Location = new System.Drawing.Point(132, 116);
            this.txtBoxNombreChofer.Name = "txtBoxNombreChofer";
            this.txtBoxNombreChofer.Size = new System.Drawing.Size(189, 20);
            this.txtBoxNombreChofer.TabIndex = 55;
            // 
            // txtBoxApellidos
            // 
            this.txtBoxApellidos.Location = new System.Drawing.Point(132, 142);
            this.txtBoxApellidos.Name = "txtBoxApellidos";
            this.txtBoxApellidos.Size = new System.Drawing.Size(189, 20);
            this.txtBoxApellidos.TabIndex = 54;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Location = new System.Drawing.Point(89, 39);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(213, 13);
            this.lblTitulo.TabIndex = 53;
            this.lblTitulo.Text = "Creacíon y modificación de Administradores";
            // 
            // lblNombreAd
            // 
            this.lblNombreAd.AutoSize = true;
            this.lblNombreAd.Location = new System.Drawing.Point(20, 119);
            this.lblNombreAd.Name = "lblNombreAd";
            this.lblNombreAd.Size = new System.Drawing.Size(44, 13);
            this.lblNombreAd.TabIndex = 51;
            this.lblNombreAd.Text = "Nombre";
            // 
            // lblFechaNacimiento
            // 
            this.lblFechaNacimiento.AutoSize = true;
            this.lblFechaNacimiento.Location = new System.Drawing.Point(20, 171);
            this.lblFechaNacimiento.Name = "lblFechaNacimiento";
            this.lblFechaNacimiento.Size = new System.Drawing.Size(106, 13);
            this.lblFechaNacimiento.TabIndex = 52;
            this.lblFechaNacimiento.Text = "Fecha de nacimiento";
            // 
            // lblApellidosAd
            // 
            this.lblApellidosAd.AutoSize = true;
            this.lblApellidosAd.Location = new System.Drawing.Point(21, 145);
            this.lblApellidosAd.Name = "lblApellidosAd";
            this.lblApellidosAd.Size = new System.Drawing.Size(49, 13);
            this.lblApellidosAd.TabIndex = 49;
            this.lblApellidosAd.Text = "Apellidos";
            // 
            // lblTelefono
            // 
            this.lblTelefono.AutoSize = true;
            this.lblTelefono.Location = new System.Drawing.Point(20, 199);
            this.lblTelefono.Name = "lblTelefono";
            this.lblTelefono.Size = new System.Drawing.Size(49, 13);
            this.lblTelefono.TabIndex = 50;
            this.lblTelefono.Text = "Telefono";
            // 
            // btnCrear
            // 
            this.btnCrear.Location = new System.Drawing.Point(24, 262);
            this.btnCrear.Name = "btnCrear";
            this.btnCrear.Size = new System.Drawing.Size(75, 23);
            this.btnCrear.TabIndex = 48;
            this.btnCrear.Text = "Crear";
            this.btnCrear.UseVisualStyleBackColor = true;
            // 
            // Administradores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(417, 335);
            this.Controls.Add(this.txtBoxID);
            this.Controls.Add(this.lblIDAd);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblMail);
            this.Controls.Add(this.btnActualizar);
            this.Controls.Add(this.btnEliminar);
            this.Controls.Add(this.txtBoxTelefono);
            this.Controls.Add(this.txtBoxFechaNacimiento);
            this.Controls.Add(this.txtBoxNombreChofer);
            this.Controls.Add(this.txtBoxApellidos);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.lblNombreAd);
            this.Controls.Add(this.lblFechaNacimiento);
            this.Controls.Add(this.lblApellidosAd);
            this.Controls.Add(this.lblTelefono);
            this.Controls.Add(this.btnCrear);
            this.Name = "Administradores";
            this.Text = "Administradores";
            this.Load += new System.EventHandler(this.Administradores_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtBoxID;
        private System.Windows.Forms.Label lblIDAd;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblMail;
        private System.Windows.Forms.Button btnActualizar;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.TextBox txtBoxTelefono;
        private System.Windows.Forms.TextBox txtBoxFechaNacimiento;
        private System.Windows.Forms.TextBox txtBoxNombreChofer;
        private System.Windows.Forms.TextBox txtBoxApellidos;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblNombreAd;
        private System.Windows.Forms.Label lblFechaNacimiento;
        private System.Windows.Forms.Label lblApellidosAd;
        private System.Windows.Forms.Label lblTelefono;
        private System.Windows.Forms.Button btnCrear;
    }
}