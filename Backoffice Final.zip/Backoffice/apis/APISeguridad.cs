﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;
using Backoffice.capa_de_negocios;
namespace Backoffice.apis
{
    class APISeguridad
    {
        
        public static string ValidoUsuario(string usuarioValidar) //a este método le tiene que llegar un usuario con nombre y contraseña pero sin rol, no tiene mucho sentido...
        {
            Usuario usuarioInput = JsonSerializer.Deserialize<Usuario>(usuarioValidar); //deserializamos el usuario que llega
            usuarioInput.rol = usuarioInput.validoUsuario(); //le asignamos su rol al usuario
            return (JsonSerializer.Serialize(usuarioInput)); //devolvemos el usuario validado serializado
        }

    }

}

