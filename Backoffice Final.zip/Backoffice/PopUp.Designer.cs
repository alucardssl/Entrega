﻿namespace Backoffice
{
    partial class PopUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pnlMensaje = new System.Windows.Forms.Panel();
            this.lblPopUp = new System.Windows.Forms.Label();
            this.tmrFadeIn = new System.Windows.Forms.Timer(this.components);
            this.tmrFadeOut = new System.Windows.Forms.Timer(this.components);
            this.pnlMensaje.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMensaje
            // 
            this.pnlMensaje.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlMensaje.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.pnlMensaje.Controls.Add(this.lblPopUp);
            this.pnlMensaje.Location = new System.Drawing.Point(0, 0);
            this.pnlMensaje.Name = "pnlMensaje";
            this.pnlMensaje.Size = new System.Drawing.Size(1288, 30);
            this.pnlMensaje.TabIndex = 0;
            this.pnlMensaje.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlMensaje_Paint);
            // 
            // lblPopUp
            // 
            this.lblPopUp.AutoSize = true;
            this.lblPopUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.lblPopUp.ForeColor = System.Drawing.Color.Black;
            this.lblPopUp.Location = new System.Drawing.Point(644, 0);
            this.lblPopUp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPopUp.Name = "lblPopUp";
            this.lblPopUp.Size = new System.Drawing.Size(343, 29);
            this.lblPopUp.TabIndex = 3;
            this.lblPopUp.Text = "Usuario creado correctamente.";
            this.lblPopUp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tmrFadeIn
            // 
            this.tmrFadeIn.Enabled = true;
            this.tmrFadeIn.Tick += new System.EventHandler(this.tmrFadeIn_Tick);
            // 
            // tmrFadeOut
            // 
            this.tmrFadeOut.Enabled = true;
            // 
            // PopUp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1100, 30);
            this.Controls.Add(this.pnlMensaje);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "PopUp";
            this.Opacity = 0D;
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "PopUp";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.PopUp_Load);
            this.pnlMensaje.ResumeLayout(false);
            this.pnlMensaje.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        public System.Windows.Forms.Label lblPopUp;
        private System.Windows.Forms.Timer tmrFadeIn;
        private System.Windows.Forms.Timer tmrFadeOut;
        public System.Windows.Forms.Panel pnlMensaje;
    }
}