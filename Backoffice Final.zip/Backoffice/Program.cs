﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Backoffice.capa_de_presentacion;

namespace Backoffice
{
    static class Program
    {
        public static Backoffice frmBackoffice;
        public static ADODB.Connection cn = new ADODB.Connection();
        public static Login frmLogin;
        public static Camiones frmCamiones;
        public static Camioneros frmCamioneros;
        public static Funcionarios frmFuncionarios;
        public static Depositos frmDepositos;
        public static Productos frmProductos;
        public static Lotes frmLotes;
        public static PagWeb frmPagWeb;
        public static Preferencias frmPreferencias;
        public static Boolean existeCI;
        public static int idioma;

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            frmLogin = new Login();
            Application.Run(new Login());
        }
    }
}