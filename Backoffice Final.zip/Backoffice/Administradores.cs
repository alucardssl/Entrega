﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Backoffice
{
    public partial class Administradores : Form
    {
        public Administradores(Boolean nuevo)
        {
            InitializeComponent();

            if (nuevo)
            {
                btnActualizar.Hide();
            }
            else
            {
                btnCrear.Hide();
            }


        }

        private void Administradores_Load(object sender, EventArgs e)
        {

        }
    }
}
