﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppSeguimiento
{
    class AsignacionLote
    {
        private int _idLote;
        private int _idCamion;
        private ADODB.Connection _conexion;

        public AsignacionLote()
        {
            _idLote= 0;
            _idCamion= 0;
            _conexion = new ADODB.Connection();
        }
        public AsignacionLote(int IdLote, int idCamion, ADODB.Connection cn)
        {
            _idLote = IdLote;
            _idCamion = idCamion;
            _conexion = cn;
        }
        public int idLote { get => _idLote; set => _idLote = value; }
        public int idCamion { get => _idCamion; set => _idCamion= value; }
        public ADODB.Connection conexion
        {
            get { return (_conexion); }
            set { _conexion = value; }
        }

        public byte AsignarLote()
        {
            object filasAfectadas;
            string sql;
            byte resultado = 0;

            if (_conexion.State == 0)
            {
                resultado = 1; // La conexión está cerrada.
            }
            else
            {
                // Componer la consulta de inserción para la tabla 'producto'
                sql = "INSERT INTO camionlleva (camion, lote) VALUES (" + _idCamion + "," + _idLote+")";

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    return 2; // Error al ejecutar la consulta de inserción
                }
            }
            return resultado;
        }
        public byte EliminarLote()
        {
            object filasAfectadas;
            string sql;
            byte resultado = 0;

            if (_conexion.State == 0)
            {
                resultado = 1; // La conexión no está abierta
            }
            else
            {
                // Componer la consulta de eliminación para la tabla 'camion'
                sql = "DELETE FROM camionlleva WHERE lote=" + _idLote;

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 2; // Error al ejecutar la consulta de eliminación
                }

            }


            return resultado;
        }
    }
}
