﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppFuncionario

{
    public partial class Preferencias : Form
    {
        public int idioma;
        public Preferencias(Login login)
        {
            InitializeComponent();
            Program.frmLogin = login;
            actualizarIdioma(Program.frmLogin.idioma);
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            Program.frmLogin.idioma = Convert.ToInt16(rbIngles.Checked);
            if (Program.cn.State == 1) //Si la conexion esta abierta
            {
                //Program.frmBackoffice.actualizarPantalla(Program.frmBackoffice.categoriaMenuActual);
                Program.frmPrincipal.actualizarTexto();
                Program.frmPrincipal.actualizarTextoCategoria(Program.frmPrincipal.categoriaMenuActual);

            }
            Program.frmLogin.actualizarTexto2();
            this.Close();
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnMin_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private bool _dragging = false;
        private Point _offset;
        private Point _start_point = new Point(0, 0);

        private void pnlBarraTitulo_MouseDown(object sender, MouseEventArgs e)
        {
            _dragging = true;
            _start_point = new Point(e.X, e.Y);
        }

        private void pnlBarraTitulo_MouseMove(object sender, MouseEventArgs e)
        {
            if (_dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this._start_point.X, p.Y - this._start_point.Y);
            }
        }

        private void pnlBarraTitulo_MouseUp(object sender, MouseEventArgs e)
        {
            _dragging = false;
        }

        private void lblTitulo_MouseDown(object sender, MouseEventArgs e)
        {
            _dragging = true;
            _start_point = new Point(e.X, e.Y);
        }

        private void lblTitulo_MouseMove(object sender, MouseEventArgs e)
        {
            if (_dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this._start_point.X, p.Y - this._start_point.Y);
            }
        }

        private void lblTitulo_MouseUp(object sender, MouseEventArgs e)
        {
            _dragging = false;
        }

        private void rbEspanol_CheckedChanged(object sender, EventArgs e)
        {
            //actualizarIdioma(Convert.ToInt16(rbIngles.Checked));
        }

        private void rbIngles_CheckedChanged(object sender, EventArgs e)
        {
            //actualizarIdioma(Convert.ToInt16(rbIngles.Checked));
        }

        public void actualizarIdioma(int idiomaselec)
        {
            switch (idiomaselec)
            {
                case 0:
                    lblTitulo.Text = "Preferencias";
                    lblIdioma.Text = "Idioma";
                    rbEspanol.Text = "Español";
                    rbIngles.Text = "Inglés";
                    btnOK.Text = "Guardar cambios";
                    idioma = 0;
                    rbEspanol.Checked = true;
                    break;
                case 1:
                    lblTitulo.Text = "Preferences";
                    lblIdioma.Text = "Language";
                    rbEspanol.Text = "Spanish";
                    rbIngles.Text = "English";
                    btnOK.Text = "Save changes";
                    rbIngles.Checked = true;
                    idioma = 1;
                    break;
                default:
                    lblTitulo.Text = "Preferencias";
                    lblIdioma.Text = "Idioma";
                    rbEspanol.Text = "Español";
                    rbIngles.Text = "Inglés";
                    btnOK.Text = "Guardar cambios";
                    rbEspanol.Checked = true;
                    idioma = 0;
                    break;
            }
        }
    }
}
