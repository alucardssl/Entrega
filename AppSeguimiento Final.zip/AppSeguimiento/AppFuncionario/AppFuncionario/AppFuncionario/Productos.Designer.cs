﻿namespace AppFuncionario
{
    partial class Productos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cboUbicacion = new System.Windows.Forms.ComboBox();
            this.lblUbicacion = new System.Windows.Forms.Label();
            this.cboPrioridad = new System.Windows.Forms.ComboBox();
            this.lblPrioridad = new System.Windows.Forms.Label();
            this.txtIDProducto = new System.Windows.Forms.TextBox();
            this.lblIDProducto = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnVolver = new System.Windows.Forms.Button();
            this.btnCrear = new System.Windows.Forms.Button();
            this.cboFragilidad = new System.Windows.Forms.ComboBox();
            this.dtpFechaLim = new System.Windows.Forms.DateTimePicker();
            this.txtCI = new System.Windows.Forms.TextBox();
            this.lblID = new System.Windows.Forms.Label();
            this.txtVolumen = new System.Windows.Forms.TextBox();
            this.lblVolumen = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.txtPeso = new System.Windows.Forms.TextBox();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblNombreCh = new System.Windows.Forms.Label();
            this.lblFechaLim = new System.Windows.Forms.Label();
            this.lblApellidos = new System.Windows.Forms.Label();
            this.lblTelefono = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cboUbicacion
            // 
            this.cboUbicacion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.cboUbicacion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboUbicacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboUbicacion.ForeColor = System.Drawing.Color.White;
            this.cboUbicacion.FormattingEnabled = true;
            this.cboUbicacion.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.cboUbicacion.Location = new System.Drawing.Point(555, 204);
            this.cboUbicacion.Name = "cboUbicacion";
            this.cboUbicacion.Size = new System.Drawing.Size(198, 32);
            this.cboUbicacion.TabIndex = 160;
            // 
            // lblUbicacion
            // 
            this.lblUbicacion.AutoSize = true;
            this.lblUbicacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.lblUbicacion.Location = new System.Drawing.Point(550, 182);
            this.lblUbicacion.Name = "lblUbicacion";
            this.lblUbicacion.Size = new System.Drawing.Size(107, 25);
            this.lblUbicacion.TabIndex = 159;
            this.lblUbicacion.Text = "Ubicación";
            // 
            // cboPrioridad
            // 
            this.cboPrioridad.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.cboPrioridad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboPrioridad.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboPrioridad.ForeColor = System.Drawing.Color.White;
            this.cboPrioridad.FormattingEnabled = true;
            this.cboPrioridad.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.cboPrioridad.Location = new System.Drawing.Point(51, 430);
            this.cboPrioridad.Name = "cboPrioridad";
            this.cboPrioridad.Size = new System.Drawing.Size(198, 32);
            this.cboPrioridad.TabIndex = 158;
            // 
            // lblPrioridad
            // 
            this.lblPrioridad.AutoSize = true;
            this.lblPrioridad.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.lblPrioridad.Location = new System.Drawing.Point(46, 408);
            this.lblPrioridad.Name = "lblPrioridad";
            this.lblPrioridad.Size = new System.Drawing.Size(98, 25);
            this.lblPrioridad.TabIndex = 157;
            this.lblPrioridad.Text = "Prioridad";
            // 
            // txtIDProducto
            // 
            this.txtIDProducto.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.txtIDProducto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.txtIDProducto.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtIDProducto.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIDProducto.ForeColor = System.Drawing.Color.White;
            this.txtIDProducto.Location = new System.Drawing.Point(555, 148);
            this.txtIDProducto.Name = "txtIDProducto";
            this.txtIDProducto.Size = new System.Drawing.Size(198, 22);
            this.txtIDProducto.TabIndex = 156;
            // 
            // lblIDProducto
            // 
            this.lblIDProducto.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.lblIDProducto.AutoSize = true;
            this.lblIDProducto.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.lblIDProducto.Location = new System.Drawing.Point(551, 126);
            this.lblIDProducto.Name = "lblIDProducto";
            this.lblIDProducto.Size = new System.Drawing.Size(155, 25);
            this.lblIDProducto.TabIndex = 155;
            this.lblIDProducto.Text = "ID de Producto";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(55)))));
            this.panel1.Location = new System.Drawing.Point(494, 102);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1, 446);
            this.panel1.TabIndex = 154;
            // 
            // btnVolver
            // 
            this.btnVolver.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnVolver.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVolver.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(25)))));
            this.btnVolver.FlatAppearance.BorderSize = 0;
            this.btnVolver.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVolver.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVolver.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(65)))));
            this.btnVolver.Location = new System.Drawing.Point(767, 479);
            this.btnVolver.Name = "btnVolver";
            this.btnVolver.Size = new System.Drawing.Size(146, 44);
            this.btnVolver.TabIndex = 153;
            this.btnVolver.Text = "Cancelar";
            this.btnVolver.UseVisualStyleBackColor = true;
            // 
            // btnCrear
            // 
            this.btnCrear.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnCrear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCrear.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(25)))));
            this.btnCrear.FlatAppearance.BorderSize = 0;
            this.btnCrear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCrear.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCrear.ForeColor = System.Drawing.Color.BlueViolet;
            this.btnCrear.Location = new System.Drawing.Point(568, 479);
            this.btnCrear.Name = "btnCrear";
            this.btnCrear.Size = new System.Drawing.Size(138, 44);
            this.btnCrear.TabIndex = 152;
            this.btnCrear.Text = "Guardar";
            this.btnCrear.UseVisualStyleBackColor = true;
            // 
            // cboFragilidad
            // 
            this.cboFragilidad.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.cboFragilidad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboFragilidad.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboFragilidad.ForeColor = System.Drawing.Color.White;
            this.cboFragilidad.FormattingEnabled = true;
            this.cboFragilidad.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.cboFragilidad.Location = new System.Drawing.Point(50, 303);
            this.cboFragilidad.Name = "cboFragilidad";
            this.cboFragilidad.Size = new System.Drawing.Size(198, 32);
            this.cboFragilidad.TabIndex = 150;
            // 
            // dtpFechaLim
            // 
            this.dtpFechaLim.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpFechaLim.Location = new System.Drawing.Point(50, 367);
            this.dtpFechaLim.Name = "dtpFechaLim";
            this.dtpFechaLim.Size = new System.Drawing.Size(200, 29);
            this.dtpFechaLim.TabIndex = 149;
            // 
            // txtCI
            // 
            this.txtCI.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.txtCI.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCI.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCI.ForeColor = System.Drawing.Color.White;
            this.txtCI.Location = new System.Drawing.Point(50, 96);
            this.txtCI.Name = "txtCI";
            this.txtCI.Size = new System.Drawing.Size(198, 22);
            this.txtCI.TabIndex = 146;
            this.txtCI.Visible = false;
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.lblID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(65)))));
            this.lblID.Location = new System.Drawing.Point(45, 74);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(33, 25);
            this.lblID.TabIndex = 145;
            this.lblID.Text = "ID";
            // 
            // txtVolumen
            // 
            this.txtVolumen.AccessibleRole = System.Windows.Forms.AccessibleRole.Cursor;
            this.txtVolumen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.txtVolumen.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtVolumen.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVolumen.ForeColor = System.Drawing.Color.White;
            this.txtVolumen.Location = new System.Drawing.Point(50, 256);
            this.txtVolumen.Name = "txtVolumen";
            this.txtVolumen.Size = new System.Drawing.Size(198, 22);
            this.txtVolumen.TabIndex = 151;
            // 
            // lblVolumen
            // 
            this.lblVolumen.AccessibleRole = System.Windows.Forms.AccessibleRole.Cursor;
            this.lblVolumen.AutoSize = true;
            this.lblVolumen.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.lblVolumen.Location = new System.Drawing.Point(45, 234);
            this.lblVolumen.Name = "lblVolumen";
            this.lblVolumen.Size = new System.Drawing.Size(97, 25);
            this.lblVolumen.TabIndex = 144;
            this.lblVolumen.Text = "Volumen";
            // 
            // txtNombre
            // 
            this.txtNombre.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.txtNombre.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombre.ForeColor = System.Drawing.Color.White;
            this.txtNombre.Location = new System.Drawing.Point(49, 148);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(198, 22);
            this.txtNombre.TabIndex = 147;
            // 
            // txtPeso
            // 
            this.txtPeso.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.txtPeso.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPeso.ForeColor = System.Drawing.Color.White;
            this.txtPeso.Location = new System.Drawing.Point(50, 204);
            this.txtPeso.Name = "txtPeso";
            this.txtPeso.Size = new System.Drawing.Size(200, 22);
            this.txtPeso.TabIndex = 148;
            // 
            // lblTitulo
            // 
            this.lblTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(0, 0);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(973, 50);
            this.lblTitulo.TabIndex = 143;
            this.lblTitulo.Text = "Creacíon de Perfil de Producto";
            this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNombreCh
            // 
            this.lblNombreCh.AutoSize = true;
            this.lblNombreCh.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.lblNombreCh.Location = new System.Drawing.Point(45, 126);
            this.lblNombreCh.Name = "lblNombreCh";
            this.lblNombreCh.Size = new System.Drawing.Size(87, 25);
            this.lblNombreCh.TabIndex = 141;
            this.lblNombreCh.Text = "Nombre";
            // 
            // lblFechaLim
            // 
            this.lblFechaLim.AutoSize = true;
            this.lblFechaLim.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.lblFechaLim.Location = new System.Drawing.Point(45, 345);
            this.lblFechaLim.Name = "lblFechaLim";
            this.lblFechaLim.Size = new System.Drawing.Size(264, 25);
            this.lblFechaLim.TabIndex = 142;
            this.lblFechaLim.Text = "Fecha Máxima de Entrega";
            // 
            // lblApellidos
            // 
            this.lblApellidos.AutoSize = true;
            this.lblApellidos.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.lblApellidos.Location = new System.Drawing.Point(46, 182);
            this.lblApellidos.Name = "lblApellidos";
            this.lblApellidos.Size = new System.Drawing.Size(61, 25);
            this.lblApellidos.TabIndex = 139;
            this.lblApellidos.Text = "Peso";
            // 
            // lblTelefono
            // 
            this.lblTelefono.AutoSize = true;
            this.lblTelefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.lblTelefono.Location = new System.Drawing.Point(45, 281);
            this.lblTelefono.Name = "lblTelefono";
            this.lblTelefono.Size = new System.Drawing.Size(107, 25);
            this.lblTelefono.TabIndex = 140;
            this.lblTelefono.Text = "Fragilidad";
            // 
            // Productos
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(12)))), ((int)(((byte)(27)))));
            this.ClientSize = new System.Drawing.Size(973, 573);
            this.Controls.Add(this.cboUbicacion);
            this.Controls.Add(this.lblUbicacion);
            this.Controls.Add(this.cboPrioridad);
            this.Controls.Add(this.lblPrioridad);
            this.Controls.Add(this.txtIDProducto);
            this.Controls.Add(this.lblIDProducto);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnVolver);
            this.Controls.Add(this.btnCrear);
            this.Controls.Add(this.cboFragilidad);
            this.Controls.Add(this.dtpFechaLim);
            this.Controls.Add(this.txtCI);
            this.Controls.Add(this.lblID);
            this.Controls.Add(this.txtVolumen);
            this.Controls.Add(this.lblVolumen);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.txtPeso);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.lblNombreCh);
            this.Controls.Add(this.lblFechaLim);
            this.Controls.Add(this.lblApellidos);
            this.Controls.Add(this.lblTelefono);
            this.ForeColor = System.Drawing.Color.BlueViolet;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Productos";
            this.Text = "Productos";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.ComboBox cboUbicacion;
        private System.Windows.Forms.Label lblUbicacion;
        public System.Windows.Forms.ComboBox cboPrioridad;
        private System.Windows.Forms.Label lblPrioridad;
        public System.Windows.Forms.TextBox txtIDProducto;
        private System.Windows.Forms.Label lblIDProducto;
        private System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.Button btnVolver;
        public System.Windows.Forms.Button btnCrear;
        public System.Windows.Forms.ComboBox cboFragilidad;
        private System.Windows.Forms.DateTimePicker dtpFechaLim;
        public System.Windows.Forms.TextBox txtCI;
        public System.Windows.Forms.Label lblID;
        private System.Windows.Forms.TextBox txtVolumen;
        private System.Windows.Forms.Label lblVolumen;
        public System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.TextBox txtPeso;
        public System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblNombreCh;
        private System.Windows.Forms.Label lblFechaLim;
        private System.Windows.Forms.Label lblApellidos;
        private System.Windows.Forms.Label lblTelefono;
    }
}