﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppSeguimiento
{
    public partial class IngresarDeposito : Form
    {
        public IngresarDeposito()
        {
            InitializeComponent();
            actualizarTexto();

        }
        private void btnContinuar_Click(object sender, EventArgs e) //-S Primero chequearia que existe el deposito seleccionado en la bd
        {
            Program.frmPrincipal.actualizarPantalla(0);
            Program.frmPrincipal.lblDeposito.Tag = txtUbicacion.Text; //Uso el tag como espacio de memoria donde almacenar el ID de Deposito
            Program.frmPrincipal.actualizarTexto();
            this.Close();
        }
        public void actualizarTexto()
        {
            switch (Program.frmLogin.idioma)
            {
                case 0:
                    lblIngresar.Text = "Ingrese Depósito para gestionar";
                    btnContinuar.Text = "Continuar";
                    break;
                case 1:
                    lblIngresar.Text = "Enter a Warehouse to Navigate in";
                    btnContinuar.Text = "Continue";
                    break;
                default:
                    lblIngresar.Text = "Ingrese Depósito para gestionar";
                    btnContinuar.Text = "Continuar";
                    break;
            }
        }
    }
}


