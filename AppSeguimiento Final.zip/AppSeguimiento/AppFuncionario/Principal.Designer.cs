﻿namespace AppSeguimiento
{
    partial class Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Principal));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlEncabez = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnPreferencias = new System.Windows.Forms.Button();
            this.pnlBarraTitulo = new System.Windows.Forms.Panel();
            this.pnlLogoBarra = new System.Windows.Forms.Panel();
            this.btnCerrar = new System.Windows.Forms.Button();
            this.btnMin = new System.Windows.Forms.Button();
            this.btnMax = new System.Windows.Forms.Button();
            this.lblCedula = new System.Windows.Forms.Label();
            this.lblBienvenido = new System.Windows.Forms.Label();
            this.btnCerrarSesion = new System.Windows.Forms.Button();
            this.pnlCategorias = new System.Windows.Forms.Panel();
            this.btnElegirDeposito = new System.Windows.Forms.Button();
            this.lblDeposito = new System.Windows.Forms.Label();
            this.pnlLogoPhoenix = new System.Windows.Forms.Panel();
            this.pnlCreditos = new System.Windows.Forms.Label();
            this.btnProductos = new System.Windows.Forms.Button();
            this.pnlLateralL = new System.Windows.Forms.Panel();
            this.pnl_lupita = new System.Windows.Forms.Panel();
            this.txtCI = new System.Windows.Forms.TextBox();
            this.pnlLateralR = new System.Windows.Forms.Panel();
            this.pnlFormHijo = new System.Windows.Forms.Panel();
            this.pnlLogoFondo = new System.Windows.Forms.Panel();
            this.dgvResultados = new System.Windows.Forms.DataGridView();
            this.test = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.test1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.test2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tmrFadeIn = new System.Windows.Forms.Timer(this.components);
            this.pnlEncabez.SuspendLayout();
            this.pnlBarraTitulo.SuspendLayout();
            this.pnlCategorias.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultados)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlEncabez
            // 
            this.pnlEncabez.Controls.Add(this.panel1);
            this.pnlEncabez.Controls.Add(this.btnPreferencias);
            this.pnlEncabez.Controls.Add(this.pnlBarraTitulo);
            this.pnlEncabez.Controls.Add(this.lblCedula);
            this.pnlEncabez.Controls.Add(this.lblBienvenido);
            this.pnlEncabez.Controls.Add(this.btnCerrarSesion);
            this.pnlEncabez.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlEncabez.Location = new System.Drawing.Point(0, 0);
            this.pnlEncabez.Name = "pnlEncabez";
            this.pnlEncabez.Size = new System.Drawing.Size(1284, 117);
            this.pnlEncabez.TabIndex = 28;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.AutoSize = true;
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(55)))));
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.panel1.Location = new System.Drawing.Point(-8, 116);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1300, 1);
            this.panel1.TabIndex = 40;
            // 
            // btnPreferencias
            // 
            this.btnPreferencias.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPreferencias.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPreferencias.BackgroundImage")));
            this.btnPreferencias.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnPreferencias.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPreferencias.FlatAppearance.BorderSize = 0;
            this.btnPreferencias.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPreferencias.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPreferencias.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(95)))));
            this.btnPreferencias.Location = new System.Drawing.Point(1229, 43);
            this.btnPreferencias.Margin = new System.Windows.Forms.Padding(4);
            this.btnPreferencias.Name = "btnPreferencias";
            this.btnPreferencias.Size = new System.Drawing.Size(32, 33);
            this.btnPreferencias.TabIndex = 39;
            this.btnPreferencias.UseVisualStyleBackColor = true;
            this.btnPreferencias.Click += new System.EventHandler(this.btnPreferencias_Click);
            // 
            // pnlBarraTitulo
            // 
            this.pnlBarraTitulo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(15)))));
            this.pnlBarraTitulo.Controls.Add(this.pnlLogoBarra);
            this.pnlBarraTitulo.Controls.Add(this.btnCerrar);
            this.pnlBarraTitulo.Controls.Add(this.btnMin);
            this.pnlBarraTitulo.Controls.Add(this.btnMax);
            this.pnlBarraTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlBarraTitulo.Location = new System.Drawing.Point(0, 0);
            this.pnlBarraTitulo.Name = "pnlBarraTitulo";
            this.pnlBarraTitulo.Size = new System.Drawing.Size(1284, 32);
            this.pnlBarraTitulo.TabIndex = 27;
            this.pnlBarraTitulo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlBarraTitulo_MouseDown);
            this.pnlBarraTitulo.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlBarraTitulo_MouseMove);
            this.pnlBarraTitulo.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlBarraTitulo_MouseUp);
            // 
            // pnlLogoBarra
            // 
            this.pnlLogoBarra.AutoSize = true;
            this.pnlLogoBarra.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlLogoBarra.BackgroundImage")));
            this.pnlLogoBarra.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pnlLogoBarra.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlLogoBarra.Location = new System.Drawing.Point(0, 0);
            this.pnlLogoBarra.Margin = new System.Windows.Forms.Padding(4);
            this.pnlLogoBarra.MinimumSize = new System.Drawing.Size(133, 12);
            this.pnlLogoBarra.Name = "pnlLogoBarra";
            this.pnlLogoBarra.Size = new System.Drawing.Size(133, 32);
            this.pnlLogoBarra.TabIndex = 26;
            // 
            // btnCerrar
            // 
            this.btnCerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCerrar.FlatAppearance.BorderSize = 0;
            this.btnCerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCerrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnCerrar.ForeColor = System.Drawing.Color.Crimson;
            this.btnCerrar.Location = new System.Drawing.Point(1254, 0);
            this.btnCerrar.Margin = new System.Windows.Forms.Padding(4);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(30, 30);
            this.btnCerrar.TabIndex = 22;
            this.btnCerrar.Text = "X";
            this.btnCerrar.UseVisualStyleBackColor = true;
            this.btnCerrar.Click += new System.EventHandler(this.btnCerrar_Click);
            // 
            // btnMin
            // 
            this.btnMin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMin.FlatAppearance.BorderSize = 0;
            this.btnMin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnMin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(55)))));
            this.btnMin.Location = new System.Drawing.Point(1192, -2);
            this.btnMin.Margin = new System.Windows.Forms.Padding(4);
            this.btnMin.Name = "btnMin";
            this.btnMin.Size = new System.Drawing.Size(32, 30);
            this.btnMin.TabIndex = 24;
            this.btnMin.Text = "—";
            this.btnMin.UseVisualStyleBackColor = true;
            this.btnMin.Click += new System.EventHandler(this.btnMin_Click);
            // 
            // btnMax
            // 
            this.btnMax.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMax.FlatAppearance.BorderSize = 0;
            this.btnMax.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMax.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnMax.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(55)))));
            this.btnMax.Location = new System.Drawing.Point(1224, -1);
            this.btnMax.Margin = new System.Windows.Forms.Padding(4);
            this.btnMax.Name = "btnMax";
            this.btnMax.Size = new System.Drawing.Size(30, 32);
            this.btnMax.TabIndex = 23;
            this.btnMax.Text = "☐";
            this.btnMax.UseVisualStyleBackColor = true;
            this.btnMax.Click += new System.EventHandler(this.btnMax_Click);
            // 
            // lblCedula
            // 
            this.lblCedula.AutoSize = true;
            this.lblCedula.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.lblCedula.ForeColor = System.Drawing.Color.Orchid;
            this.lblCedula.Location = new System.Drawing.Point(18, 84);
            this.lblCedula.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCedula.Name = "lblCedula";
            this.lblCedula.Size = new System.Drawing.Size(52, 29);
            this.lblCedula.TabIndex = 4;
            this.lblCedula.Text = "\"CI\"";
            // 
            // lblBienvenido
            // 
            this.lblBienvenido.AutoSize = true;
            this.lblBienvenido.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.lblBienvenido.ForeColor = System.Drawing.Color.Orchid;
            this.lblBienvenido.Location = new System.Drawing.Point(18, 55);
            this.lblBienvenido.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBienvenido.Name = "lblBienvenido";
            this.lblBienvenido.Size = new System.Drawing.Size(273, 29);
            this.lblBienvenido.TabIndex = 2;
            this.lblBienvenido.Text = "Bienvenido, Funcionario";
            // 
            // btnCerrarSesion
            // 
            this.btnCerrarSesion.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCerrarSesion.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCerrarSesion.FlatAppearance.BorderSize = 0;
            this.btnCerrarSesion.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnCerrarSesion.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnCerrarSesion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCerrarSesion.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCerrarSesion.ForeColor = System.Drawing.Color.Crimson;
            this.btnCerrarSesion.Location = new System.Drawing.Point(1127, 84);
            this.btnCerrarSesion.Margin = new System.Windows.Forms.Padding(4);
            this.btnCerrarSesion.Name = "btnCerrarSesion";
            this.btnCerrarSesion.Size = new System.Drawing.Size(144, 33);
            this.btnCerrarSesion.TabIndex = 88;
            this.btnCerrarSesion.Text = "Cerrar Sesión";
            this.btnCerrarSesion.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCerrarSesion.UseVisualStyleBackColor = true;
            this.btnCerrarSesion.Click += new System.EventHandler(this.btnCerrarSesion_Click);
            // 
            // pnlCategorias
            // 
            this.pnlCategorias.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(15)))));
            this.pnlCategorias.Controls.Add(this.btnElegirDeposito);
            this.pnlCategorias.Controls.Add(this.lblDeposito);
            this.pnlCategorias.Controls.Add(this.pnlLogoPhoenix);
            this.pnlCategorias.Controls.Add(this.pnlCreditos);
            this.pnlCategorias.Controls.Add(this.btnProductos);
            this.pnlCategorias.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlCategorias.Location = new System.Drawing.Point(0, 117);
            this.pnlCategorias.Name = "pnlCategorias";
            this.pnlCategorias.Size = new System.Drawing.Size(311, 573);
            this.pnlCategorias.TabIndex = 29;
            // 
            // btnElegirDeposito
            // 
            this.btnElegirDeposito.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnElegirDeposito.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnElegirDeposito.FlatAppearance.BorderSize = 0;
            this.btnElegirDeposito.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnElegirDeposito.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnElegirDeposito.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnElegirDeposito.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.btnElegirDeposito.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(65)))));
            this.btnElegirDeposito.Location = new System.Drawing.Point(4, 475);
            this.btnElegirDeposito.Margin = new System.Windows.Forms.Padding(4);
            this.btnElegirDeposito.Name = "btnElegirDeposito";
            this.btnElegirDeposito.Size = new System.Drawing.Size(80, 33);
            this.btnElegirDeposito.TabIndex = 89;
            this.btnElegirDeposito.Text = "Atrás";
            this.btnElegirDeposito.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnElegirDeposito.UseVisualStyleBackColor = true;
            this.btnElegirDeposito.Click += new System.EventHandler(this.btnElegirDeposito_Click);
            // 
            // lblDeposito
            // 
            this.lblDeposito.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.lblDeposito.ForeColor = System.Drawing.Color.Orchid;
            this.lblDeposito.Location = new System.Drawing.Point(10, 441);
            this.lblDeposito.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDeposito.Name = "lblDeposito";
            this.lblDeposito.Size = new System.Drawing.Size(148, 29);
            this.lblDeposito.TabIndex = 29;
            this.lblDeposito.Text = "Deposito:";
            this.lblDeposito.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pnlLogoPhoenix
            // 
            this.pnlLogoPhoenix.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlLogoPhoenix.BackColor = System.Drawing.Color.Transparent;
            this.pnlLogoPhoenix.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlLogoPhoenix.BackgroundImage")));
            this.pnlLogoPhoenix.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pnlLogoPhoenix.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pnlLogoPhoenix.Location = new System.Drawing.Point(3, 528);
            this.pnlLogoPhoenix.Name = "pnlLogoPhoenix";
            this.pnlLogoPhoenix.Size = new System.Drawing.Size(140, 42);
            this.pnlLogoPhoenix.TabIndex = 28;
            this.pnlLogoPhoenix.Click += new System.EventHandler(this.pnlLogoPhoenix_Click);
            // 
            // pnlCreditos
            // 
            this.pnlCreditos.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlCreditos.AutoSize = true;
            this.pnlCreditos.BackColor = System.Drawing.Color.Transparent;
            this.pnlCreditos.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.pnlCreditos.ForeColor = System.Drawing.Color.White;
            this.pnlCreditos.Location = new System.Drawing.Point(12, 512);
            this.pnlCreditos.Name = "pnlCreditos";
            this.pnlCreditos.Size = new System.Drawing.Size(130, 17);
            this.pnlCreditos.TabIndex = 27;
            this.pnlCreditos.Text = "Desarrollado por";
            this.pnlCreditos.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnProductos
            // 
            this.btnProductos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnProductos.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnProductos.FlatAppearance.BorderSize = 0;
            this.btnProductos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProductos.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold);
            this.btnProductos.ForeColor = System.Drawing.Color.BlueViolet;
            this.btnProductos.Image = ((System.Drawing.Image)(resources.GetObject("btnProductos.Image")));
            this.btnProductos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnProductos.Location = new System.Drawing.Point(0, 0);
            this.btnProductos.Name = "btnProductos";
            this.btnProductos.Size = new System.Drawing.Size(311, 85);
            this.btnProductos.TabIndex = 25;
            this.btnProductos.Text = "Productos";
            this.btnProductos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnProductos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnProductos.UseVisualStyleBackColor = true;
            this.btnProductos.Click += new System.EventHandler(this.btnProductos_Click);
            // 
            // pnlLateralL
            // 
            this.pnlLateralL.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlLateralL.Location = new System.Drawing.Point(311, 117);
            this.pnlLateralL.Name = "pnlLateralL";
            this.pnlLateralL.Size = new System.Drawing.Size(90, 573);
            this.pnlLateralL.TabIndex = 31;
            // 
            // pnl_lupita
            // 
            this.pnl_lupita.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.pnl_lupita.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnl_lupita.BackgroundImage")));
            this.pnl_lupita.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pnl_lupita.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.pnl_lupita.Location = new System.Drawing.Point(735, 141);
            this.pnl_lupita.Name = "pnl_lupita";
            this.pnl_lupita.Size = new System.Drawing.Size(31, 31);
            this.pnl_lupita.TabIndex = 82;
            // 
            // txtCI
            // 
            this.txtCI.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.txtCI.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCI.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCI.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(95)))));
            this.txtCI.Location = new System.Drawing.Point(401, 141);
            this.txtCI.Margin = new System.Windows.Forms.Padding(4);
            this.txtCI.MaxLength = 8;
            this.txtCI.Name = "txtCI";
            this.txtCI.Size = new System.Drawing.Size(365, 31);
            this.txtCI.TabIndex = 77;
            this.txtCI.Text = "Buscar...";
            this.txtCI.Enter += new System.EventHandler(this.txtCI_Enter);
            // 
            // pnlLateralR
            // 
            this.pnlLateralR.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlLateralR.Location = new System.Drawing.Point(1194, 117);
            this.pnlLateralR.Name = "pnlLateralR";
            this.pnlLateralR.Size = new System.Drawing.Size(90, 573);
            this.pnlLateralR.TabIndex = 78;
            // 
            // pnlFormHijo
            // 
            this.pnlFormHijo.Location = new System.Drawing.Point(735, 573);
            this.pnlFormHijo.Name = "pnlFormHijo";
            this.pnlFormHijo.Size = new System.Drawing.Size(55, 36);
            this.pnlFormHijo.TabIndex = 84;
            // 
            // pnlLogoFondo
            // 
            this.pnlLogoFondo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlLogoFondo.BackgroundImage")));
            this.pnlLogoFondo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pnlLogoFondo.Location = new System.Drawing.Point(418, 293);
            this.pnlLogoFondo.Name = "pnlLogoFondo";
            this.pnlLogoFondo.Size = new System.Drawing.Size(696, 185);
            this.pnlLogoFondo.TabIndex = 85;
            // 
            // dgvResultados
            // 
            this.dgvResultados.AllowUserToAddRows = false;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(15)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.White;
            this.dgvResultados.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
            this.dgvResultados.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvResultados.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvResultados.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(15)))));
            this.dgvResultados.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvResultados.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(15)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.NullValue = "-";
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.BlueViolet;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvResultados.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dgvResultados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResultados.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.test,
            this.test1,
            this.test2});
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(15)))));
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.BlueViolet;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.BlueViolet;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvResultados.DefaultCellStyle = dataGridViewCellStyle13;
            this.dgvResultados.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.dgvResultados.Location = new System.Drawing.Point(401, 232);
            this.dgvResultados.Name = "dgvResultados";
            this.dgvResultados.ReadOnly = true;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(15)))));
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.BlueViolet;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvResultados.RowHeadersDefaultCellStyle = dataGridViewCellStyle14;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.White;
            this.dgvResultados.RowsDefaultCellStyle = dataGridViewCellStyle15;
            this.dgvResultados.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(15)))));
            this.dgvResultados.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvResultados.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.dgvResultados.Size = new System.Drawing.Size(792, 286);
            this.dgvResultados.TabIndex = 87;
            // 
            // test
            // 
            this.test.HeaderText = "test";
            this.test.Name = "test";
            this.test.ReadOnly = true;
            // 
            // test1
            // 
            this.test1.HeaderText = "test1";
            this.test1.Name = "test1";
            this.test1.ReadOnly = true;
            // 
            // test2
            // 
            this.test2.HeaderText = "test2";
            this.test2.Name = "test2";
            this.test2.ReadOnly = true;
            // 
            // tmrFadeIn
            // 
            this.tmrFadeIn.Enabled = true;
            this.tmrFadeIn.Tick += new System.EventHandler(this.tmrFadeIn_Tick);
            // 
            // Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(12)))), ((int)(((byte)(27)))));
            this.ClientSize = new System.Drawing.Size(1284, 690);
            this.Controls.Add(this.dgvResultados);
            this.Controls.Add(this.pnlLogoFondo);
            this.Controls.Add(this.pnlFormHijo);
            this.Controls.Add(this.pnl_lupita);
            this.Controls.Add(this.txtCI);
            this.Controls.Add(this.pnlLateralR);
            this.Controls.Add(this.pnlLateralL);
            this.Controls.Add(this.pnlCategorias);
            this.Controls.Add(this.pnlEncabez);
            this.ForeColor = System.Drawing.Color.BlueViolet;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Principal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Principal";
            this.pnlEncabez.ResumeLayout(false);
            this.pnlEncabez.PerformLayout();
            this.pnlBarraTitulo.ResumeLayout(false);
            this.pnlBarraTitulo.PerformLayout();
            this.pnlCategorias.ResumeLayout(false);
            this.pnlCategorias.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultados)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlEncabez;
        private System.Windows.Forms.Button btnPreferencias;
        private System.Windows.Forms.Panel pnlBarraTitulo;
        private System.Windows.Forms.Panel pnlLogoBarra;
        private System.Windows.Forms.Button btnCerrar;
        private System.Windows.Forms.Button btnMin;
        private System.Windows.Forms.Button btnMax;
        public System.Windows.Forms.Label lblCedula;
        private System.Windows.Forms.Label lblBienvenido;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel pnlCategorias;
        private System.Windows.Forms.Button btnProductos;
        private System.Windows.Forms.Panel pnlLateralL;
        private System.Windows.Forms.Panel pnl_lupita;
        private System.Windows.Forms.TextBox txtCI;
        private System.Windows.Forms.Panel pnlLateralR;
        private System.Windows.Forms.Panel pnlFormHijo;
        private System.Windows.Forms.Panel pnlLogoFondo;
        private System.Windows.Forms.Button btnCerrarSesion;
        private System.Windows.Forms.DataGridView dgvResultados;
        private System.Windows.Forms.DataGridViewTextBoxColumn test;
        private System.Windows.Forms.DataGridViewTextBoxColumn test1;
        private System.Windows.Forms.DataGridViewTextBoxColumn test2;
        private System.Windows.Forms.Panel pnlLogoPhoenix;
        private System.Windows.Forms.Label pnlCreditos;
        private System.Windows.Forms.Timer tmrFadeIn;
        private System.Windows.Forms.Button btnElegirDeposito;
        public System.Windows.Forms.Label lblDeposito;
    }
}