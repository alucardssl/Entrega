﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppSeguimiento

{
    public partial class CustomMessageBox : Form
    {
        public CustomMessageBox()
        {
            InitializeComponent();
        }

        public static CustomMessageBox costumMessageBox;
        public static byte Button_id;

        //Cada messageBox.show siempre tendrá un mensaje (string) y un título (string) que serán ingresados como parametros
        //Opcionalmente también podrán tener un botón de cancelar si se le envía un int como parámetro al final
        //si el int es un 0 entonces el botón de ok está en foco, si el int es un 1 entonces el botón de cancelar estará en foco

        public static void Show(string txtMessage, string titulo)
        {
            costumMessageBox = new CustomMessageBox();
            costumMessageBox.lblTitulo.Text = titulo;
            costumMessageBox.lblMensaje.Text = txtMessage;
            costumMessageBox.btnCancelar.Hide();
            costumMessageBox.btnOK.Left = 127;
            costumMessageBox.btnOK.Focus();
            costumMessageBox.btnOK.Text = "OK";
            costumMessageBox.Show();
            Button_id = 0;
        }

        public static int Show(string txtMessage, string titulo, byte opcion)
        {
            costumMessageBox = new CustomMessageBox();
            costumMessageBox.lblMensaje.Text = txtMessage;
            costumMessageBox.lblTitulo.Text = titulo;

            switch (opcion)
            {
                default:
                case 0:
                    costumMessageBox.btnOK.Focus();
                    costumMessageBox.btnOK.FlatAppearance.BorderSize = 1;
                    break;

                case 1:
                    costumMessageBox.btnCancelar.Focus();
                    costumMessageBox.btnCancelar.FlatAppearance.BorderSize = 1;
                    break;
            }
            costumMessageBox.ShowDialog();
            return Button_id;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            Button_id = 0;
            costumMessageBox.Dispose();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Button_id = 1;
            costumMessageBox.Dispose();
        }

        /*private void btnCerrar_Click(object sender, EventArgs e) //-S Esta roto porque deberia tomar un valor button_id dependiendo de las opciones en pantalla
        {
            costumMessageBox.Dispose();
        }

        private void btnMin_Click(object sender, EventArgs e) //-S Si quieren que el minimizar solo cierre esta ventana y no la del form que llama a este entonces hay que usar Show en vez de ShowDialog y ajustar la variable de button id para que no devuelva un valor en el momento en el que se abre y se vuelva a cerrar (y que sentido tendria poder minimzar esta ventana si no vas a poder interactar de ninguna manera con el form de abajo?)
        {
            costumMessageBox.WindowState = FormWindowState.Minimized;
        }*/



        //para mover el forms por el label

        private bool _dragging = false;
        private Point _offset;
        private Point _start_point = new Point(0, 0);

        private void pnlBarraTitulo_MouseDown(object sender, MouseEventArgs e)
        {
            _dragging = true;
            _start_point = new Point(e.X, e.Y);
        }

        private void pnlBarraTitulo_MouseMove(object sender, MouseEventArgs e)
        {
            if (_dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this._start_point.X, p.Y - this._start_point.Y);
            }
        }

        private void pnlBarraTitulo_MouseUp(object sender, MouseEventArgs e)
        {
            _dragging = false;
        }

        private void lblTitulo_MouseDown(object sender, MouseEventArgs e)
        {
            _dragging = true;
            _start_point = new Point(e.X, e.Y);
        }

        private void lblTitulo_MouseMove(object sender, MouseEventArgs e)
        {
            if (_dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this._start_point.X, p.Y - this._start_point.Y);
            }
        }

        private void lblTitulo_MouseUp(object sender, MouseEventArgs e)
        {
            _dragging = false;
        }

        //para mover el forms por el label
    }
}
