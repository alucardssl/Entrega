﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.Json;
using System.Data.OleDb;

namespace AppSeguimiento
{
    public partial class Login : Form
    {

        public int idioma;
        string upSerializado;

        public Login()
        {
            InitializeComponent();
            txtUsuario.Focus();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            Usuario up = new Usuario();
            up.usuario = txtUsuario.Text;
            up.contrasenia = txtPassword.Text;

            upSerializado = JsonSerializer.Serialize(up); //serializamos el usuario generado por el input del programa
            upSerializado = APIAutenticacion.ValidoUsuario(upSerializado); //ahora enviamos ese objeto serializado a la api

            up = JsonSerializer.Deserialize<Usuario>(upSerializado); //la API nos devuelve o bien su rol o un código de error

            if (up.rol == 1) //login exitoso
            {
                Program.frmPrincipal = new Principal();
                this.Hide();
                Program.frmPrincipal.lblCedula.Text = txtUsuario.Text;

                Program.frmPrincipal.ShowDialog();
                this.Close();
            }
            else
            {
                switch (Program.frmLogin.idioma)
                {
                    case 0:
                        CustomMessageBox.Show("Usuario o contraseña incorrectos. Código de error: " + up.rol, "Error");
                        return;
                    case 1:
                        CustomMessageBox.Show("Incorrect user or password. Error code: " + up.rol, "Error");
                        return;
                }
            }
        }
        public void ActualizarDataGridDeposito(IngresarDeposito frmIngresarProductos)
        {
            String sql = "select id, nombre, localizacion from deposito";
            DataTable dt = new DataTable();

            try
            {
                if (Program.cn.State == 1) // Si la conexión está abierta
                {
                    ADODB.Recordset rs = Program.cn.Execute(sql, out object filasAfectadas);
                    OleDbDataAdapter da = new OleDbDataAdapter();
                    da.Fill(dt, rs);
                    rs = null;
                }

                // Asigna los datos al DataGridView solo si aún no tiene un origen de datos
                if (frmIngresarProductos.dgvDepositos.DataSource == null)
                {
                    frmIngresarProductos.dgvDepositos.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                // Maneja la excepción según tus necesidades
                MessageBox.Show("Error al cargar datos: " + ex.Message);
            }
        }
        private void Login_Load(object sender, EventArgs e)
        {
            txtUsuario.Focus();
        }
        private void btnCerrar_Click(object sender, EventArgs e)
        {
            int respuesta;
            switch (Program.frmLogin.idioma)
            {
                case 0:
                    respuesta = CustomMessageBox.Show("¿Está seguro que desea salir de la aplicación?", "Saliendo de WingMaster", 1);
                    if (respuesta == 0)
                    {
                        this.Close();
                    }
                    return;
                case 1:
                    respuesta = CustomMessageBox.Show("Are you sure you want to exit the application?", "Exiting WingMaster", 1);
                    if (respuesta == 0)
                    {
                        this.Close();
                    }
                    return;
            }
            //int respuesta = CustomMessageBox.Show("¿Desea cerrar sesión?", "Cerrar sesión", 1);
        }

        private void btnMax_Click(object sender, EventArgs e)
        {
            if (WindowState != FormWindowState.Maximized)
            {
                WindowState = FormWindowState.Maximized;
            }
            else
            {
                WindowState = FormWindowState.Normal;
            }
        }

        private void btnMin_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void tmrFadeIn_Tick(object sender, EventArgs e) //Animación de aparición del formulario
        {
            if (Opacity == 1)
            {
                tmrFadeIn.Stop();
            }
            Opacity += .17; //Velocidad en la que aparece el formulario
        }

        private void pnlLogoPhoenix_Click(object sender, EventArgs e)
        {
            PagWeb frmPagWeb = new PagWeb();
            frmPagWeb.Show();
        }

        //para mover el forms por el label

        private bool _dragging = false;
        private Point _offset;
        private Point _start_point = new Point(0, 0);

        private void panel3_MouseDown(object sender, MouseEventArgs e)
        {
            _dragging = true;
            _start_point = new Point(e.X, e.Y);
        }

        private void panel3_MouseMove(object sender, MouseEventArgs e)
        {
            if (_dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this._start_point.X, p.Y - this._start_point.Y);
            }
        }

        private void panel3_MouseUp(object sender, MouseEventArgs e)
        {
            _dragging = false;
        }

        private void btnPreferencias_Click(object sender, EventArgs e)
        {
            Preferencias frmPreferencias = new Preferencias(this);
            frmPreferencias.Show();
        }

        public void actualizarTexto2()
        {
            switch (idioma)
            {
                case 0:
                    lblIngresar.Text = "Ingresar";
                    lblCI.Text = "ID";
                    lblContraseña.Text = "Contraseña";
                    btnLogin.Text = "Iniciar sesión";
                    lblBackoffice.Text = "Aplicación de Funcionario";
                    pnlCreditos.Text = "Desarrollado por";
                    break;
                case 1:
                    lblIngresar.Text = "Log in";
                    lblCI.Text = "ID";
                    lblContraseña.Text = "Password";
                    btnLogin.Text = "Log in";
                    lblBackoffice.Text = "Warehouse Clerk App";
                    pnlCreditos.Text = "Developed by";
                    break;
                default:
                    lblIngresar.Text = "Ingresar";
                    lblCI.Text = "ID";
                    lblContraseña.Text = "Contraseña";
                    btnLogin.Text = "Iniciar sesión";
                    lblBackoffice.Text = "Aplicación de Funcionario";
                    pnlCreditos.Text = "Desarrollado por";
                    break;
            }
        }
    }
}