﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace AppSeguimiento

{
    public partial class Principal: Form
    {
        public byte categoriaMenuActual = 3;
        /*Indicador de en que categoria está navegando el usuario en el menú
        0 -Inicio
        1 - Funcionarios
        2 - Camioneros
        3 - Camiones
        4 - Productos
        5 - Lotes
        6 - Depósitos
        */

        private bool _txtCiIntacto;
        private bool _txtNombreIntacto;

        public Principal()
        {

            InitializeComponent();
            actualizarTexto();
            Program.frmIngresarDeposito = new IngresarDeposito();
        }
        public void ActualizarDataGridProducto()
        {
            String sql = "select * from producto";
            DataTable dt = new DataTable();

            try
            {
                if (Program.cn.State == 1) // Si la conexión está abierta
                {
                    ADODB.Recordset rs = Program.cn.Execute(sql, out object filasAfectadas);
                    OleDbDataAdapter da = new OleDbDataAdapter();
                    da.Fill(dt, rs);
                    rs = null;
                }

                // Asigna los datos al DataGridView solo si aún no tiene un origen de datos
                if (dgvResultados.DataSource == null)
                {
                    dgvResultados.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                // Maneja la excepción según tus necesidades
                MessageBox.Show("Error al cargar datos: " + ex.Message);
            }
        }
        public void actualizarPantalla(byte nuevaCategoriaMenu)
        {
            //MessageBox.Show(Convert.ToString(pnlEncabez.Size.Width - btnFuncionarios.Size.Width));
            //MessageBox.Show(Convert.ToString(pnlLateralL.Size.Height));

            /*
            if (categoriaMenuActual == nuevaCategoriaMenu) //no me saquen esto de vuelta por favor
            {
                return;
            }*/
            //-S lo saco porque interfiere con botones que quieren actualizar la pantalla sin cambiar de categoria el menu

            btnProductos.BackColor = Color.FromArgb(5, 5, 15);

            txtCI.ForeColor = Color.FromArgb(80, 80, 95);
            pnlLateralL.Show();
            pnlLateralR.Show();
            pnlFormHijo.Hide();
            pnl_lupita.Hide();
            pnlLogoFondo.Hide();
            txtCI.Show();

            dgvResultados.Hide();
            pnlCategorias.Show();
            dgvResultados.Columns.Clear();
            IsMdiContainer = false;
            _txtCiIntacto = true;
            _txtNombreIntacto = true;

            categoriaMenuActual = nuevaCategoriaMenu;

            switch (nuevaCategoriaMenu)
            {
                case 0: //Ninguna categoría seleccionada / Pantalla inicial
                    pnlLogoFondo.Show();
                    txtCI.Hide();
                    dgvResultados.Hide();
                    break;
                case 1: //Categoría Productos seleccionada
                    btnProductos.BackColor = Color.FromArgb(12, 12, 27);
                    switch (Program.frmLogin.idioma)
                    {
                        case 0:
                            txtCI.Text = "Buscar ID de Producto...";
                            break;
                        case 1:
                            txtCI.Text = "Search in Products by ID...";
                            break;
                        default:
                            txtCI.Text = "Buscar ID de Producto...";
                            break;
                    }
                    pnl_lupita.Show();
                    actualizarDataGridProductos();
                    ActualizarDataGridProducto();
                    dgvResultados.Show();
                    break;
               
            } //switch
        }


        private Int32 numero(String valor)
        {
            Int32 retorno;
            if (!Int32.TryParse(valor, out retorno))
            {
                retorno = 0;
            }
            return (retorno);
        }

        public Boolean validaCI(int CI)
        {
            Boolean retorno = true;
            Int16 i;
            int calculoDigitoControl = 0;
            int digitoControl = CI % 10;
            int CIaux = CI / 10; //división entera
            if (CI < 100000)
            {
                retorno = false;
            }
            else
            {
                for (i = 1; i <= 7; i++)
                {
                    switch (i)
                    {
                        case 1:
                            calculoDigitoControl = calculoDigitoControl + (CIaux % 10) * 6;
                            break;
                        case 2:
                            calculoDigitoControl = calculoDigitoControl + (CIaux % 10) * 7;
                            break;
                        case 3:
                            calculoDigitoControl = calculoDigitoControl + (CIaux % 10) * 4;
                            break;
                        case 4:
                            calculoDigitoControl = calculoDigitoControl + (CIaux % 10) * 3;
                            break;
                        case 5:
                            calculoDigitoControl = calculoDigitoControl + (CIaux % 10) * 2;
                            break;
                        case 6:
                            calculoDigitoControl = calculoDigitoControl + (CIaux % 10) * 1;
                            break;
                        case 7:
                            calculoDigitoControl = calculoDigitoControl + (CIaux % 10) * 8;
                            break;
                    };
                    CIaux = CIaux / 10;
                }//for
                retorno = (calculoDigitoControl % 10 == digitoControl);
            }
            return (retorno);
        }

      
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            switch (categoriaMenuActual)
            {
                case 1: //Producto

                    Producto p = new Producto();
                    List<String> nombreLugares = new List<String>();
                    p.Id = numero(txtCI.Text);
                    p.conexion = Program.cn;

                    switch (p.buscar())
                    {
                        case 0:  //Encontré 
                            Program.frmProductos = new Productos();
                            p.buscarLugar();
                            abrirFormHijo(Program.frmProductos);
                            Program.frmProductos.lblID.Text = "CI: " + txtCI.Text;
                            Program.frmProductos.lblTitulo.Text = "Creacíon de Producto";
                            Program.frmProductos.txtCI.Text = txtCI.Text;
                            List<String> opcionesF = new List<String>() { "No", "Si" };
                            foreach (string Opcion in opcionesF)
                            {
                                Program.frmProductos.cboFragilidad.Items.Add(Opcion);
                            }
                            List<String> opcionesP = new List<String>() { "No", "Si" };
                            foreach (string Opcion in opcionesP)
                            {
                                Program.frmProductos.cboPrioridad.Items.Add(Opcion);
                            }
                            ActualizarDataGridLugarP(Program.frmProductos);
                            ActualizarDataGridDeposito(Program.frmProductos);
                            break;
                        case 1: //La conexión está cerrada.
                            MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                            break;
                        case 2:
                        case 4:
                            MessageBox.Show("Hubo errores al efectuar operación");
                            break;
                        case 3: //No encontré
                            if (CustomMessageBox.Show("Registro no encontrado ¿Desea efectuar el alta?", "¿Alta?", 0) == 0)
                            {
                                Program.frmPrincipal.abrirFormHijo(Program.frmProductos);
                                Program.frmProductos.lblID.Text = "ID: " + txtCI.Text;
                                p.buscarLugar();
                                Program.frmProductos.txtCI.Text = txtCI.Text;
                                List<String> opcionesF2 = new List<String>() { "No", "Si" };
                                foreach (string Opcion in opcionesF2)
                                {
                                    Program.frmProductos.cboFragilidad.Items.Add(Opcion);
                                }
                                List<String> opcionesP2 = new List<String>() { "No", "Si" };
                                foreach (string Opcion in opcionesP2)
                                {
                                    Program.frmProductos.cboPrioridad.Items.Add(Opcion);
                                }
                                ActualizarDataGridLugarP(Program.frmProductos);
                                ActualizarDataGridDeposito(Program.frmProductos);
                            }
                            break;
                    };
                    break;
                case 2: //Lotes

                    Lote l = new Lote();
                    List<String> nombreDestinos = new List<String>();
                    l.Id = int.Parse(txtCI.Text);
                    l.conexion = Program.cn;

                    switch (l.buscar())
                    {
                        case 0:  //Encontré 
                            Program.frmLotes = new Lotes();
                            abrirFormHijo(Program.frmLotes);
                            Program.frmLotes.lblID.Text = "ID: " + txtCI.Text;
                            Program.frmLotes.txtID.Text = txtCI.Text;
                            Program.frmLotes.lblTitulo.Text = "Creacíon de Lote";
                            List<String> opcionesF = new List<String>() { "No", "Si" };
                            foreach (string Opcion in opcionesF)
                            {
                                Program.frmLotes.cboPrioridad.Items.Add(Opcion);
                            }
                            ActualizarDataGridDepositoL(Program.frmLotes);
                            ActualizarDataGridLugarL(Program.frmLotes);
                            ActualizarDataGridProducto(Program.frmLotes);
                            break;
                        case 1: //La conexión está cerrada.
                            MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                            break;
                        case 2:
                        case 4:
                            MessageBox.Show("Hubo errores al efectuar operación");
                            break;
                        case 3: //No encontré
                            if (CustomMessageBox.Show("Registro no encontrado ¿Desea efectuar el alta?", "¿Alta?", 0) == 0)
                            {
                                Program.frmPrincipal.abrirFormHijo(Program.frmLotes);
                                Program.frmLotes.lblID.Text = "ID: " + txtCI.Text;
                                Program.frmLotes.txtID.Text = txtCI.Text;
                                Program.frmLotes.dgvProductos.Visible = false;
                                List<String> opcionesF2 = new List<String>() { "No", "Si" };
                                foreach (string Opcion in opcionesF2)
                                {
                                    Program.frmLotes.cboPrioridad.Items.Add(Opcion);
                                }
                            }
                            ActualizarDataGridDepositoL(Program.frmLotes);
                            ActualizarDataGridLugarL(Program.frmLotes);
                            break;
                    };
                    break;
            }
        }

        private void btnCerrarSesion_Click(object sender, EventArgs e) //Cerrar sesion
        {
            if (Program.cn.State == 1) //si la conexion esta abierta
            {
                int respuesta;
                switch (Program.frmLogin.idioma)
                {
                    case 0:
                        respuesta = CustomMessageBox.Show("¿Desea cerrar sesión?", "Cerrar sesión", 1);
                        if (respuesta == 0)
                        {

                            Program.cn.Close();
                            Program.frmLogin = new Login();
                            Hide();
                            Program.frmLogin.ShowDialog();
                            Dispose();
                            //Close();
                        }
                        return;
                    case 1:
                        respuesta = CustomMessageBox.Show("Do you want to log out?", "Log out", 1);
                        if (respuesta == 0)
                        {

                            Program.cn.Close();
                            Program.frmLogin = new Login();
                            Hide();
                            Program.frmLogin.ShowDialog();
                            Dispose();
                            //Close();
                        }
                        return;
                }
                //int respuesta = CustomMessageBox.Show("¿Desea cerrar sesión?", "Cerrar sesión", 1);
            }
        }

        public void maximizarPantalla()
        {
            if (WindowState != FormWindowState.Maximized) //Si la ventana no está maximizada...
            {
                WindowState = FormWindowState.Maximized;
            }
            else
            {
                WindowState = FormWindowState.Normal;
            }
        }

        private void btnMax_Click(object sender, EventArgs e) //Maximizar pantalla
        {
            maximizarPantalla();
        }

        private void pnlBarraTitulo_DoubleClick(object sender, EventArgs e) //Otra forma de maximizar la pantalla más práctica
        {
            maximizarPantalla();
        }

        private void btnMin_Click(object sender, EventArgs e) //Minimizar pantalla
        {
            WindowState = FormWindowState.Minimized;
        }


        private void btnCerrar_Click(object sender, EventArgs e) //Cerrar aplicación
        {
            int respuesta;
            switch (Program.frmLogin.idioma)
            {
                case 0:
                    respuesta = CustomMessageBox.Show("¿Está seguro que desea salir de la aplicación?", "Saliendo de WingMaster", 1);
                    if (respuesta == 0)
                    {
                        Program.cn.Close();
                        this.Close();
                    }
                    return;
                case 1:
                    respuesta = CustomMessageBox.Show("Are you sure you want to exit the application?", "Exiting WingMaster", 1);
                    if (respuesta == 0)
                    {
                        Program.cn.Close();
                        this.Close();
                    }
                    return;
            }
        }

        private void tmrFadeIn_Tick(object sender, EventArgs e) //Animación de entrada del formulario
        {
            if (Opacity == 1)
            {
                tmrFadeIn.Stop();
            }
            Opacity += .17; //Marca la velocidad en la que el formulario entra
        }

        private void txtCI_Enter(object sender, EventArgs e) //para borrar el texto placeholder al hacer click y resaltar el texto en blanco más claro 
        {
            txtCI.ForeColor = Color.White;

            if (_txtCiIntacto)
            {
                txtCI.Text = "";
                _txtCiIntacto = false;
            }
        }

        private void btnProductos_Click(object sender, EventArgs e)
        {
            actualizarPantalla(1);
        }

        private void btnLotes_Click(object sender, EventArgs e)
        {
            actualizarPantalla(2);
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {

            switch (categoriaMenuActual)
            {

                case 1: //Camioneros

                    Program.frmProductos = new Productos();
                    Producto p = new Producto();
                    p.Id = int.Parse(txtCI.Text);
                    p.conexion = Program.cn;

                    switch (p.buscar())
                    {
                        case 0:  //Encontré 
                            p.EliminarProducto();
                            CustomMessageBox.Show("Producto eliminado exitosamente.", "Mensaje");
                            break;
                        case 1: //La conexión está cerrada.
                            MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                            break;
                        case 2:
                        case 4:
                            MessageBox.Show("Hubo errores al efectuar operación");
                            break;
                        case 3: //No encontré
                            Program.existeCI = false;

                            CustomMessageBox.Show("El Producto no existe en el sistema", "Error");
                            return;
                    };
                    break;
                case 2: //Lotes

                    Program.frmLotes = new Lotes();
                    Lote l = new Lote();
                    l.Id = int.Parse(txtCI.Text);
                    l.conexion = Program.cn;

                    switch (l.buscar())
                    {
                        case 0:  //Encontré 
                            l.EliminarLote();
                            CustomMessageBox.Show("Lote eliminado exitosamente.", "Mensaje");
                            l = null;
                            break;
                        case 1: //La conexión está cerrada.
                            MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                            break;
                        case 2:
                        case 4:
                            MessageBox.Show("Hubo errores al efectuar operación");
                            break;
                        case 3: //No encontré
                            Program.existeCI = false;

                            CustomMessageBox.Show("El Producto no existe en el sistema", "Error");
                            return;
                    };
                    l = null;
                    break;
            }
        }

        private Form frmActivo = null;

        public void abrirFormHijo(Form frmHijo)
        {
            IsMdiContainer = true;
            if (frmActivo != null)
                frmActivo.Close();
            frmHijo = frmActivo;
            pnlFormHijo.Show();
            pnlFormHijo.Dock = DockStyle.Fill;
            switch (categoriaMenuActual)
            {
                case 1:
                    Program.frmProductos = new Productos();
                    frmHijo = Program.frmProductos;
                    Program.frmProductos.actualizarTexto();
                    break;
                case 2:
                    Program.frmLotes = new Lotes();
                    frmHijo = Program.frmLotes;
                    Program.frmLotes.actualizarTexto();
                    break;
                case 3:
                    Program.frmIngresarDeposito = new IngresarDeposito();
                    frmHijo = Program.frmIngresarDeposito;
                    pnlCategorias.Hide();
                    pnlLogoFondo.Hide();
                    break;
            }
            //MessageBox.Show(Convert.ToString(categoriaMenuActual));

            dgvResultados.Hide();
            pnl_lupita.Hide();
            pnlLateralL.Hide();
            pnlLateralR.Hide();
            txtCI.Hide();

            frmHijo.MdiParent = this;
            frmHijo.TopLevel = false;
            frmHijo.Dock = DockStyle.Fill;
            pnlFormHijo.Show();
            pnlFormHijo.Controls.Add(frmHijo);
            pnlFormHijo.Tag = frmHijo;
            frmHijo.BringToFront();
            frmHijo.Show();
        }
        private void pnlLogoPhoenix_Click(object sender, EventArgs e)
        {
            actualizarPantalla(0);
        }

        public void actualizarDataGridProductos()
        {
            String sql;
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter();
            
            ADODB.Recordset rs = new ADODB.Recordset();
            object filasAfectadas = new object();
            dgvResultados.DataSource = null;

            if (Program.cn.State == 1) //Si la conexion esta abierta
            {
                //MessageBox.Show(Convert.ToString(categoriaMenuActual));
                sql = "select * from producto where ubicadoEn = " + lblDeposito.Tag;
                try
                {
                    rs = Program.cn.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    return;
                }
            }

            dgvResultados.DataSource = null;
            dgvResultados.Rows.Clear();
            dgvResultados.Columns.Clear();
            da.Fill(dt, rs);
            dgvResultados.DataSource = dt;
            //dgvResultados.AutoSizeColumnsMode=  DataGridViewAutoSizeColumnsMode.DisplayedCells;
            /*while (!rs.EOF) //mientras no llegue al fin 
            {
                dgvResultados.Rows.Add(Convert.ToString(rs.Fields[0].Value));
                rs.MoveNext(); //nos movemos al siguiente registro
            }*/
            rs = null;
            filasAfectadas = null;
            return;
        }
        public void actualizarDataGridLotes()
        {
            String sql;
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter();

            ADODB.Recordset rs = new ADODB.Recordset();
            object filasAfectadas = new object();
            dgvResultados.DataSource = null;

            if (Program.cn.State == 1) //Si la conexion esta abierta
            {
                //MessageBox.Show(Convert.ToString(categoriaMenuActual));
                sql = "select * from lote where ubicadoEn = " + lblDeposito.Tag;
                try
                {
                    rs = Program.cn.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    return;
                }
            }

            dgvResultados.DataSource = null;
            dgvResultados.Rows.Clear();
            dgvResultados.Columns.Clear();
            da.Fill(dt, rs);
            dgvResultados.DataSource = dt;
            //dgvResultados.AutoSizeColumnsMode=  DataGridViewAutoSizeColumnsMode.DisplayedCells;
            /*while (!rs.EOF) //mientras no llegue al fin 
            {
                dgvResultados.Rows.Add(Convert.ToString(rs.Fields[0].Value));
                rs.MoveNext(); //nos movemos al siguiente registro
            }*/
            rs = null;
            filasAfectadas = null;
            return;
        }
        private void txtCI_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtCI.Text.Length == 1) //Comienza a tomar efecto despues del tercer digito para no sobrecargar la busqueda cuando todavia hay muchos registros
            {
                actualizarDataGridProductos();
            }
        }


        //para mover el forms por el label

        private bool _dragging = false;
        private Point _offset;
        private Point _start_point = new Point(0, 0);

        private void pnlBarraTitulo_MouseDown(object sender, MouseEventArgs e)
        {
            _dragging = true;
            _start_point = new Point(e.X, e.Y);
        }

        private void pnlBarraTitulo_MouseMove(object sender, MouseEventArgs e)
        {
            if (_dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this._start_point.X, p.Y - this._start_point.Y);
            }
        }

        private void pnlBarraTitulo_MouseUp(object sender, MouseEventArgs e)
        {
            _dragging = false;
        }

        private void btnPreferencias_Click(object sender, EventArgs e)
        {
            Preferencias frmPreferencias = new Preferencias(Program.frmLogin);
            frmPreferencias.Show();
        }

        public void actualizarTexto()
        {
            switch (Program.frmLogin.idioma)
            {
                case 0:
                    lblBienvenido.Text = "Bienvenido/a, ";
                    btnProductos.Text = "Productos";
                    btnCerrarSesion.Text = "Cerrar sesión";
                    pnlCreditos.Text = "desarrollado por";
                    lblDeposito.Text = "Depósito: "+ lblDeposito.Tag;
                    btnElegirDeposito.Text = "Atrás";
                    break;
                case 1:
                    lblBienvenido.Text = "Welcome, ";
                    btnProductos.Text = "Products";
                    btnCerrarSesion.Text = "Log out";
                    pnlCreditos.Text = "developed by";
                    lblDeposito.Text = "Warehouse: " + lblDeposito.Tag;
                    btnElegirDeposito.Text = "Back";
                    break;
                default:
                    lblBienvenido.Text = "Bienvenido/a, ";
                    btnProductos.Text = "Productos";
                    btnCerrarSesion.Text = "Cerrar sesión";
                    pnlCreditos.Text = "desarrollado por";
                    lblDeposito.Text = "Depósito: " + lblDeposito.Tag;
                    btnElegirDeposito.Text = "Atrás";
                    break;
            }
        }
        public void actualizarTextoCategoria(int categoria)
        {
            switch (categoriaMenuActual)
            {
                case 0: //Ninguna categoría seleccionada / Pantalla inicial
                    break;
                case 1: //Categoría Productos seleccionada
                    switch (Program.frmLogin.idioma)
                    {
                        case 0:
                            txtCI.Text = "Buscar ID de Producto...";
                            break;
                        case 1:
                            txtCI.Text = "Search in Products by ID...";
                            break;
                        default:
                            txtCI.Text = "Buscar ID de Producto...";
                            break;
                    }
                    break;
                case 2: //Categoría Lotes seleccionada
                    switch (Program.frmLogin.idioma)
                    {
                        case 0:
                            txtCI.Text = "Buscar ID de Lote...";
                            break;
                        case 1:
                            txtCI.Text = "Search in Packages by ID...";
                            break;
                        default:
                            txtCI.Text = "Buscar ID de Lote...";
                            break;
                    }
                    break;
            }
        }

        private void btnElegirDeposito_Click(object sender, EventArgs e)
        {
            categoriaMenuActual = 3;
            abrirFormHijo(Program.frmIngresarDeposito);
        }
        public void actualizarDataGridCamion(AsignarLote frmAsignarLote)
        {
            String sql = "select id, matricula from camion";
            DataTable dt = new DataTable();

            try
            {
                if (Program.cn.State == 1) // Si la conexión está abierta
                {
                    ADODB.Recordset rs = Program.cn.Execute(sql, out object filasAfectadas);
                    OleDbDataAdapter da = new OleDbDataAdapter();
                    da.Fill(dt, rs);
                    rs = null;
                }

                // Asigna los datos al DataGridView solo si aún no tiene un origen de datos
                if (frmAsignarLote.dgvCamion.DataSource == null)
                {
                    frmAsignarLote.dgvCamion.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                // Maneja la excepción según tus necesidades
                MessageBox.Show("Error al cargar datos: " + ex.Message);
            }
        }
        public void actualizarDataGridLote(AsignarLote frmAsignarLote)
        {
            String sql = "select id, destino from lote";
            DataTable dt = new DataTable();

            try
            {
                if (Program.cn.State == 1) // Si la conexión está abierta
                {
                    ADODB.Recordset rs = Program.cn.Execute(sql, out object filasAfectadas);
                    OleDbDataAdapter da = new OleDbDataAdapter();
                    da.Fill(dt, rs);
                    rs = null;
                }

                // Asigna los datos al DataGridView solo si aún no tiene un origen de datos
                if (frmAsignarLote.dgvLote.DataSource == null)
                {
                    frmAsignarLote.dgvLote.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                // Maneja la excepción según tus necesidades
                MessageBox.Show("Error al cargar datos: " + ex.Message);
            }
        }
        public void ActualizarDataGridLugarL(Lotes frmLotes)
        {
            String sql = "select id, nombre from lugar";
            DataTable dt = new DataTable();

            try
            {
                if (Program.cn.State == 1) // Si la conexión está abierta
                {
                    ADODB.Recordset rs = Program.cn.Execute(sql, out object filasAfectadas);
                    OleDbDataAdapter da = new OleDbDataAdapter();
                    da.Fill(dt, rs);
                    rs = null;
                }

                // Asigna los datos al DataGridView solo si aún no tiene un origen de datos
                if (frmLotes.dgvDestino.DataSource == null)
                {
                    frmLotes.dgvDestino.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                // Maneja la excepción según tus necesidades
                MessageBox.Show("Error al cargar datos: " + ex.Message);
            }
        }
        public void ActualizarDataGridProducto(Lotes frmLotes)
        {
            String sql = "select id, nombre, destino from producto where ubicadoEn = " + lblDeposito.Tag;
            DataTable dt = new DataTable();

            try
            {
                if (Program.cn.State == 1) // Si la conexión está abierta
                {
                    ADODB.Recordset rs = Program.cn.Execute(sql, out object filasAfectadas);
                    OleDbDataAdapter da = new OleDbDataAdapter();
                    da.Fill(dt, rs);
                    rs = null;
                }

                // Asigna los datos al DataGridView solo si aún no tiene un origen de datos
                if (frmLotes.dgvProductos.DataSource == null)
                {
                    frmLotes.dgvProductos.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                // Maneja la excepción según tus necesidades
                MessageBox.Show("Error al cargar datos: " + ex.Message);
            }
        }
        public void ActualizarDataGridDepositoL(Lotes frmLotes)
        {
            String sql = "select id, nombre, localizacion from deposito where id = " + lblDeposito.Tag; 
            DataTable dt = new DataTable();

            try
            {
                if (Program.cn.State == 1) // Si la conexión está abierta
                {
                    ADODB.Recordset rs = Program.cn.Execute(sql, out object filasAfectadas);
                    OleDbDataAdapter da = new OleDbDataAdapter();
                    da.Fill(dt, rs);
                    rs = null;
                }

                // Asigna los datos al DataGridView solo si aún no tiene un origen de datos
                if (frmLotes.dgvDepositos.DataSource == null)
                {
                    frmLotes.dgvDepositos.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                // Maneja la excepción según tus necesidades
                MessageBox.Show("Error al cargar datos: " + ex.Message);
            }
        }
        public void ActualizarDataGridDeposito(Productos frmProductos)
        {
            String sql = "select id, nombre, localizacion from deposito where id = " + lblDeposito.Tag; 
            DataTable dt = new DataTable();

            try
            {
                if (Program.cn.State == 1) // Si la conexión está abierta
                {
                    ADODB.Recordset rs = Program.cn.Execute(sql, out object filasAfectadas);
                    OleDbDataAdapter da = new OleDbDataAdapter();
                    da.Fill(dt, rs);
                    rs = null;
                }

                // Asigna los datos al DataGridView solo si aún no tiene un origen de datos
                if (frmProductos.dgvDeposito.DataSource == null)
                {
                    frmProductos.dgvDeposito.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                // Maneja la excepción según tus necesidades
                MessageBox.Show("Error al cargar datos: " + ex.Message);
            }
        }
        public void ActualizarDataGridLugarP(Productos frmProductos)
        {
            String sql = "select id, nombre from lugar";
            DataTable dt = new DataTable();

            try
            {
                if (Program.cn.State == 1) // Si la conexión está abierta
                {
                    ADODB.Recordset rs = Program.cn.Execute(sql, out object filasAfectadas);
                    OleDbDataAdapter da = new OleDbDataAdapter();
                    da.Fill(dt, rs);
                    rs = null;
                }

                // Asigna los datos al DataGridView solo si aún no tiene un origen de datos
                if (frmProductos.dgvDestino.DataSource == null)
                {
                    frmProductos.dgvDestino.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                // Maneja la excepción según tus necesidades
                MessageBox.Show("Error al cargar datos: " + ex.Message);
            }
        }
        private void btnAsignar_Click(object sender, EventArgs e)
        {
            
            Program.frmAsignarLote = new AsignarLote();
            actualizarDataGridCamion(Program.frmAsignarLote);
            actualizarDataGridLote(Program.frmAsignarLote);
            Program.frmAsignarLote.Show();
        }
    }
}
