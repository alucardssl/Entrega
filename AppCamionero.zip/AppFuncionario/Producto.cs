﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppFuncionario
{
    class Producto
    {
        private int _idCamion;
        private int _id;
        private int _idDestino;
        private int _idLugar;
        private String _nombre;
        private String _descripcion;
        private float _volumen;
        private float _peso;
        private DateTime _fechaLimite;
        private int _fragilidad;
        private int _prioridad;
        private String _nombreCliente;
        private String _mailCliente;
        private String _nombreDestino;
        private float _latitudDestino;
        private float _longitudDestino;
        private String _direccionDestino;
        private String _departamentoDestino;
        private List<String> _nombreLugar;
        private ADODB.Connection _conexion;


        public Producto()
        {
            _idCamion = 0;
            _id = 0;
            _idDestino = 0;
            _idLugar = 0;
            _nombre = "";
            _descripcion = "";
            _volumen = 0;
            _peso = 0;
            _fechaLimite = new DateTime();
            _fragilidad = 0;
            _prioridad = 0;
            _nombreCliente = "";
            _mailCliente = "";
            _nombreDestino = "";
            _latitudDestino = 0;
            _longitudDestino = 0;
            _direccionDestino = "";
            _departamentoDestino = "";
            _nombreLugar = new List<String>();
            _conexion = new ADODB.Connection();
        }

        public Producto(int idCamion, int ID, int idDestino, List<String> nombreLugar, int idLugar, string nombre, string descripcion, float volumen, float peso, DateTime fechaLimite, int fragilidad, int prioridad, string nombreCliente, string mailCliente, string nombreDestino, float latitudDestino, float longitudDestino, string direccionDestino, string departamentoDestino, ADODB.Connection cn)
        {
            _idCamion = idCamion;
            _id = ID;
            _idLugar = idLugar;
            _nombreLugar = nombreLugar;
            _nombre = nombre;
            _descripcion = descripcion;
            _volumen = volumen;
            _peso = peso;
            _idDestino = idDestino;
            _fechaLimite = fechaLimite;
            _fragilidad = fragilidad;
            _prioridad = prioridad;
            _nombreCliente = nombreCliente;
            _mailCliente = mailCliente;
            _nombreDestino = nombreDestino;
            _latitudDestino = latitudDestino;
            _longitudDestino = longitudDestino;
            _direccionDestino = direccionDestino;
            _departamentoDestino = departamentoDestino;
            _conexion = cn;
        }
        public List<String> NombreLugar { get => _nombreLugar; set => _nombreLugar = value; }
        public int IdCamion { get => _id; set => _idCamion = value; }
        public int Id { get => _id; set => _id = value; }
        public int IdLugar { get => _idLugar; set => _idLugar = value; }
        public int IdDestino { get => _idDestino; set => _idDestino = value; }
        public string Nombre { get => _nombre; set => _nombre = value; }
        public string Descripcion { get => _descripcion; set => _descripcion = value; }
        public float Volumen { get => _volumen; set => _volumen = value; }
        public float Peso { get => _peso; set => _peso = value; }
        public DateTime FechaLimite { get => _fechaLimite; set => _fechaLimite = value; }
        public int Fragilidad { get => _fragilidad; set => _fragilidad = value; }
        public int Prioridad { get => _prioridad; set => _prioridad = value; }
        public string NombreCliente { get => _nombreCliente; set => _nombreCliente = value; }
        public string MailCliente { get => _mailCliente; set => _mailCliente = value; }
        public string NombreDestino { get => _nombreDestino; set => _nombreDestino = value; }
        public float LatitudDestino { get => _latitudDestino; set => _latitudDestino = value; }
        public float LongitudDestino { get => _longitudDestino; set => _longitudDestino = value; }
        public string DireccionDestino { get => _direccionDestino; set => _direccionDestino = value; }
        public string DepartamentoDestino { get => _departamentoDestino; set => _departamentoDestino = value; }

        public ADODB.Connection conexion
        {
            get { return (_conexion); }
            set { _conexion = value; }
        }

        public int buscar()
        {
            int retorno = 0; //por defecto asumo que no hubieron errores.
            //object cantFilas;
            ADODB.Recordset rs = new ADODB.Recordset();
            string sql;


            if (_conexion.State == 0)
            {
                retorno = 1; //conexión cerrada.
            }
            else
            {
                Program.cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient;
                sql = "select id from producto where id=" + _id;
                try
                {
                    //rs = _conexion.Execute(sql, out cantFilas, -1);   
                    rs.Open(sql, _conexion, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly, -1);
                }
                catch
                {
                    return 2; //error al ejecutar la consulta.
                }
                if (rs.RecordCount == 0)
                {
                    return 3; //No se encontró registro alguno.
                }
                Program.cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient;
                rs.Close();
                rs = null; // destruyo el objeto.
            }//if
            return (retorno);
        }

        public int buscarLugar()
        {
            int retorno = 0; // Por defecto, asumimos que no hubo errores.
            ADODB.Recordset rs = new ADODB.Recordset();
            string sql;

            if (_conexion.State == 0)
            {
                retorno = 1; // Conexión cerrada.
            }
            else
            {
                // Consulta para la tabla 'lugar'
                sql = "SELECT nombre FROM lugar";
                try
                {
                    rs.Open(sql, _conexion, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly, -1);
                    _nombreLugar.Clear();
                    while (!rs.EOF)
                    {
                        _nombreLugar.Add(rs.Fields[0].Value);
                        rs.MoveNext();
                    }
                    rs.Close();
                }
                catch
                {
                    return 2; // Error al ejecutar la consulta de nombre de lugar
                }

                Program.cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient;
                rs = null; // Destruyo el objeto.
            }

            return retorno;
        }

        public byte CrearProducto()
        {
            object filasAfectadas;
            string sql;
            byte resultado = 0;

            if (_conexion.State == 0)
            {
                resultado = 1; // La conexión está cerrada.
            }
            else
            {
                // Componer la consulta de inserción para la tabla 'producto'
                sql = "INSERT INTO producto (id,nombre, descripcion, volumen, peso, fechaLimite, prioridad, fragilidad, ubicadoEN, destino) VALUES " +
                      "(" + _id + ",'" + _nombre + "','" + _descripcion + "'," + _volumen + "," +
                      _peso + ",'" + _fechaLimite.ToString("yyyy-MM-dd") + "'," +
                      _prioridad + "," + _fragilidad + "," + _idDestino + "," + _idLugar + ")";

                /*try
                {*/
                _conexion.Execute(sql, out filasAfectadas);
                /*}
                catch
                {
                    return 2; // Error al ejecutar la consulta de inserción
                }*/
            }
            return resultado;
        }


        public byte ModificarProducto()
        {
            object filasAfectadas;
            string sql;
            byte resultado = 0;

            if (_conexion.State == 0)
            {
                resultado = 1; // La conexión está cerrada.
            }
            else
            {
                // Componer la consulta de actualización para la tabla 'producto'
                sql = "UPDATE producto SET nombre = '" + _nombre + "', descripcion = '" + _descripcion + "', " +
       "volumen = " + _volumen + ", peso = " + _peso + ", " +
       "fechaLimite = '" + _fechaLimite.ToString("yyyy-MM-dd") + "', " +
       "prioridad = " + _prioridad + ", fragilidad = " + _fragilidad + ", " +
       "ubicadoEn = " + _idDestino + ", destino = " + _idLugar + " WHERE id = " + _id;

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    return 2; // Error al ejecutar la consulta de actualización
                }
            }
            return resultado;
        }
        public byte EliminarProducto()
        {
            object filasAfectadas;
            string sql;
            byte resultado = 0;

            if (_conexion.State == 0)
            {
                resultado = 1; // La conexión no está abierta
            }
            else
            {

                sql = "DELETE FROM productoDentroDeLote WHERE productoDentro=" + _id;

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 2; // Error al ejecutar la consulta de eliminación
                }
                // Componer la consulta de eliminación para la tabla 'camion'
                sql = "DELETE FROM producto WHERE id=" + _id;

                try
                {
                    _conexion.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    resultado = 3; // Error al ejecutar la consulta de eliminación
                }

            }

            return resultado;
        }
    }
}

