﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppFuncionario
{
    public partial class AsignarLote : Form
    {
        public AsignarLote()
        {
            InitializeComponent();
        }

        private void btnAsignarLote_Click(object sender, EventArgs e)
        {
            AsignacionLote a = new AsignacionLote();
            a.idCamion = int.Parse(txtIdCamion.Text);
            a.idLote = int.Parse(txtIdLote.Text);
            a.conexion = Program.cn;

            switch (a.AsignarLote())
            {
                case 0:  //Se pudo efectuar el alta o modificación sin problemas.
                    MessageBox.Show("Asignado correctamente");
                    this.Close();
                    break;
                case 1: //La conexión está cerrada.
                    MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                    break;
                case 2:
                    MessageBox.Show("2");
                    break;
                case 3:
                    MessageBox.Show("3");
                    break;
            }
            Program.frmPrincipal.actualizarPantalla(2);
            a = null;
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AsignacionLote a = new AsignacionLote();
            a.idLote = int.Parse(txtIdLote.Text);
            a.conexion = Program.cn;

            switch (a.EliminarLote())
            {
                case 0:  //Se pudo efectuar el alta o modificación sin problemas.
                    MessageBox.Show("Desasignado correctamente");
                    this.Close();
                    break;
                case 1: //La conexión está cerrada.
                    MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                    break;
                case 2:
                    MessageBox.Show("2");
                    break;
                case 3:
                    MessageBox.Show("3");
                    break;
            }
            Program.frmPrincipal.actualizarPantalla(2);
            a = null;
            this.Close();
        }
    }
    
}
