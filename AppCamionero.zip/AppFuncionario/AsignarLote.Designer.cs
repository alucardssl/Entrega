﻿namespace AppFuncionario
{
    partial class AsignarLote
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAsignarLote = new System.Windows.Forms.Button();
            this.txtIdCamion = new System.Windows.Forms.TextBox();
            this.txtIdLote = new System.Windows.Forms.TextBox();
            this.lblIdCamion = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblHoraEngrega = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnAsignarLote
            // 
            this.btnAsignarLote.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAsignarLote.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAsignarLote.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(25)))));
            this.btnAsignarLote.FlatAppearance.BorderSize = 0;
            this.btnAsignarLote.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAsignarLote.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAsignarLote.ForeColor = System.Drawing.Color.BlueViolet;
            this.btnAsignarLote.Location = new System.Drawing.Point(199, 208);
            this.btnAsignarLote.Name = "btnAsignarLote";
            this.btnAsignarLote.Size = new System.Drawing.Size(155, 44);
            this.btnAsignarLote.TabIndex = 168;
            this.btnAsignarLote.Text = "Asignar Lote";
            this.btnAsignarLote.UseVisualStyleBackColor = true;
            this.btnAsignarLote.Click += new System.EventHandler(this.btnAsignarLote_Click);
            // 
            // txtIdCamion
            // 
            this.txtIdCamion.AccessibleRole = System.Windows.Forms.AccessibleRole.Cursor;
            this.txtIdCamion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.txtIdCamion.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtIdCamion.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIdCamion.ForeColor = System.Drawing.Color.White;
            this.txtIdCamion.Location = new System.Drawing.Point(47, 66);
            this.txtIdCamion.Name = "txtIdCamion";
            this.txtIdCamion.Size = new System.Drawing.Size(198, 22);
            this.txtIdCamion.TabIndex = 169;
            // 
            // txtIdLote
            // 
            this.txtIdLote.AccessibleRole = System.Windows.Forms.AccessibleRole.Cursor;
            this.txtIdLote.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.txtIdLote.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtIdLote.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIdLote.ForeColor = System.Drawing.Color.White;
            this.txtIdLote.Location = new System.Drawing.Point(302, 66);
            this.txtIdLote.Name = "txtIdLote";
            this.txtIdLote.Size = new System.Drawing.Size(198, 22);
            this.txtIdLote.TabIndex = 170;
            // 
            // lblIdCamion
            // 
            this.lblIdCamion.AutoSize = true;
            this.lblIdCamion.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.lblIdCamion.Location = new System.Drawing.Point(42, 38);
            this.lblIdCamion.Name = "lblIdCamion";
            this.lblIdCamion.Size = new System.Drawing.Size(113, 25);
            this.lblIdCamion.TabIndex = 171;
            this.lblIdCamion.Text = "ID Camion";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(297, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 25);
            this.label1.TabIndex = 172;
            this.label1.Text = "ID Lote";
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(25)))));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.BlueViolet;
            this.button1.Location = new System.Drawing.Point(403, 113);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(186, 44);
            this.button1.TabIndex = 173;
            this.button1.Text = "Desasignar Lote";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.AccessibleRole = System.Windows.Forms.AccessibleRole.Cursor;
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.White;
            this.textBox1.Location = new System.Drawing.Point(156, 152);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(198, 22);
            this.textBox1.TabIndex = 174;
            // 
            // lblHoraEngrega
            // 
            this.lblHoraEngrega.AutoSize = true;
            this.lblHoraEngrega.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.lblHoraEngrega.Location = new System.Drawing.Point(194, 123);
            this.lblHoraEngrega.Name = "lblHoraEngrega";
            this.lblHoraEngrega.Size = new System.Drawing.Size(113, 25);
            this.lblHoraEngrega.TabIndex = 175;
            this.lblHoraEngrega.Text = "ID Camion";
            // 
            // AsignarLote
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblHoraEngrega);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblIdCamion);
            this.Controls.Add(this.txtIdLote);
            this.Controls.Add(this.txtIdCamion);
            this.Controls.Add(this.btnAsignarLote);
            this.Name = "AsignarLote";
            this.Text = "AsignarLote";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public System.Windows.Forms.Button btnAsignarLote;
        private System.Windows.Forms.TextBox txtIdCamion;
        private System.Windows.Forms.TextBox txtIdLote;
        private System.Windows.Forms.Label lblIdCamion;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblHoraEngrega;
    }
}