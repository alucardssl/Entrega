﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppFuncionario
{
    public partial class Productos : Form
    {
        public Productos()
        {
            InitializeComponent();
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            Program.frmPrincipal.actualizarPantalla(1);
            this.Close();
        }

        private void btnCrear_Click(object sender, EventArgs e)
        {
            Producto p = new Producto();
            p.Id = int.Parse(txtCI.Text);
            p.IdLugar = int.Parse(txtDestino.Text);
            p.IdDestino = int.Parse(txtDeposito.Text);
            p.Nombre = txtNombre.Text;
            p.Descripcion = txtDescripcion.Text;
            p.Volumen = int.Parse(txtVolumen.Text);
            p.Peso = int.Parse(txtPeso.Text);
            p.FechaLimite = dtpFechaLim.Value;
            p.Prioridad = cboPrioridad.SelectedIndex;
            p.Fragilidad = cboFragilidad.SelectedIndex;
            p.conexion = Program.cn;

            switch (p.CrearProducto())
            {
                case 0:  //Se pudo efectuar el alta o modificación sin problemas.
                    MessageBox.Show("Producto creado correctamente");
                    this.Close();
                    break;
                case 1: //La conexión está cerrada.
                    MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                    break;
                case 2:
                    MessageBox.Show("2");
                    break;
                case 3:
                    MessageBox.Show("3");
                    break;
            }
            Program.frmPrincipal.actualizarPantalla(1);
            p = null;
            this.Close();
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {

            Producto p = new Producto();
            p.Id = int.Parse(txtCI.Text);
            p.IdLugar = int.Parse(txtDestino.Text);
            p.IdDestino = int.Parse(txtDeposito.Text);
            p.Nombre = txtNombre.Text;
            p.Descripcion = txtDescripcion.Text;
            p.Volumen = int.Parse(txtVolumen.Text);
            p.Peso = int.Parse(txtPeso.Text);
            p.FechaLimite = dtpFechaLim.Value;
            p.Prioridad = cboPrioridad.SelectedIndex;
            p.Fragilidad = cboFragilidad.SelectedIndex;
            p.conexion = Program.cn;

            switch (p.ModificarProducto())
            {
                case 0:  //Se pudo efectuar el alta o modificación sin problemas.
                    MessageBox.Show("Producto modificado correctamente");
                    break;
                case 1: //La conexión está cerrada.
                    MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                    break;
                case 2:
                    MessageBox.Show("2");
                    break;
                case 3:
                    MessageBox.Show("3");
                    break;
            }
            Program.frmPrincipal.actualizarPantalla(1);
            p = null;
            this.Close();
        }
    }
}
