﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace AppFuncionario

{
    public partial class Principal: Form
    {
        public byte categoriaMenuActual = 1;
        /*Indicador de en que categoria está navegando el usuario en el menú
        0 -Inicio
        1 - Funcionarios
        2 - Camioneros
        3 - Camiones
        4 - Productos
        5 - Lotes
        6 - Depósitos
        */

        private bool _txtCiIntacto;
        private bool _txtNombreIntacto;

        public Principal()
        {

            InitializeComponent();
            actualizarTexto();
            actualizarPantalla(0);
        }

        public void actualizarPantalla(byte nuevaCategoriaMenu)
        {
            //MessageBox.Show(Convert.ToString(pnlEncabez.Size.Width - btnFuncionarios.Size.Width));
            //MessageBox.Show(Convert.ToString(pnlLateralL.Size.Height));

            /*
            if (categoriaMenuActual == nuevaCategoriaMenu) //no me saquen esto de vuelta por favor
            {
                return;
            }*/
            //-S lo saco porque interfiere con botones que quieren actualizar la pantalla sin cambiar de categoria el menu

            btnProductos.BackColor = Color.FromArgb(5, 5, 15);
            btnLotes.BackColor = Color.FromArgb(5, 5, 15);
            txtCI.ForeColor = Color.FromArgb(80, 80, 95);
            pnlLateralL.Show();
            pnlLateralR.Show();
            pnlFormHijo.Hide();
            pnl_lupita.Hide();
            pnlLogoFondo.Hide();
            txtCI.Show();
            btnAgregar.Hide();
            btnEliminar.Hide();
            lblError.Hide();
            dgvResultados.Hide();
            dgvResultados.Columns.Clear();
            IsMdiContainer = false;
            _txtCiIntacto = true;
            _txtNombreIntacto = true;

            categoriaMenuActual = nuevaCategoriaMenu;

            switch (nuevaCategoriaMenu)
            {
                case 0: //Ninguna categoría seleccionada / Pantalla inicial
                    pnlLogoFondo.Show();
                    txtCI.Hide();
                    break;
                case 1: //Categoría Productos seleccionada
                    btnProductos.BackColor = Color.FromArgb(12, 12, 27);
                    switch (Program.frmLogin.idioma)
                    {
                        case 0:
                            btnAgregar.Text = "Cambiar/Agregar Producto";
                            txtCI.Text = "Buscar ID de Producto...";
                            btnEliminar.Text = "Eliminar Producto";
                            break;
                        case 1:
                            btnAgregar.Text = "Modify/Add Product";
                            txtCI.Text = "Search in Products by ID...";
                            btnEliminar.Text = "Delete Product";
                            break;
                        default:
                            btnAgregar.Text = "Cambiar/Agregar Producto";
                            txtCI.Text = "Buscar ID de Producto...";
                            btnEliminar.Text = "Eliminar Producto";
                            break;
                    }
                    btnAgregar.Show();
                    btnEliminar.Show();
                    pnl_lupita.Show();
                    dgvResultados.Columns.Add("id", "ID");
                    dgvResultados.Columns.Add("nombre", "Nombre");
                    dgvResultados.Columns.Add("peso", "Peso");
                    dgvResultados.Columns.Add("volumen", "Volumen");
                    dgvResultados.Columns.Add("fragilidad", "Fragilidad");
                    dgvResultados.Show();
                    break;
                case 2: //Categoría Lotes seleccionada
                    btnLotes.BackColor = Color.FromArgb(12, 12, 27);
                    switch (Program.frmLogin.idioma)
                    {
                        case 0:
                            btnAgregar.Text = "Cambiar/Agregar Lote";
                            txtCI.Text = "Buscar ID de Lote...";
                            btnEliminar.Text = "Eliminar Lote";
                            break;
                        case 1:
                            btnAgregar.Text = "Modify/Add Package";
                            txtCI.Text = "Search in Packages by ID...";
                            btnEliminar.Text = "Delete Package";
                            break;
                        default:
                            btnAgregar.Text = "Cambiar/Agregar Lote";
                            txtCI.Text = "Buscar ID de Lote...";
                            btnEliminar.Text = "Eliminar Lote";
                            break;
                    }
                    btnAgregar.Show();
                    btnEliminar.Show();
                    pnl_lupita.Show();
                    dgvResultados.Show();
                    break;
            } //switch
        }


        private Int32 numero(String valor)
        {
            Int32 retorno;
            if (!Int32.TryParse(valor, out retorno))
            {
                retorno = 0;
            }
            return (retorno);
        }

        public Boolean validaCI(int CI)
        {
            Boolean retorno = true;
            Int16 i;
            int calculoDigitoControl = 0;
            int digitoControl = CI % 10;
            int CIaux = CI / 10; //división entera
            if (CI < 100000)
            {
                retorno = false;
            }
            else
            {
                for (i = 1; i <= 7; i++)
                {
                    switch (i)
                    {
                        case 1:
                            calculoDigitoControl = calculoDigitoControl + (CIaux % 10) * 6;
                            break;
                        case 2:
                            calculoDigitoControl = calculoDigitoControl + (CIaux % 10) * 7;
                            break;
                        case 3:
                            calculoDigitoControl = calculoDigitoControl + (CIaux % 10) * 4;
                            break;
                        case 4:
                            calculoDigitoControl = calculoDigitoControl + (CIaux % 10) * 3;
                            break;
                        case 5:
                            calculoDigitoControl = calculoDigitoControl + (CIaux % 10) * 2;
                            break;
                        case 6:
                            calculoDigitoControl = calculoDigitoControl + (CIaux % 10) * 1;
                            break;
                        case 7:
                            calculoDigitoControl = calculoDigitoControl + (CIaux % 10) * 8;
                            break;
                    };
                    CIaux = CIaux / 10;
                }//for
                retorno = (calculoDigitoControl % 10 == digitoControl);
            }
            return (retorno);
        }

        private void txtCI_TextChanged(object sender, EventArgs e) //esto hace que aparezca el cartelito que avisa que la cédula es inválida antes de darle al botón
        {
            switch (categoriaMenuActual)
            {
                case 1:
                case 2:

                    if (txtCI.Text.Length == 8)
                    {
                        if (validaCI(numero(txtCI.Text)))
                        {
                            lblError.Text = "Cédula valida.";
                            lblError.ForeColor = Color.MediumSeaGreen;
                            lblError.Show();
                        }
                        else
                        {
                            lblError.Text = "Cédula invalida.";
                            lblError.ForeColor = Color.Crimson;
                            lblError.Show();
                        }


                    }
                    else
                    {
                        lblError.Hide();
                    }
                    break;
            }

        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            switch (categoriaMenuActual)
            {
                case 1: //Producto

                    Producto p = new Producto();
                    List<String> nombreLugares = new List<String>();
                    p.Id = numero(txtCI.Text);
                    p.conexion = Program.cn;

                    switch (p.buscar())
                    {
                        case 0:  //Encontré 
                            Program.frmProductos = new Productos();
                            p.buscarLugar();
                            abrirFormHijo(Program.frmProductos);
                            Program.frmProductos.lblID.Text = "CI: " + txtCI.Text;
                            Program.frmProductos.lblTitulo.Text = "Creacíon de Producto";
                            Program.frmProductos.txtCI.Text = txtCI.Text;
                            Program.frmProductos.cboUbicacion.Items.Add(" ");
                            foreach (string lugar in p.NombreLugar)
                            {
                                Program.frmProductos.cboUbicacion.Items.Add(lugar);
                            }
                            List<String> opcionesF = new List<String>() { "No", "Si" };
                            foreach (string Opcion in opcionesF)
                            {
                                Program.frmProductos.cboFragilidad.Items.Add(Opcion);
                            }
                            List<String> opcionesP = new List<String>() { "No", "Si" };
                            foreach (string Opcion in opcionesP)
                            {
                                Program.frmProductos.cboPrioridad.Items.Add(Opcion);
                            }
                            break;
                        case 1: //La conexión está cerrada.
                            MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                            break;
                        case 2:
                        case 4:
                            MessageBox.Show("Hubo errores al efectuar operación");
                            break;
                        case 3: //No encontré
                            if (CustomMessageBox.Show("Registro no encontrado ¿Desea efectuar el alta?", "¿Alta?", 0) == 0)
                            {
                                Program.frmPrincipal.abrirFormHijo(Program.frmProductos);
                                Program.frmProductos.lblID.Text = "ID: " + txtCI.Text;
                                p.buscarLugar();
                                Program.frmProductos.txtCI.Text = txtCI.Text;
                                Program.frmProductos.cboUbicacion.Items.Add(" ");
                                foreach (string lugar in p.NombreLugar)
                                {
                                    Program.frmProductos.cboUbicacion.Items.Add(lugar);
                                }
                                List<String> opcionesF2 = new List<String>() { "No", "Si" };
                                foreach (string Opcion in opcionesF2)
                                {
                                    Program.frmProductos.cboFragilidad.Items.Add(Opcion);
                                }
                                List<String> opcionesP2 = new List<String>() { "No", "Si" };
                                foreach (string Opcion in opcionesP2)
                                {
                                    Program.frmProductos.cboPrioridad.Items.Add(Opcion);
                                }
                            }
                            break;
                    };
                    break;
                case 2: //Lotes

                    Lote l = new Lote();
                    List<String> nombreDestinos = new List<String>();
                    l.Id = int.Parse(txtCI.Text);
                    l.conexion = Program.cn;

                    switch (l.buscar())
                    {
                        case 0:  //Encontré 
                            Program.frmProductos = new Productos();
                            l.buscarDestinoYProductos();
                            abrirFormHijo(Program.frmLotes);
                            Program.frmLotes.lblID.Text = "ID: " + txtCI.Text;
                            Program.frmLotes.lblTitulo.Text = "Creacíon de Lote";
                            Program.frmLotes.txtID.Text = txtCI.Text;
                            Program.frmLotes.cboUbicacion.Items.Add(" ");
                            foreach (string lugar in l.NombreDeposito)
                            {
                                Program.frmLotes.cboUbicacion.Items.Add(lugar);
                            }
                            Program.frmLotes.cboProductos.Items.Add(" ");
                            foreach (string Producto in l.NombreProducto)
                            {
                                Program.frmLotes.cboProductos.Items.Add(Producto);
                            }
                            List<String> opcionesF = new List<String>() { "No", "Si" };
                            foreach (string Opcion in opcionesF)
                            {
                                Program.frmLotes.cboPrioridad.Items.Add(Opcion);
                            }
                            break;
                        case 1: //La conexión está cerrada.
                            MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                            break;
                        case 2:
                        case 4:
                            MessageBox.Show("Hubo errores al efectuar operación");
                            break;
                        case 3: //No encontré
                            if (CustomMessageBox.Show("Registro no encontrado ¿Desea efectuar el alta?", "¿Alta?", 0) == 0)
                            {
                                Program.frmPrincipal.abrirFormHijo(Program.frmLotes);
                                Program.frmLotes.lblID.Text = "ID: " + txtCI.Text;
                                l.buscarDestinoYProductos();
                                Program.frmLotes.txtID.Text = txtCI.Text;
                                Program.frmLotes.cboUbicacion.Items.Add(" ");
                                foreach (string lugar in l.NombreDeposito)
                                {
                                    Program.frmLotes.cboUbicacion.Items.Add(lugar);
                                }
                                Program.frmLotes.cboProductos.Items.Add(" ");
                                foreach (string Producto in l.NombreProducto)
                                {
                                    Program.frmLotes.cboProductos.Items.Add(Producto);
                                }
                                List<String> opcionesF2 = new List<String>() { "No", "Si" };
                                foreach (string Opcion in opcionesF2)
                                {
                                    Program.frmLotes.cboPrioridad.Items.Add(Opcion);
                                }
                            }
                            break;
                    };
                    break;
            }
        }

        private void btnCerrarSesion_Click(object sender, EventArgs e) //Cerrar sesion
        {
            if (Program.cn.State == 1) //si la conexion esta abierta
            {
                int respuesta;
                switch (Program.frmLogin.idioma)
                {
                    case 0:
                        respuesta = CustomMessageBox.Show("¿Desea cerrar sesión?", "Cerrar sesión", 1);
                        if (respuesta == 0)
                        {

                            Program.cn.Close();
                            Program.frmLogin = new Login();
                            Hide();
                            Program.frmLogin.ShowDialog();
                            Dispose();
                            //Close();
                        }
                        return;
                    case 1:
                        respuesta = CustomMessageBox.Show("Do you want to log out?", "Log out", 1);
                        if (respuesta == 0)
                        {

                            Program.cn.Close();
                            Program.frmLogin = new Login();
                            Hide();
                            Program.frmLogin.ShowDialog();
                            Dispose();
                            //Close();
                        }
                        return;
                }
                //int respuesta = CustomMessageBox.Show("¿Desea cerrar sesión?", "Cerrar sesión", 1);
            }
        }

        public void maximizarPantalla()
        {
            if (WindowState != FormWindowState.Maximized) //Si la ventana no está maximizada...
            {
                WindowState = FormWindowState.Maximized;
            }
            else
            {
                WindowState = FormWindowState.Normal;
            }
        }

        private void btnMax_Click(object sender, EventArgs e) //Maximizar pantalla
        {
            maximizarPantalla();
        }

        private void pnlBarraTitulo_DoubleClick(object sender, EventArgs e) //Otra forma de maximizar la pantalla más práctica
        {
            maximizarPantalla();
        }

        private void btnMin_Click(object sender, EventArgs e) //Minimizar pantalla
        {
            WindowState = FormWindowState.Minimized;
        }


        private void btnCerrar_Click(object sender, EventArgs e) //Cerrar aplicación
        {
            int respuesta;
            switch (Program.frmLogin.idioma)
            {
                case 0:
                    respuesta = CustomMessageBox.Show("¿Está seguro que desea salir de la aplicación?", "Saliendo de WingMaster", 1);
                    if (respuesta == 0)
                    {
                        Program.cn.Close();
                        this.Close();
                    }
                    return;
                case 1:
                    respuesta = CustomMessageBox.Show("Are you sure you want to exit the application?", "Exiting WingMaster", 1);
                    if (respuesta == 0)
                    {
                        Program.cn.Close();
                        this.Close();
                    }
                    return;
            }
        }

        private void tmrFadeIn_Tick(object sender, EventArgs e) //Animación de entrada del formulario
        {
            if (Opacity == 1)
            {
                tmrFadeIn.Stop();
            }
            Opacity += .17; //Marca la velocidad en la que el formulario entra
        }

        private void txtCI_Enter(object sender, EventArgs e) //para borrar el texto placeholder al hacer click y resaltar el texto en blanco más claro 
        {
            txtCI.ForeColor = Color.White;

            if (_txtCiIntacto)
            {
                txtCI.Text = "";
                _txtCiIntacto = false;
            }
        }

        private void btnProductos_Click(object sender, EventArgs e)
        {
            actualizarPantalla(4);
        }

        private void btnLotes_Click(object sender, EventArgs e)
        {
            actualizarPantalla(5);
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {

            /*switch (categoriaMenuActual)
            {

                case 1: //Productos

                    if (!validaCI(numero(txtCI.Text)))
                    {
                        CustomMessageBox.Show("Cédula inválida", "Error");
                        return;
                    }

                    Producto p = new Producto();
                    List<String> telefonosF = new List<String>();
                    f.ci = numero(txtCI.Text);
                    f.conexion = Program.cn;
                    txtCI.Text = Convert.ToString(f.ci);
                    switch (f.buscar())
                    {
                        case 0:  //Encontré 
                            string sql;
                            object filasAfectadas;
                            sql = "DELETE FROM chofer WHERE ci = " + txtCI.Text;
                            f.conexion.Execute(sql, out filasAfectadas);
                            sql = "DELETE FROM funcionario WHERE ci = " + txtCI.Text;
                            f.conexion.Execute(sql, out filasAfectadas);
                            sql = "delete from empleado_telefonos where empleado = " + txtCI.Text;
                            f.conexion.Execute(sql, out filasAfectadas);
                            sql = "delete from empleado where ci = " + txtCI.Text;
                            f.conexion.Execute(sql, out filasAfectadas);
                            CustomMessageBox.Show("Funcionario eliminado exitosamente.", "Error");
                            Program.frmBackoffice.actualizarPantalla(1);
                            break;
                        case 1: //La conexión está cerrada.
                            MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                            break;
                        case 2:
                        case 4:
                            MessageBox.Show("Hubo errores al efectuar operación");
                            break;
                        case 3: //No encontré
                            Program.existeCI = false;

                            CustomMessageBox.Show("La cédula no existe en el sistema", "Error");
                            return;
                    };
                    f = null;
                    break;

                case 2: //Lotes

                    if (!validaCI(numero(txtCI.Text)))
                    {
                        CustomMessageBox.Show("Cédula inválida", "Error");
                        return;
                    }

                    Program.frmCamioneros = new Camioneros();
                    List<String> telefonos = new List<String>();
                    Camionero c = new Camionero();
                    c.ci = numero(txtCI.Text);
                    c.conexion = Program.cn;
                    txtCI.Text = Convert.ToString(c.ci);

                    switch (c.buscar())
                    {
                        case 0:  //Encontré 
                            string sql;
                            object filasAfectadas;
                            sql = "DELETE FROM chofer WHERE ci = " + txtCI.Text;
                            c.conexion.Execute(sql, out filasAfectadas);
                            sql = "DELETE FROM funcionario WHERE ci = " + txtCI.Text;
                            c.conexion.Execute(sql, out filasAfectadas);
                            sql = "delete from empleado_telefonos where empleado = " + txtCI.Text;
                            c.conexion.Execute(sql, out filasAfectadas);
                            sql = "delete from empleado where ci = " + txtCI.Text;
                            c.conexion.Execute(sql, out filasAfectadas);
                            Program.frmBackoffice.actualizarPantalla(2);
                            MessageBox.Show("Camionero eliminado exitosamente.");
                            c = null;
                            break;
                        case 1: //La conexión está cerrada.
                            MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                            break;
                        case 2:
                        case 4:
                            MessageBox.Show("Hubo errores al efectuar operación");
                            break;
                        case 3: //No encontré
                            Program.existeCI = false;

                            CustomMessageBox.Show("La cédula no existe en el sistema", "Error");
                            return;
                    };
                    c = null;
                    break;
                case 3: //Camiones

                    Program.frmCamiones = new Camiones();
                    Camion ca = new Camion();
                    ca.Id = numero(txtCI.Text);
                    ca.conexion = Program.cn;
                    txtCI.Text = Convert.ToString(ca.Id);

                    switch (ca.buscar())
                    {
                        case 0:  //Encontré 
                            switch (ca.Eliminar())
                            {

                                case 0:
                                    CustomMessageBox.Show("Camion eliminado exitosamente.", "Mensaje");
                                    Program.frmBackoffice.actualizarPantalla(2);
                                    break;
                                case 1:
                                    CustomMessageBox.Show("Conexion cerrada", "Error");
                                    break;
                                case 2:
                                    CustomMessageBox.Show("Error al ejecutar consulta", "Error");
                                    break;
                            }
                            Program.frmBackoffice.actualizarPantalla(2);
                            break;
                        case 1: //La conexión está cerrada.
                            MessageBox.Show("Se perdió la sesión. Debe loguearse nuevamente.");
                            break;
                        case 2:
                        case 4:
                            MessageBox.Show("Hubo errores al efectuar operación");
                            break;
                        case 3: //No encontré
                            Program.existeCI = false;

                            CustomMessageBox.Show("El camión no existe en el sistema", "Error");
                            return;
                    };
                    c = null;
                    break;
            }*/
        }

        private Form frmActivo = null;

        public void abrirFormHijo(Form frmHijo)
        {
            IsMdiContainer = true;
            /*if (frmActivo != null)
                frmActivo.Close();
            frmHijo = frmActivo; */
            pnlFormHijo.Show();
            pnlFormHijo.Dock = DockStyle.Fill;
            switch (categoriaMenuActual)
            {
                case 1:
                    Program.frmProductos = new Productos();
                    frmHijo = Program.frmProductos;
                    break;
                case 2:
                    Program.frmLotes = new Lotes();
                    frmHijo = Program.frmLotes;
                    break;
            }
            //MessageBox.Show(Convert.ToString(categoriaMenuActual));
            btnAgregar.Hide();
            btnEliminar.Hide();
            dgvResultados.Hide();
            pnl_lupita.Hide();
            pnlLateralL.Hide();
            pnlLateralR.Hide();
            txtCI.Hide();
            lblError.Hide();

            frmHijo.MdiParent = this;
            frmHijo.TopLevel = false;
            frmHijo.Dock = DockStyle.Fill;
            pnlFormHijo.Show();
            pnlFormHijo.Controls.Add(frmHijo);
            pnlFormHijo.Tag = frmHijo;
            frmHijo.BringToFront();
            frmHijo.Show();
        }
        private void pnlLogoPhoenix_Click(object sender, EventArgs e)
        {
            actualizarPantalla(0);
        }

        public void actualizarDataGrid()
        {
            String sql;
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter();
            List<String> categorias = new List<String>() { "empleado", "empleado", "modeloCamion", "productos", "depositos" };
            ADODB.Recordset rs = new ADODB.Recordset();
            object filasAfectadas = new object();
            dgvResultados.DataSource = null;

            if (Program.cn.State == 1) //Si la conexion esta abierta
            {
                //MessageBox.Show(Convert.ToString(categoriaMenuActual));
                sql = "select * from " + categorias[categoriaMenuActual - 1] + " where ci like '" + txtCI.Text + "%'";
                try
                {
                    rs = Program.cn.Execute(sql, out filasAfectadas);
                }
                catch
                {
                    return;
                }
            }

            dgvResultados.DataSource = null;
            dgvResultados.Rows.Clear();
            dgvResultados.Columns.Clear();
            da.Fill(dt, rs);
            dgvResultados.DataSource = dt;
            //dgvResultados.AutoSizeColumnsMode=  DataGridViewAutoSizeColumnsMode.DisplayedCells;
            /*while (!rs.EOF) //mientras no llegue al fin 
            {
                dgvResultados.Rows.Add(Convert.ToString(rs.Fields[0].Value));
                rs.MoveNext(); //nos movemos al siguiente registro
            }*/
            rs = null;
            filasAfectadas = null;
            return;
        }

        private void txtCI_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtCI.Text.Length >= 3) //Comienza a tomar efecto despues del tercer digito para no sobrecargar la busqueda cuando todavia hay muchos registros
            {
                actualizarDataGrid();
            }
        }


        //para mover el forms por el label

        private bool _dragging = false;
        private Point _offset;
        private Point _start_point = new Point(0, 0);

        private void pnlBarraTitulo_MouseDown(object sender, MouseEventArgs e)
        {
            _dragging = true;
            _start_point = new Point(e.X, e.Y);
        }

        private void pnlBarraTitulo_MouseMove(object sender, MouseEventArgs e)
        {
            if (_dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this._start_point.X, p.Y - this._start_point.Y);
            }
        }

        private void pnlBarraTitulo_MouseUp(object sender, MouseEventArgs e)
        {
            _dragging = false;
        }

        private void btnPreferencias_Click(object sender, EventArgs e)
        {
            Preferencias frmPreferencias = new Preferencias(Program.frmLogin);
            frmPreferencias.Show();
        }

        public void actualizarTexto()
        {
            switch (Program.frmLogin.idioma)
            {
                case 0:
                    lblBienvenido.Text = "Bienvenido/a, ";
                    btnProductos.Text = "Productos";
                    btnLotes.Text = "Lotes";
                    btnCerrarSesion.Text = "Cerrar sesión";
                    pnlCreditos.Text = "desarrollado por";
                    break;
                case 1:
                    lblBienvenido.Text = "Welcome, ";
                    btnProductos.Text = "Products";
                    btnLotes.Text = "Packages";
                    btnCerrarSesion.Text = "Log out";
                    pnlCreditos.Text = "developed by";
                    break;
                default:
                    lblBienvenido.Text = "Bienvenido/a, ";
                    btnProductos.Text = "Productos";
                    btnLotes.Text = "Lotes";
                    btnCerrarSesion.Text = "Cerrar sesión";
                    pnlCreditos.Text = "desarrollado por";
                    break;
            }
        }
        public void actualizarTextoCategoria(int categoria)
        {
            switch (categoriaMenuActual)
            {
                case 0: //Ninguna categoría seleccionada / Pantalla inicial
                    return;
                case 1: //Categoría Funcionarios seleccionada
                    switch (Program.frmLogin.idioma)
                    {
                        case 0:
                            btnAgregar.Text = "Cambiar/Agregar Funcionario";
                            txtCI.Text = "Buscar CI de Funcionario...";
                            btnEliminar.Text = "Eliminar Funcionario";
                            break;
                        case 1:
                            btnAgregar.Text = "Modify/Add Clerk";
                            txtCI.Text = "Search in Clerk by ID...";
                            btnEliminar.Text = "Delete Clerk";
                            break;
                        default:
                            btnAgregar.Text = "Cambiar/Agregar Funcionario";
                            txtCI.Text = "Buscar CI de Funcionario...";
                            btnEliminar.Text = "Eliminar Funcionario";
                            break;
                    }
                    break;
                case 2: //Categoría Camioneros seleccionada
                    switch (Program.frmLogin.idioma)
                    {
                        case 0:
                            btnAgregar.Text = "Cambiar/Agregar Camionero";
                            txtCI.Text = "Buscar CI de Camionero...";
                            btnEliminar.Text = "Eliminar Camionero";
                            break;
                        case 1:
                            btnAgregar.Text = "Modify/Add Driver";
                            txtCI.Text = "Search in Drivers by ID...";
                            btnEliminar.Text = "Delete Driver";
                            break;
                        default:
                            btnAgregar.Text = "Cambiar/Agregar Camionero";
                            txtCI.Text = "Buscar CI de Camionero...";
                            btnEliminar.Text = "Eliminar Camionero";
                            break;
                    }
                    break;
                case 3: //Categoría Camiones seleccionada
                    switch (Program.frmLogin.idioma)
                    {
                        case 0:
                            btnAgregar.Text = "Cambiar/Agregar Camión";
                            txtCI.Text = "Buscar ID de Camión...";
                            btnEliminar.Text = "Eliminar Camión";
                            break;
                        case 1:
                            btnAgregar.Text = "Modify/Add Truck";
                            txtCI.Text = "Search in Trucks by ID...";
                            btnEliminar.Text = "Delete Truck";
                            break;
                        default:
                            btnAgregar.Text = "Cambiar/Agregar Camión";
                            txtCI.Text = "Buscar ID de Camión...";
                            btnEliminar.Text = "Eliminar Camión";
                            break;
                    }
                    break;
                case 4: //Categoría Productos seleccionada
                    switch (Program.frmLogin.idioma)
                    {
                        case 0:
                            btnAgregar.Text = "Cambiar/Agregar Producto";
                            txtCI.Text = "Buscar ID de Producto...";
                            btnEliminar.Text = "Eliminar Producto";
                            break;
                        case 1:
                            btnAgregar.Text = "Modify/Add Product";
                            txtCI.Text = "Search in Products by ID...";
                            btnEliminar.Text = "Delete Product";
                            break;
                        default:
                            btnAgregar.Text = "Cambiar/Agregar Producto";
                            txtCI.Text = "Buscar ID de Producto...";
                            btnEliminar.Text = "Eliminar Producto";
                            break;
                    }
                    break;
                case 5: //Categoría Lotes seleccionada
                    switch (Program.frmLogin.idioma)
                    {
                        case 0:
                            btnAgregar.Text = "Cambiar/Agregar Lote";
                            txtCI.Text = "Buscar ID de Lote...";
                            btnEliminar.Text = "Eliminar Lote";
                            break;
                        case 1:
                            btnAgregar.Text = "Modify/Add Package";
                            txtCI.Text = "Search in Packages by ID...";
                            btnEliminar.Text = "Delete Package";
                            break;
                        default:
                            btnAgregar.Text = "Cambiar/Agregar Lote";
                            txtCI.Text = "Buscar ID de Lote...";
                            btnEliminar.Text = "Eliminar Lote";
                            break;
                    }
                    break;
                    /*case 6: //Categoría Depósitos seleccionada
                        switch (Program.frmLogin.idioma)
                        {
                            case 0:
                                btnAgregar.Text = "Cambiar/Agregar Lote";
                                txtCI.Text = "Buscar ID de Lote...";
                                btnEliminar.Text = "Eliminar Lote";
                                txtNombre.Text = "Buscar en Lotes...";
                                break;
                            case 1:
                                btnAgregar.Text = "Modify/Add Warehouses";
                                txtCI.Text = "Search in Warehouses by ID...";
                                btnEliminar.Text = "Delete Warehouses";
                                txtNombre.Text = "Search in Warehousess...";
                                break;
                            default:
                                btnAgregar.Text = "Cambiar/Agregar Depósito";
                                txtCI.Text = "Buscar ID de Depósito...";
                                btnEliminar.Text = "Eliminar Depósito";
                                txtNombre.Text = "Buscar en Depósitos...";
                                break;
                        }*/
            }
        }
    }
}
